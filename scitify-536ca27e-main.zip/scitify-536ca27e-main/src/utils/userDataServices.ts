
import { supabase } from '@/lib/supabase';
import { Product, ProductVariant } from '@/types/product';
import { CartItem } from '@/contexts/cart';
import { adaptProductForUI } from '@/types/product';

// Favorites Service Functions
export const getUserFavorites = async (userId: string) => {
  try {
    console.log('Fetching favorites for user:', userId);
    const { data, error } = await supabase
      .from('favorites')
      .select('product_id')
      .eq('user_id', userId);
    
    if (error) {
      console.error('Error in getUserFavorites:', error);
      throw error;
    }
    
    console.log('Favorites data from DB:', data);
    
    if (!data || data.length === 0) {
      return [];
    }
    
    // Now fetch the actual product details for each favorite
    const productIds = data.map(item => item.product_id);
    
    const { data: productsData, error: productsError } = await supabase
      .from('products')
      .select(`
        *,
        variants:product_variants(*),
        images:product_images(*)
      `)
      .in('id', productIds);
    
    if (productsError) {
      console.error('Error fetching favorite products:', productsError);
      throw productsError;
    }
    
    console.log('Favorite products retrieved:', productsData);
    return productsData || [];
  } catch (error) {
    console.error('Error fetching user favorites:', error);
    return [];
  }
};

export const saveFavorite = async (userId: string, productId: string) => {
  try {
    console.log(`Saving favorite: userId=${userId}, productId=${productId}`);
    const { error } = await supabase
      .from('favorites')
      .insert({
        user_id: userId,
        product_id: productId,
        created_at: new Date().toISOString()
      });
    
    if (error) {
      console.error('Error in saveFavorite:', error);
      throw error;
    }
    
    console.log('Favorite saved successfully');
    return true;
  } catch (error) {
    console.error('Error saving favorite:', error);
    return false;
  }
};

export const removeFavorite = async (userId: string, productId: string) => {
  try {
    console.log(`Removing favorite: userId=${userId}, productId=${productId}`);
    const { error } = await supabase
      .from('favorites')
      .delete()
      .eq('user_id', userId)
      .eq('product_id', productId);
    
    if (error) {
      console.error('Error in removeFavorite:', error);
      throw error;
    }
    
    console.log('Favorite removed successfully');
    return true;
  } catch (error) {
    console.error('Error removing favorite:', error);
    return false;
  }
};

// Cart Service Functions
export const getUserCart = async (userId: string) => {
  try {
    console.log('Fetching cart for user:', userId);
    const { data, error } = await supabase
      .from('cart_items')
      .select('id, product_id, quantity, variant_data, created_at')
      .eq('user_id', userId);
    
    if (error) {
      console.error('Error in getUserCart:', error);
      throw error;
    }
    
    console.log('Cart data from DB:', data);
    
    if (!data || data.length === 0) {
      return [];
    }
    
    // Now fetch the actual product details for each cart item
    const productIds = data.map(item => item.product_id);
    
    const { data: productsData, error: productsError } = await supabase
      .from('products')
      .select(`
        *,
        variants:product_variants(*),
        images:product_images(*)
      `)
      .in('id', productIds);
    
    if (productsError) {
      console.error('Error fetching cart products:', productsError);
      throw productsError;
    }
    
    console.log('Cart products retrieved:', productsData);
    
    // Map the products data to CartItem format
    const cartItems: CartItem[] = data.map(item => {
      const product = productsData?.find(p => p.id === item.product_id);
      if (!product) return null;
      
      const adaptedProduct = adaptProductForUI(product);
      
      // Convert the variant_data from JSON to a proper ProductVariant
      const variantData = item.variant_data as unknown as ProductVariant;
      
      // Use variant ID as cart item ID for unique identification
      const cartItemId = variantData?.id || product.id;
      
      return {
        id: cartItemId,
        product: adaptedProduct,
        variant: variantData,
        quantity: item.quantity
      };
    }).filter(Boolean) as CartItem[];
    
    return cartItems;
  } catch (error) {
    console.error('Error fetching user cart:', error);
    return [];
  }
};

export const mergeLocalAndDbCart = async (userId: string, localCart: CartItem[]) => {
  try {
    console.log('Starting cart merge for user:', userId);
    console.log('Local cart to merge:', localCart);
    
    if (!localCart || localCart.length === 0) {
      console.log('No local cart items to merge, skipping');
      return;
    }
    
    // Get existing cart items from database
    const { data: existingItems, error } = await supabase
      .from('cart_items')
      .select('id, product_id, quantity, variant_data')
      .eq('user_id', userId);
    
    if (error) {
      console.error('Error fetching existing cart for merge:', error);
      throw error;
    }
    
    console.log('Existing DB cart items:', existingItems);
    
    // Process each local cart item
    for (const item of localCart) {
      // Skip invalid items
      if (!item || !item.product || !item.product.id) {
        console.log('Skipping invalid cart item:', item);
        continue;
      }
      
      // Check if this exact variant already exists in DB
      const existingItem = existingItems?.find(dbItem => {
        if (dbItem.product_id !== item.product.id) return false;
        const dbVariant = dbItem.variant_data as any;
        return dbVariant?.id === item.variant?.id;
      });
      
      if (existingItem) {
        // Update quantity for existing item
        console.log(`Updating quantity for existing variant ${item.variant?.id} from ${existingItem.quantity} to ${existingItem.quantity + item.quantity}`);
        
        const { error: updateError } = await supabase
          .from('cart_items')
          .update({ 
            quantity: existingItem.quantity + item.quantity,
            updated_at: new Date().toISOString()
          })
          .eq('id', existingItem.id);
        
        if (updateError) {
          console.error('Error updating cart item quantity during merge:', updateError);
        }
      } else {
        // Insert new item
        console.log(`Adding new variant to cart: ${item.product.id} / ${item.variant?.id}, quantity: ${item.quantity}`);
        
        const { error: insertError } = await supabase
          .from('cart_items')
          .insert([{
            user_id: userId,
            product_id: item.product.id,
            variant_data: item.variant as any,
            quantity: item.quantity,
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString()
          }]);
        
        if (insertError) {
          console.error('Error inserting new cart item during merge:', insertError);
        }
      }
    }
    
    console.log('Cart merge completed successfully');
    return true;
  } catch (error) {
    console.error('Error merging cart:', error);
    return false;
  }
};

export const saveCartItem = async (userId: string, item: CartItem) => {
  try {
    console.log('Saving cart item:', item, 'for user:', userId);
    
    // Check if this exact variant already exists in the cart
    const { data, error: fetchError } = await supabase
      .from('cart_items')
      .select('*')
      .eq('user_id', userId)
      .eq('product_id', item.product.id);
    
    if (fetchError) {
      console.error('Error checking if cart item exists:', fetchError);
      throw fetchError;
    }
    
    // Find matching variant by variant ID in variant_data
    const existingItem = data?.find(dbItem => {
      const dbVariant = dbItem.variant_data as any;
      return dbVariant?.id === item.variant?.id;
    });
    
    if (existingItem) {
      // Update existing item quantity
      const { error } = await supabase
        .from('cart_items')
        .update({ 
          quantity: existingItem.quantity + item.quantity,
          updated_at: new Date().toISOString() 
        })
        .eq('id', existingItem.id);
      
      if (error) {
        console.error('Error updating cart item:', error);
        throw error;
      }
    } else {
      // Insert new item
      const { error } = await supabase
        .from('cart_items')
        .insert({
          user_id: userId,
          product_id: item.product.id,
          variant_data: item.variant as any,
          quantity: item.quantity,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        });
      
      if (error) {
        console.error('Error inserting cart item:', error);
        throw error;
      }
    }
    
    console.log('Cart item saved successfully');
    return true;
  } catch (error) {
    console.error('Error saving cart item:', error);
    return false;
  }
};

export const updateCartItemQuantity = async (userId: string, cartItemId: string, quantity: number) => {
  try {
    console.log('Updating cart item quantity:', cartItemId, quantity, 'for user:', userId);
    
    // Find the cart item by matching variant ID in variant_data
    const { data, error: fetchError } = await supabase
      .from('cart_items')
      .select('*')
      .eq('user_id', userId);
    
    if (fetchError) {
      console.error('Error finding cart item to update:', fetchError);
      throw fetchError;
    }
    
    // Match by variant ID stored in variant_data
    const matchingItem = data?.find(dbItem => {
      const dbVariant = dbItem.variant_data as any;
      return dbVariant?.id === cartItemId;
    }) || data?.find(dbItem => dbItem.product_id === cartItemId);
    
    if (matchingItem) {
      const { error } = await supabase
        .from('cart_items')
        .update({ 
          quantity: quantity,
          updated_at: new Date().toISOString() 
        })
        .eq('id', matchingItem.id);
      
      if (error) {
        console.error('Error updating cart item quantity:', error);
        throw error;
      }
      
      console.log('Cart item quantity updated successfully');
      return true;
    }
    
    console.log('Cart item not found for quantity update');
    return false;
  } catch (error) {
    console.error('Error updating cart item quantity:', error);
    return false;
  }
};

export const removeCartItem = async (userId: string, cartItemId: string) => {
  try {
    console.log('Removing cart item:', cartItemId, 'for user:', userId);
    
    // Find the cart item by matching variant ID in variant_data
    const { data, error: fetchError } = await supabase
      .from('cart_items')
      .select('*')
      .eq('user_id', userId);
    
    if (fetchError) {
      console.error('Error finding cart item to remove:', fetchError);
      throw fetchError;
    }
    
    const matchingItem = data?.find(dbItem => {
      const dbVariant = dbItem.variant_data as any;
      return dbVariant?.id === cartItemId;
    }) || data?.find(dbItem => dbItem.product_id === cartItemId);
    
    if (matchingItem) {
      const { error } = await supabase
        .from('cart_items')
        .delete()
        .eq('id', matchingItem.id);
      
      if (error) {
        console.error('Error removing cart item:', error);
        throw error;
      }
    }
    
    console.log('Cart item removed successfully');
    return true;
  } catch (error) {
    console.error('Error removing cart item:', error);
    return false;
  }
};

export const clearUserCart = async (userId: string) => {
  try {
    console.log('Clearing cart for user:', userId);
    
    const { error } = await supabase
      .from('cart_items')
      .delete()
      .eq('user_id', userId);
    
    if (error) {
      console.error('Error clearing user cart:', error);
      throw error;
    }
    
    console.log('User cart cleared successfully');
    return true;
  } catch (error) {
    console.error('Error clearing user cart:', error);
    return false;
  }
};
