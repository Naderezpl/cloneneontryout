import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';

export type PdfOrder = {
  id: string;
  created_at: string;
  status: string;
  total_price: number;
  customer_name?: string | null;
  customer_email?: string | null;
  customer_phone?: string | null;
  shipping_address?: string | null;
  notes?: string | null;
  delivery_fee?: number | null;
};

export type PdfOrderItem = {
  id: string;
  quantity: number;
  price: number;
  product_name?: string;
  variant_data?: any;
};

export type PdfCompany = {
  name?: string | null;
  logoUrl?: string | null;
  email?: string | null;
  phone?: string | null;
  address?: string | null;
  currency?: string | null;
};

export const formatVariant = (variantData: any): string => {
  if (!variantData) return '';
  const parts: string[] = [];
  if (variantData.variant_name && variantData.variant_name !== 'Default') {
    parts.push(String(variantData.variant_name));
  }
  const opts = variantData.options || variantData.selected_options || variantData.variant_options;
  if (opts && typeof opts === 'object') {
    Object.entries(opts).forEach(([k, v]) => parts.push(`${k}: ${v}`));
  }
  if (variantData.sku) parts.push(`SKU: ${variantData.sku}`);
  return parts.join(' • ');
};

const loadImage = (url: string): Promise<{ dataUrl: string; width: number; height: number } | null> =>
  new Promise((resolve) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      try {
        const canvas = document.createElement('canvas');
        canvas.width = img.naturalWidth;
        canvas.height = img.naturalHeight;
        const ctx = canvas.getContext('2d');
        if (!ctx) return resolve(null);
        ctx.drawImage(img, 0, 0);
        resolve({ dataUrl: canvas.toDataURL('image/png'), width: img.naturalWidth, height: img.naturalHeight });
      } catch {
        resolve(null);
      }
    };
    img.onerror = () => resolve(null);
    img.src = url;
  });

export const orderNumber = (id: string) => id.slice(-6).toUpperCase();

export const orderPdfFileName = (order: PdfOrder) => {
  const name = (order.customer_name || 'Customer')
    .trim()
    .replace(/[^\p{L}\p{N}\s-]/gu, '')
    .split(/\s+/)
    .join('-');
  return `Order-${orderNumber(order.id)}-${name}.pdf`;
};

export const buildOrderPdf = async (
  order: PdfOrder,
  items: PdfOrderItem[],
  company: PdfCompany = {}
): Promise<jsPDF> => {
  const doc = new jsPDF({ unit: 'pt', format: 'a4' });
  const pageWidth = doc.internal.pageSize.getWidth();
  const margin = 40;
  const currency = company.currency || '$';
  let y = margin;

  if (company.logoUrl) {
    const img = await loadImage(company.logoUrl);
    if (img) {
      const maxW = 110;
      const maxH = 55;
      const ratio = Math.min(maxW / img.width, maxH / img.height);
      doc.addImage(img.dataUrl, 'PNG', margin, y, img.width * ratio, img.height * ratio);
    }
  }

  doc.setFontSize(20);
  doc.setFont('helvetica', 'bold');
  doc.text('RECEIPT / DELIVERY SLIP', pageWidth - margin, y + 16, { align: 'right' });
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text(`Order #${orderNumber(order.id)}`, pageWidth - margin, y + 34, { align: 'right' });
  doc.text(new Date(order.created_at).toLocaleString(), pageWidth - margin, y + 48, { align: 'right' });
  doc.text(`Status: ${order.status || 'pending'}`, pageWidth - margin, y + 62, { align: 'right' });

  y += 90;
  doc.setDrawColor(200);
  doc.line(margin, y, pageWidth - margin, y);
  y += 20;

  const colWidth = (pageWidth - margin * 2) / 2;

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.text('From', margin, y);
  doc.text('Deliver To', margin + colWidth, y);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);

  const fromLines = [company.name || 'Store', company.email || '', company.phone || '', company.address || '']
    .filter(Boolean)
    .flatMap((l) => doc.splitTextToSize(String(l), colWidth - 20));
  const toLines = [
    order.customer_name || 'N/A',
    order.customer_email || '',
    order.customer_phone || '',
    order.shipping_address || '',
  ]
    .filter(Boolean)
    .flatMap((l) => doc.splitTextToSize(String(l), colWidth - 20));

  doc.text(fromLines, margin, y + 16);
  doc.text(toLines, margin + colWidth, y + 16);
  y += 16 + Math.max(fromLines.length, toLines.length) * 13 + 16;

  const body = items.map((item) => {
    const variant = formatVariant(item.variant_data);
    return [
      variant ? `${item.product_name || 'Product'}\n${variant}` : item.product_name || 'Product',
      String(item.quantity),
      `${currency}${Number(item.price).toFixed(2)}`,
      `${currency}${(Number(item.price) * item.quantity).toFixed(2)}`,
    ];
  });

  autoTable(doc, {
    startY: y,
    head: [['Item', 'Qty', 'Unit Price', 'Total']],
    body,
    theme: 'grid',
    styles: { fontSize: 9, cellPadding: 6 },
    headStyles: { fillColor: [30, 30, 30], textColor: 255 },
    columnStyles: {
      0: { cellWidth: 'auto' },
      1: { cellWidth: 50, halign: 'center' },
      2: { cellWidth: 80, halign: 'right' },
      3: { cellWidth: 80, halign: 'right' },
    },
    margin: { left: margin, right: margin },
  });

  y = (doc as any).lastAutoTable.finalY + 20;

  const itemsTotal = items.reduce((sum, i) => sum + Number(i.price) * i.quantity, 0);
  const deliveryFee = Number(order.delivery_fee || 0);
  const grandTotal = Number(order.total_price ?? itemsTotal + deliveryFee);
  const discount = Math.max(0, itemsTotal + deliveryFee - grandTotal);

  const summary: [string, string][] = [
    ['Subtotal', `${currency}${itemsTotal.toFixed(2)}`],
    ['Delivery Fee', `${currency}${deliveryFee.toFixed(2)}`],
  ];
  if (discount > 0) summary.push(['Discount', `-${currency}${discount.toFixed(2)}`]);

  doc.setFontSize(10);
  summary.forEach(([label, value]) => {
    doc.text(label, pageWidth - margin - 160, y);
    doc.text(value, pageWidth - margin, y, { align: 'right' });
    y += 16;
  });
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(13);
  doc.text('Grand Total', pageWidth - margin - 160, y + 4);
  doc.text(`${currency}${grandTotal.toFixed(2)}`, pageWidth - margin, y + 4, { align: 'right' });
  y += 30;

  if (order.notes) {
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(11);
    doc.text('Order Notes', margin, y);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(10);
    const noteLines = doc.splitTextToSize(String(order.notes), pageWidth - margin * 2);
    doc.text(noteLines, margin, y + 15);
    y += 15 + noteLines.length * 13;
  }

  doc.setFontSize(9);
  doc.setTextColor(130);
  doc.text('Thank you for your order.', margin, doc.internal.pageSize.getHeight() - 30);

  return doc;
};

export const downloadOrderPdf = async (order: PdfOrder, items: PdfOrderItem[], company: PdfCompany = {}) => {
  const doc = await buildOrderPdf(order, items, company);
  doc.save(orderPdfFileName(order));
};

export const printOrderPdf = async (order: PdfOrder, items: PdfOrderItem[], company: PdfCompany = {}) => {
  const doc = await buildOrderPdf(order, items, company);
  doc.autoPrint();
  const url = doc.output('bloburl');
  window.open(url as any, '_blank');
};
