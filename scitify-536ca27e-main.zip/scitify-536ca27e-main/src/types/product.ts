export interface VariantOptionGroup {
    name: string;
    values: string[];
}

export interface Product {
    id: string;
    name: string;
    description: string;
    category_id: string;
    product_cost?: number;
    price?: number;
    variants?: ProductVariant[];
    images?: ProductImage[];
    is_hidden?: boolean;
    track_stock?: boolean;
    featured?: boolean;
    is_featured?: boolean;
    is_on_sale?: boolean;
    show_description?: boolean;
    show_faq?: boolean;
    show_recommendations?: boolean;
    faqs?: ProductFAQ[];
    recommended_product_ids?: string[];
    variant_options?: VariantOptionGroup[];
}

export interface ProductVariant {
    id: string;
    product_id: string;
    variant_name: string;
    price: number;
    stock_quantity: number;
    compare_at_price?: number;
    original_price?: number;
    is_on_sale?: boolean;
    images?: ProductImage[];
}

export interface ProductImage {
    id: string;
    product_id: string;
    variant_id: string | null;
    image_url: string;
    title: string | null;
    position: number | null;
}

export interface Category {
    id: string;
    name: string;
}

export interface ProductFAQ {
    id: string;
    product_id: string;
    question: string;
    answer: string;
    position: number | null;
}

// CartItem type has been moved to src/contexts/cart/cartTypes.ts
// Import it from there when needed: import { CartItem } from '@/contexts/cart';

export function adaptProductForUI(product: any): Product {
    // Ensure we have the basic product properties
    const adaptedProduct: Product = {
        id: product.id,
        name: product.name,
        description: product.description || '',
        category_id: product.category_id || null,
        product_cost: typeof product.product_cost === 'number' ? product.product_cost : 0,
        is_hidden: product.is_hidden !== undefined ? product.is_hidden : false,
        track_stock: product.track_stock !== undefined ? product.track_stock : false,
        featured: product.featured !== undefined ? product.featured : false,
        is_featured: product.is_featured !== undefined ? product.is_featured : false,
        is_on_sale: product.is_on_sale !== undefined ? product.is_on_sale : false,
        show_description: product.show_description !== undefined ? product.show_description : true,
        show_faq: product.show_faq !== undefined ? product.show_faq : false,
        show_recommendations: product.show_recommendations !== undefined ? product.show_recommendations : false,
        faqs: product.faqs || [],
        recommended_product_ids: product.recommended_product_ids || [],
        variant_options: product.variant_options || []
    };

    // Add variants if they exist
    if (product.variants && Array.isArray(product.variants)) {
        adaptedProduct.variants = product.variants;
        
        // If there are variants, calculate the lowest price for the product
        if (product.variants.length > 0) {
            const prices = product.variants.map((v: ProductVariant) => v.price).filter((p: number) => p !== undefined);
            if (prices.length > 0) {
                adaptedProduct.price = Math.min(...prices);
            }
        }
    }

    // Add images if they exist, sorted by position
    if (product.images && Array.isArray(product.images)) {
        adaptedProduct.images = [...product.images].sort((a, b) => (a.position ?? 999) - (b.position ?? 999));
    }

    return adaptedProduct;
}
