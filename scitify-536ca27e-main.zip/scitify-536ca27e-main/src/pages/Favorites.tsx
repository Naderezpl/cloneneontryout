
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useFavorites } from '@/contexts/FavoritesContext';
import ProductCard from '@/components/ProductCard';
import { Button } from '@/components/ui/button';
import { Heart } from 'lucide-react';
import { adaptProductForUI } from '@/types/product';
import { useAuth } from '@/contexts/AuthContext';

const Favorites = () => {
  const { favorites } = useFavorites();
  const { isAuthenticated } = useAuth();
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Add a small delay to allow favorites to load
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 500);
    
    return () => clearTimeout(timer);
  }, [favorites]);

  console.log('Rendering Favorites page with favorites:', favorites);

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8 text-center">Your Favorites</h1>

      {isLoading ? (
        <div className="text-center py-12">
          <p>Loading favorites...</p>
        </div>
      ) : favorites.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {favorites.map(product => (
            <ProductCard key={product.id} product={adaptProductForUI(product)} />
          ))}
        </div>
      ) : (
        <div className="text-center py-12">
          <Heart className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
          <h3 className="text-xl font-medium mb-2">No favorites yet</h3>
          <p className="text-muted-foreground mb-6">
            {isAuthenticated 
              ? "You haven't added any products to your favorites yet."
              : "You haven't added any products to your favorites yet. Your favorites will be saved locally on this device."}
          </p>
          <Button asChild>
            <Link to="/shop">Explore Products</Link>
          </Button>
        </div>
      )}
    </div>
  );
};

export default Favorites;
