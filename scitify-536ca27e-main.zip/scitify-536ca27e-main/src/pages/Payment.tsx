import React, { useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Wallet, Coins, Copy } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { fetchSiteSettings } from '@/api/settings';

const Payment = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { toast } = useToast();
  const { data: settings } = useQuery({ queryKey: ['site-settings'], queryFn: fetchSiteSettings });

  const state = (location.state as any) || {};
  const { orderId, paymentMethod, total, usdtAddress } = state;

  // COD orders never see this page
  useEffect(() => {
    if (!orderId || !paymentMethod || paymentMethod === 'cod') {
      navigate('/', { replace: true });
    }
  }, [orderId, paymentMethod, navigate]);

  if (!orderId || !paymentMethod || paymentMethod === 'cod') return null;

  const isOmt = paymentMethod === 'omt';
  const methodName = isOmt ? 'OMT' : 'Whish Money';

  const copy = (label: string, value?: string | null) => {
    if (!value) return;
    navigator.clipboard.writeText(value);
    toast({ title: 'Copied', description: `${label} copied to clipboard.` });
  };

  const Row = ({ label, value }: { label: string; value?: string | null }) =>
    value ? (
      <div className="flex items-center justify-between gap-4 py-2">
        <span className="text-sm text-muted-foreground">{label}</span>
        <div className="flex items-center gap-2">
          <span className="font-medium break-all text-right">{value}</span>
          <Button type="button" variant="ghost" size="icon" onClick={() => copy(label, value)}>
            <Copy className="h-4 w-4" />
          </Button>
        </div>
      </div>
    ) : null;

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="max-w-xl mx-auto">
        <h1 className="text-3xl font-bold mb-2 text-center">Complete Your Payment</h1>
        <p className="text-muted-foreground text-center mb-8">
          Order #{String(orderId).slice(-6)}
          {typeof total === 'number' ? ` · $${Number(total).toFixed(2)}` : ''}
        </p>

        <Card>
          <CardContent className="p-6 space-y-4">
            {(paymentMethod === 'whish-money' || paymentMethod === 'omt') && (
              <>
                <div className="flex items-center gap-2 text-lg font-semibold">
                  <Wallet className="h-5 w-5" /> {isOmt ? 'OMT' : 'Whish Money'}
                </div>
                <p className="text-sm">
                  Send{' '}
                  {typeof total === 'number' ? `$${Number(total).toFixed(2)}` : 'the order total'} via{' '}
                  {methodName} to the store account. Write{' '}
                  <span className="font-semibold">Order #{String(orderId).slice(-6)}</span> in the
                  transfer note.
                </p>
                <Separator />
                {isOmt ? (
                  <>
                    <Row label="OMT Number" value={settings?.omt_number} />
                    <Row label="OMT Full Name" value={settings?.omt_owner_name} />
                  </>
                ) : (
                  <>
                    <Row label="Whish Number" value={settings?.whish_number} />
                    <Row label="Account Name" value={settings?.whish_owner_name} />
                  </>
                )}
              </>
            )}

            {paymentMethod === 'crypto-usdt' && (
              <>
                <div className="flex items-center gap-2 text-lg font-semibold">
                  <Coins className="h-5 w-5" /> Crypto (USDT)
                </div>
                <p className="text-sm">
                  Send{' '}
                  {typeof total === 'number' ? `$${Number(total).toFixed(2)}` : 'the order total'} in
                  USDT (ERC20) to the wallet address below. Write{' '}
                  <span className="font-semibold">Order #{String(orderId).slice(-6)}</span> in the
                  transfer note.
                </p>
                <Separator />
                <Row label="USDT (ERC20) Address" value={usdtAddress} />
              </>
            )}

            {settings?.payment_instructions && (
              <>
                <Separator />
                <p className="text-sm whitespace-pre-line">{settings.payment_instructions}</p>
              </>
            )}

          </CardContent>
        </Card>


        <div className="flex justify-center mt-8">
          <Button
            size="lg"
            onClick={() =>
              navigate('/order/confirmation', {
                replace: true,
                state: { fromCheckout: true, paymentMethod, orderId },
              })
            }
          >
            I've Completed the Payment
          </Button>
        </div>
      </div>
    </div>
  );
};

export default Payment;
