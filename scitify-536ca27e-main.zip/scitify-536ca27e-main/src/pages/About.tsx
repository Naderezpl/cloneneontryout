
import React, { useEffect, useState } from 'react';
import { fetchPageBySlug } from '@/api/pages';
import { cn } from '@/lib/utils';

const About = () => {
  const [content, setContent] = useState<{ title: string; html: string; enabled: boolean; hero?: string | null }>({
    title: 'Our Story',
    html: '',
    enabled: true,
    hero: null,
  });

  useEffect(() => {
    (async () => {
      try {
        const page = await fetchPageBySlug('about');
        if (page && page.enabled) {
          setContent({
            title: page.title || 'Our Story',
            html: page.content_html || '',
            enabled: true,
            hero: page.hero_image_url || null,
          });
        } else {
          setContent({ title: 'Our Story', html: '', enabled: false, hero: null });
        }
      } catch {}
    })();
  }, []);

  if (!content.enabled) {
    return (
      <div className="container mx-auto px-4 py-24 text-center text-muted-foreground">
        This page is not available.
      </div>
    );
  }

  return (
    <section className="bg-background py-20 md:py-28">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-10 md:gap-16 lg:gap-20 items-center max-w-6xl mx-auto">
          {/* Image */}
          {content.hero && (
            <div
              className={cn(
                "rounded-3xl overflow-hidden",
                "shadow-[0_4px_6px_-1px_rgb(0_0_0/0.04),0_20px_25px_-5px_rgb(0_0_0/0.05)]",
                "transition-shadow duration-300 hover:shadow-[0_8px_12px_-2px_rgb(0_0_0/0.06),0_25px_35px_-5px_rgb(0_0_0/0.08)]"
              )}
            >
              <img
                src={content.hero}
                alt={content.title}
                className="w-full h-auto object-cover aspect-[4/5]"
                loading="lazy"
              />
            </div>
          )}

          {/* Content */}
          <div className={cn("flex flex-col justify-center", !content.hero && "md:col-span-2 max-w-2xl mx-auto text-center")}>
            <h1 className="text-3xl md:text-4xl font-bold tracking-tight text-foreground mb-6 leading-[1.1]">
              {content.title}
            </h1>

            {content.html && (
              <div
                className="prose prose-lg max-w-none text-muted-foreground [&>p]:leading-relaxed [&>p]:mb-4 [&>h2]:text-foreground [&>h3]:text-foreground"
                dangerouslySetInnerHTML={{ __html: content.html }}
              />
            )}
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
