
import React from 'react';
import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Heart, ShoppingCart, Check, AlertCircle, ChevronRight, Truck, Shield, Headphones, Sparkles, Package, Plane, Rocket, Clock, BadgeCheck, Award, Star, Wrench, MessageCircle, Phone as PhoneIcon, LifeBuoy, Bot, Zap, Globe, Lock, CheckCircle, Gift, Leaf, Crown, Heart as HeartIcon } from 'lucide-react';
import { 
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";
import { Button } from '@/components/ui/button';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
// Removed unused Tabs imports
import { 
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { useToast } from '@/components/ui/use-toast';
import { useCart } from '@/contexts/cart';
import { useFavorites } from '@/contexts/FavoritesContext';
import { supabase } from '@/lib/supabase';
import { Product, adaptProductForUI } from '@/types/product';
import ProductCard from '@/components/ProductCard';
import { fetchSiteSettings } from '@/api/settings';
import { useQuery as useQuery2 } from '@tanstack/react-query';
import { Textarea } from '@/components/ui/textarea';
import { createReview, analyzeReviewContent } from '@/api/reviews';

class ErrorBoundary extends React.Component<{ children: React.ReactNode }, { hasError: boolean }> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { hasError: false };
  }
  static getDerivedStateFromError() {
    return { hasError: true };
  }
  componentDidCatch() {}
  render() {
    if (this.state.hasError) {
      return (
        <div className="container mx-auto px-4 py-16 text-center">
          <div className="text-2xl font-bold mb-2">Something went wrong</div>
          <div className="text-muted-foreground">Please go back and try again.</div>
        </div>
      );
    }
    return this.props.children;
  }
}

const ProductDetail = () => {
  const { id } = useParams<{ id: string }>();
  const [quantity, setQuantity] = useState(1);
  const [selectedVariantId, setSelectedVariantId] = useState<string | null>(null);
  const [selectedOptions, setSelectedOptions] = useState<Record<string, string>>({});
  const { addToCart } = useCart();
  const { favorites, toggleFavorite } = useFavorites();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [reviewerName, setReviewerName] = useState('');
  const [reviewRating, setReviewRating] = useState<number>(5);
  const [reviewText, setReviewText] = useState('');
  const [hpWebsite, setHpWebsite] = useState(''); // honeypot
  
  console.log("ProductDetail - Product ID from URL:", id);
  
  const { data: product, isLoading, error } = useQuery({
    queryKey: ['product', id],
    queryFn: async () => {
      console.log("Fetching product with ID:", id);
      
      if (!id) {
        throw new Error('Product ID is missing');
      }
      
      const { data, error } = await supabase
        .from('products')
        .select('*, product_variants(*), product_images(*)')
        .eq('id', id)
        .single();
      
      if (error) {
        console.error('Error fetching product:', error);
        throw new Error(error.message);
      }
      
      if (!data) {
        throw new Error('Product not found');
      }
      
      console.log("Product data from DB:", data);
      
      // Map the product_variants to variants and product_images to images
      const mappedProduct = {
        ...data,
        variants: Array.isArray(data.product_variants) ? data.product_variants : [],
        images: Array.isArray(data.product_images) ? data.product_images : [],
      };
      
      // Fetch FAQs
      const { data: faqs, error: faqError } = await supabase
        .from('product_faqs')
        .select('*')
        .eq('product_id', id)
        .order('position', { ascending: true });
      if (faqError) {
        console.warn('Error fetching product FAQs:', faqError);
      }

      // Fetch recommended product ids
      const { data: recRows, error: recError } = await supabase
        .from('product_recommendations')
        .select('recommended_product_id, position')
        .eq('product_id', id)
        .order('position', { ascending: true });
      if (recError) {
        console.warn('Error fetching recommendations:', recError);
      }

      const baseProduct = adaptProductForUI({
        ...mappedProduct,
        faqs: Array.isArray(faqs) ? faqs : [],
        recommended_product_ids: Array.isArray(recRows) ? recRows.map(r => r.recommended_product_id) : []
      }) as Product;

      // If we need recommended product details, fetch them
      if (baseProduct.show_recommendations && baseProduct.recommended_product_ids && baseProduct.recommended_product_ids.length > 0) {
        const { data: recProducts, error: recProdErr } = await supabase
          .from('products')
          .select('*, product_variants(*), product_images(*)')
          .in('id', baseProduct.recommended_product_ids);
        if (recProdErr) {
          console.warn('Error fetching recommended products:', recProdErr);
          return baseProduct;
        }
        // Attach adapted recommended products for display convenience
        const adapted = (Array.isArray(recProducts) ? recProducts : []).map(p => adaptProductForUI({
          ...p,
          variants: Array.isArray(p.product_variants) ? p.product_variants : [],
          images: Array.isArray(p.product_images) ? p.product_images : []
        }));
        // @ts-expect-error - recommended_products is not in the base type but used in UI
        baseProduct.recommended_products = adapted;
      }

      return baseProduct as Product;
    },
  });

  const { data: settings } = useQuery2({
    queryKey: ['site-settings'],
    queryFn: fetchSiteSettings,
  });

  const highlightIconMap: Record<string, React.ComponentType<{ className?: string }>> = {
    truck: Truck, package: Package, plane: Plane, rocket: Rocket, clock: Clock,
    shield: Shield, badgecheck: BadgeCheck, award: Award, star: Star, wrench: Wrench,
    headphones: Headphones, messagecircle: MessageCircle, phone: PhoneIcon,
    lifebuoy: LifeBuoy, bot: Bot, sparkles: Sparkles, zap: Zap,
    globe: Globe, lock: Lock, checkcircle: CheckCircle, gift: Gift, leaf: Leaf, crown: Crown,
  };

  const { data: storeHighlights = [] } = useQuery({
    queryKey: ['store-highlights'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('store_highlights')
        .select('*')
        .eq('is_enabled', true)
        .order('position');
      if (error) throw error;
      return data as { id: string; title: string; description: string; icon: string }[];
    },
  });

  const isFavorite = favorites.some(fav => fav.id === product?.id);
  
  const hasVariantOptions = product?.variant_options && product.variant_options.length > 0;

  // Set the first variant as selected by default
  useEffect(() => {
    if (product?.variants && product.variants.length > 0 && !selectedVariantId) {
      if (hasVariantOptions && product.variant_options) {
        // Auto-select first value for each option group
        const defaults: Record<string, string> = {};
        product.variant_options.forEach(group => {
          if (group.values.length > 0) {
            defaults[group.name] = group.values[0];
          }
        });
        setSelectedOptions(defaults);
        // Find matching variant
        const defaultName = product.variant_options.map(g => defaults[g.name]).join(' / ');
        const match = product.variants.find(v => v.variant_name === defaultName);
        if (match) setSelectedVariantId(match.id);
        else setSelectedVariantId(product.variants[0].id);
      } else {
        setSelectedVariantId(product.variants[0].id);
      }
    }
  }, [product, selectedVariantId]);

  // When selectedOptions change, find the matching variant
  useEffect(() => {
    if (!hasVariantOptions || !product?.variants || !product.variant_options) return;
    const allSelected = product.variant_options.every(g => selectedOptions[g.name]);
    if (!allSelected) return;
    const variantName = product.variant_options.map(g => selectedOptions[g.name]).join(' / ');
    const match = product.variants.find(v => v.variant_name === variantName);
    if (match) setSelectedVariantId(match.id);
  }, [selectedOptions, product]);
  
  const selectedVariant = product?.variants?.find(v => v.id === selectedVariantId);
  const formatPrice = (value: number | null | undefined) => {
    if (value == null || Number.isNaN(Number(value))) return 'N/A';
    return `$${Number(value).toFixed(2)}`;
  };
  
  const handleQuantityChange = (value: string) => {
    const newQuantity = parseInt(value);
    if (!isNaN(newQuantity) && newQuantity > 0) {
      setQuantity(newQuantity);
    }
  };
  
  const decrementQuantity = () => {
    if (quantity > 1) {
      setQuantity(quantity - 1);
    }
  };
  
  const incrementQuantity = () => {
    setQuantity(quantity + 1);
  };
  
  const handleAddToCart = () => {
    if (product && selectedVariant) {
      addToCart(product, quantity, selectedVariant);
      
      const variantLabel = selectedVariant.variant_name !== 'Default' 
        ? ` - ${selectedVariant.variant_name}` 
        : '';
      toast({
        title: "Added to cart",
        description: `${product.name}${variantLabel} has been added to your cart.`,
      });
    }
  };
  
  const handleToggleFavorite = () => {
    if (product) {
      toggleFavorite(product);
      
      toast({
        title: isFavorite ? "Removed from favorites" : "Added to favorites",
        description: `${product.name} has been ${isFavorite ? 'removed from' : 'added to'} your favorites.`,
      });
    }
  };
  
  const jsonLd = React.useMemo(() => {
    if (!product) {
      return {
        "@context": "https://schema.org",
        "@type": "Product",
      };
    }
    const variant = selectedVariant ?? product?.variants?.[0] ?? null;
    const images = (product?.images ?? []).map((img) => img.image_url).filter(Boolean);
    const inStock = product?.track_stock
      ? (variant?.stock_quantity ?? 0) > 0
      : true;
    const offerPrice = variant?.price ?? product?.price ?? null;

    return {
      "@context": "https://schema.org",
      "@type": "Product",
      name: product?.name,
      description: product?.description,
      image: images.length ? images : undefined,
      offers: offerPrice != null
        ? {
            "@type": "Offer",
            priceCurrency: "USD",
            price: Number(offerPrice),
            availability: inStock
              ? "https://schema.org/InStock"
              : "https://schema.org/OutOfStock",
            url: `${window.location.origin}/product/${product?.id}`,
          }
        : undefined,
      hasVariant: (product?.variants ?? []).map((v) => ({
        "@type": "Product",
        name: `${product?.name} - ${v.variant_name}`,
        offers: {
          "@type": "Offer",
          priceCurrency: "USD",
          price: Number(v.price),
          availability: product?.track_stock
            ? ((v.stock_quantity ?? 0) > 0 ? "https://schema.org/InStock" : "https://schema.org/OutOfStock")
            : "https://schema.org/InStock",
        },
      })),
    };
  }, [product, selectedVariant]);

  let jsonLdStr = "{}";
  try {
    jsonLdStr = JSON.stringify(jsonLd);
  } catch (e) {
    console.warn("Failed to stringify JSON-LD", e);
  }

  const addReviewMutation = useMutation({
    mutationFn: async () => {
      if (!id) throw new Error('Missing product id');
      if (hpWebsite) throw new Error('spam-detected');
      if (!reviewerName.trim() || !reviewText.trim()) throw new Error('Please fill all fields');
      return createReview({
        product_id: id,
        reviewer_name: reviewerName.trim(),
        rating: reviewRating,
        review_text: reviewText.trim(),
      });
    },
    onSuccess: () => {
      setReviewerName('');
      setReviewRating(5);
      setReviewText('');
      queryClient.invalidateQueries({ queryKey: ['reviews-product', id] });
      const outcome = analyzeReviewContent(reviewRating, reviewText);
      const desc = outcome.status === 'approved'
        ? 'Thanks! Your review is live.'
        : 'Your review is being reviewed by our moderation team.';
      toast({ title: 'Review submitted', description: desc });
    },
    onError: (err: any) => {
      const msg = err?.message === 'spam-detected'
        ? 'Submission blocked'
        : (err?.message || 'Failed to submit review');
      toast({ title: 'Could not submit review', description: msg, variant: 'destructive' });
    }
  });

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="animate-pulse">
          <div className="h-8 bg-muted rounded w-3/4 mb-4"></div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="aspect-square bg-muted rounded"></div>
            <div className="space-y-4">
              <div className="h-4 bg-muted rounded w-1/2"></div>
              <div className="h-4 bg-muted rounded w-3/4"></div>
              <div className="h-4 bg-muted rounded w-2/3"></div>
              <div className="h-10 bg-muted rounded w-1/3 mt-6"></div>
            </div>
          </div>
        </div>
      </div>
    );
  }
  
  if (error || !product) {
    console.error("Error in ProductDetail:", error);
    return (
      <div className="container mx-auto px-4 py-8 text-center">
        <AlertCircle className="h-12 w-12 mx-auto text-destructive mb-4" />
        <h1 className="text-2xl font-bold mb-2">Product Not Found</h1>
        <p className="text-muted-foreground mb-6">
          We couldn't find the product you're looking for.
        </p>
        <Button asChild>
          <Link to="/shop">Continue Shopping</Link>
        </Button>
      </div>
    );
  }

  return (
    <ErrorBoundary>
      <div className="container mx-auto px-4 py-8">
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: jsonLdStr }}
        />
        {/* Breadcrumbs */}
        <div className="flex items-center text-sm text-muted-foreground mb-8">
          <Link to="/" className="hover:text-foreground">Home</Link>
          <ChevronRight className="h-4 w-4 mx-1" />
          <Link to="/shop" className="hover:text-foreground">Shop</Link>
          <ChevronRight className="h-4 w-4 mx-1" />
          <span className="text-foreground">{product.name}</span>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
          {/* Product Images */}
          <div>
            <Carousel className="w-full">
              <CarouselContent>
                {product.images && product.images.map((image) => (
                  <CarouselItem key={image.id}>
                    <div className="aspect-square bg-muted rounded-lg overflow-hidden">
                      <img 
                        src={image.image_url} 
                        alt={image.title || product.name} 
                        className="w-full h-full object-cover"
                      />
                    </div>
                  </CarouselItem>
                ))}
              </CarouselContent>
              <CarouselPrevious className="left-2" />
              <CarouselNext className="right-2" />
            </Carousel>
            
            <div className="flex mt-4 space-x-2 overflow-auto pb-2">
              {product.images && product.images.map((image, index) => (
                <div 
                  key={image.id}
                  className="w-20 h-20 flex-shrink-0 rounded-md overflow-hidden border cursor-pointer"
                >
                  <img 
                    src={image.image_url} 
                    alt={image.title || `${product.name} thumbnail ${index + 1}`} 
                    className="w-full h-full object-cover"
                  />
                </div>
              ))}
            </div>
          </div>
          
          {/* Product Info */}
          <div>
            <h1 className="text-3xl font-bold mb-2">{product.name}</h1>
            
            {/* Price */}
            <div className="flex items-center mb-4">
              {selectedVariant && selectedVariant.compare_at_price != null && selectedVariant.price != null ? (
                <>
                  <span className="text-2xl font-bold text-primary mr-2">
                    {formatPrice(selectedVariant.price)}
                  </span>
                  <span className="text-lg text-muted-foreground line-through">
                    {formatPrice(selectedVariant.compare_at_price)}
                  </span>
                  <Badge className="ml-2 bg-primary">
                    Save {formatPrice(selectedVariant.compare_at_price - selectedVariant.price)}
                  </Badge>
                </>
              ) : (
                <span className="text-2xl font-bold">
                  {formatPrice(selectedVariant?.price ?? product.price)}
                </span>
              )}
            </div>
            
            {/* Product description is shown in the section below if enabled */}
            
            {/* Variant Selector */}
            {product.variants && product.variants.length > 0 && (
              <>
                {hasVariantOptions && product.variant_options ? (
                  /* Grouped variant selectors (e.g., separate Color and Size dropdowns) */
                  <div className="space-y-4 mb-6">
                    {product.variant_options.map((group) => (
                      <div key={group.name}>
                        <label className="block text-sm font-medium mb-2">
                          {group.name}
                        </label>
                        <div className="flex flex-wrap gap-2">
                          {group.values.map((value) => {
                            const isSelected = selectedOptions[group.name] === value;
                            // Check if this option leads to any in-stock variant
                            const testOptions = { ...selectedOptions, [group.name]: value };
                            const matchName = product.variant_options!.map(g => testOptions[g.name] || g.values[0]).join(' / ');
                            const matchVariant = product.variants?.find(v => v.variant_name === matchName);
                            const isOutOfStock = product.track_stock && matchVariant && (matchVariant.stock_quantity ?? 0) <= 0;
                            
                            return (
                              <button
                                key={value}
                                type="button"
                                onClick={() => setSelectedOptions(prev => ({ ...prev, [group.name]: value }))}
                                className={`px-4 py-2 rounded-md border text-sm font-medium transition-colors ${
                                  isSelected 
                                    ? 'bg-primary text-primary-foreground border-primary' 
                                    : 'bg-background text-foreground border-border hover:border-primary/50'
                                } ${isOutOfStock ? 'opacity-50 line-through' : ''}`}
                                disabled={!!isOutOfStock}
                              >
                                {value}
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  /* Standard single dropdown for variants */
                  <div className="mb-6">
                    <label className="block text-sm font-medium mb-2">
                      Variant
                    </label>
                    <Select
                      value={selectedVariantId || ''}
                      onValueChange={setSelectedVariantId}
                    >
                      <SelectTrigger className="w-full">
                        <SelectValue placeholder="Select a variant" />
                      </SelectTrigger>
                      <SelectContent>
                        {product.variants.map(variant => (
                          <SelectItem 
                            key={variant.id} 
                            value={variant.id}
                            disabled={product.track_stock && (variant.stock_quantity ?? 0) <= 0}
                          >
                            {variant.variant_name} 
                            {product.track_stock && (variant.stock_quantity ?? 0) <= 0 && " (Out of Stock)"}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}
              </>
            )}
            
            {/* Quantity Selector */}
            <div className="mb-6">
              <label className="block text-sm font-medium mb-2">
                Quantity
              </label>
              <div className="flex">
                <Button
                  variant="outline"
                  size="icon"
                  onClick={decrementQuantity}
                  disabled={quantity <= 1}
                  className="rounded-r-none"
                >
                  -
                </Button>
                <Input
                  type="number"
                  min="1"
                  value={quantity}
                  onChange={(e) => handleQuantityChange(e.target.value)}
                  className="w-16 text-center rounded-none"
                />
                <Button
                  variant="outline"
                  size="icon"
                  onClick={incrementQuantity}
                  className="rounded-l-none"
                >
                  +
                </Button>
              </div>
            </div>
            
            {/* Stock Status - only show when track_stock is enabled */}
            {product.track_stock && (
              <div className="mb-6">
                {selectedVariant && (
                  (selectedVariant.stock_quantity ?? 0) > 5 ? (
                    <div className="flex items-center text-green-600">
                      <Check className="h-4 w-4 mr-1" />
                      <span>In Stock</span>
                    </div>
                  ) : (selectedVariant.stock_quantity ?? 0) > 0 ? (
                    <div className="flex items-center text-amber-600">
                      <AlertCircle className="h-4 w-4 mr-1" />
                      <span>Low Stock - Only {selectedVariant.stock_quantity} left</span>
                    </div>
                  ) : (
                    <div className="flex items-center text-destructive">
                      <AlertCircle className="h-4 w-4 mr-1" />
                      <span>Out of Stock</span>
                    </div>
                  )
                )}
              </div>
            )}
            
            {/* Add to Cart & Favorite Buttons */}
            <div className="flex flex-wrap gap-4 mb-8">
              <Button 
                size="lg" 
                onClick={handleAddToCart}
                disabled={!selectedVariant || (product.track_stock && (selectedVariant.stock_quantity ?? 0) <= 0)}
                className="flex-1"
              >
                <ShoppingCart className="mr-2 h-5 w-5" />
                Add to Cart
              </Button>
              
              <Button
                variant="outline"
                size="lg"
                onClick={handleToggleFavorite}
                className={`${isFavorite ? 'text-red-500 border-red-500 hover:bg-red-50' : ''}`}
              >
                <Heart className={`h-5 w-5 ${isFavorite ? 'fill-current' : ''}`} />
              </Button>
            </div>

            {/* Micro-trust line */}
            {settings && (
              <div className="flex flex-wrap items-center justify-center gap-6 sm:gap-10 mb-8 text-base font-medium text-foreground">
                {settings.secure_payments_enabled && (
                  <span className="flex items-center gap-2">
                    <Lock className="h-5 w-5" />
                    {settings.secure_payments_text || 'Secure Checkout'}
                  </span>
                )}
                {settings.free_shipping_enabled && (
                  <span className="flex items-center gap-2">
                    <Truck className="h-5 w-5" />
                    {settings.free_shipping_text}
                  </span>
                )}
                <span className="flex items-center gap-2">
                  <Package className="h-5 w-5" />
                  {settings.returns_text || 'Easy Returns'}
                </span>
              </div>
            )}
            
            {/* Product Description (toggleable) */}
            {product.show_description && (
              <div className="border-t pt-6">
                <h2 className="text-xl font-semibold mb-4">Product Description</h2>
                <p className="text-muted-foreground mb-4">{product.description}</p>
              </div>
            )}
          </div>
        </div>
        
        {storeHighlights.length > 0 && (
          <div className="mb-12">
            {settings?.highlights_section_title?.trim() && (
              <div className="text-center mb-10">
                <h2 className="text-2xl md:text-3xl font-bold text-foreground">{settings.highlights_section_title}</h2>
              </div>
            )}
            <div className={`grid grid-cols-1 ${
              storeHighlights.length <= 2 ? 'sm:grid-cols-2' :
              storeHighlights.length <= 3 ? 'sm:grid-cols-2 md:grid-cols-3' :
              storeHighlights.length <= 4 ? 'sm:grid-cols-2 md:grid-cols-4' :
              'sm:grid-cols-2 md:grid-cols-3'
            } gap-6 md:gap-8`}>
              {storeHighlights.map((h) => {
                const IconComp = highlightIconMap[(h.icon || '').toLowerCase()] || Sparkles;
                return (
                  <div
                    key={h.id}
                    className="flex flex-col items-center text-center gap-4 bg-[hsl(0_0%_100%)] rounded-[2.5rem] px-8 py-10 shadow-[0_4px_6px_-1px_rgb(0_0_0/0.04),0_20px_50px_-6px_rgb(0_0_0/0.06)] hover:-translate-y-1.5 hover:shadow-[0_8px_12px_-2px_rgb(0_0_0/0.06),0_25px_60px_-8px_rgb(0_0_0/0.1)] transition-all duration-300 active:scale-[0.98]"
                  >
                    <div className="w-12 h-12 rounded-full bg-muted flex items-center justify-center">
                      <IconComp className="h-5 w-5 text-foreground" />
                    </div>
                    <div>
                      <div className="text-base font-semibold text-foreground">{h.title}</div>
                      {h.description && (
                        <div className="text-sm text-muted-foreground mt-1.5 leading-relaxed">{h.description}</div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
        
        {/* FAQ Section (toggleable) */}
        {product.show_faq && product.faqs && product.faqs.length > 0 && (
          <div className="mb-16">
            <h2 className="text-2xl font-bold mb-6">Frequently Asked Questions</h2>
            <Accordion type="single" collapsible className="w-full">
              {product.faqs.map((f, idx) => (
                <AccordionItem key={f.id || idx} value={`faq-${idx}`}>
                  <AccordionTrigger>{f.question}</AccordionTrigger>
                  <AccordionContent>{f.answer}</AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </div>
        )}
        
        {/* You May Also Like (toggleable) */}
        {product.show_recommendations &&
          // @ts-ignore
          Array.isArray(product.recommended_products) &&
          // @ts-ignore
          product.recommended_products.length > 0 && (
          <div>
            <h2 className="text-2xl font-bold mb-6">You May Also Like</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {
                // @ts-ignore
                product.recommended_products.map((p: Product) => (
                  <ProductCard key={p.id} product={p} />
                ))
              }
            </div>
          </div>
        )}
        
        <div className="mt-12">
          <h2 className="text-2xl font-bold mb-6">Write a Review</h2>
          <div className="border-t pt-6">
            <form
              className="grid grid-cols-1 md:grid-cols-2 gap-4"
              onSubmit={(e) => {
                e.preventDefault();
                addReviewMutation.mutate();
              }}
            >
              <Input
                placeholder="Your name"
                value={reviewerName}
                onChange={(e) => setReviewerName(e.target.value)}
                required
              />
              <div className="flex items-center gap-2">
                <span className="text-sm text-muted-foreground">Rating</span>
                <div className="flex items-center gap-1">
                  {[1,2,3,4,5].map(n => (
                    <button
                      key={n}
                      type="button"
                      onClick={() => setReviewRating(n)}
                      aria-label={`${n} star${n>1?'s':''}`}
                      className="p-0.5"
                    >
                      <Star className={`h-5 w-5 ${n <= reviewRating ? 'text-yellow-500 fill-yellow-500' : 'text-muted-foreground'}`} />
                    </button>
                  ))}
                </div>
              </div>
              <Textarea
                className="md:col-span-2"
                placeholder="Share your experience with this product"
                value={reviewText}
                onChange={(e) => setReviewText(e.target.value)}
                rows={4}
                required
              />
              <Input
                className="hidden"
                tabIndex={-1}
                autoComplete="off"
                value={hpWebsite}
                onChange={(e) => setHpWebsite(e.target.value)}
                aria-hidden="true"
              />
              <div className="md:col-span-2">
                <Button type="submit" disabled={addReviewMutation.isPending}>
                  {addReviewMutation.isPending ? 'Submitting...' : 'Submit Review'}
                </Button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </ErrorBoundary>
  );
};

export default ProductDetail;
