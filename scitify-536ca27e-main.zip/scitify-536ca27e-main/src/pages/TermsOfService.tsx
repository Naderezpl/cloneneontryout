import React, { useEffect, useState } from 'react';
import { fetchPageBySlug } from '@/api/pages';
import Hero from '@/components/Hero';

const TermsOfService = () => {
  const [content, setContent] = useState<{ title: string; html: string; enabled: boolean }>({ title: 'Terms of Service', html: '', enabled: true });

  const contentRef = React.useRef<HTMLDivElement>(null);

  useEffect(() => {
    contentRef.current?.scrollIntoView({ behavior: 'smooth' });
    (async () => {
      try {
        const page = await fetchPageBySlug('terms-of-service');
        if (page && page.enabled) {
          setContent({ title: page.title || 'Terms of Service', html: page.content_html || '', enabled: true });
        } else {
          setContent({ title: 'Terms of Service', html: '', enabled: false });
        }
      } catch {}
    })();
  }, []);

  return (
    <div className="w-full">
      <Hero />
      <div ref={contentRef} className="container mx-auto px-4 py-12">
        <h1 className="text-3xl font-bold mb-6">{content.title}</h1>
        {content.enabled && content.html ? (
          <div className="prose max-w-none text-foreground" dangerouslySetInnerHTML={{ __html: content.html }} />
        ) : (
          <div className="text-muted-foreground">This page is not available.</div>
        )}
      </div>
    </div>
  );
};

export default TermsOfService;
