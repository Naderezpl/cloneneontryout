
import React from 'react';
import { useCart } from '@/contexts/cart';
import EmptyCart from '@/components/cart/EmptyCart';
import CartItemsList from '@/components/cart/CartItemsList';
import OrderSummary from '@/components/cart/OrderSummary';

const Cart = () => {
  const { cart, removeFromCart, updateQuantity, clearCart, getTotalPrice } = useCart();
  const subtotal = getTotalPrice();

  if (cart.length === 0) {
    return <EmptyCart />;
  }

  return (
    <main className="flex-grow container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">Your Cart</h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <CartItemsList 
          cart={cart}
          clearCart={async () => await clearCart()}
          removeFromCart={async (productId) => await removeFromCart(productId)}
          updateQuantity={async (productId, quantity) => await updateQuantity(productId, quantity)}
        />
        
        <OrderSummary 
          subtotal={subtotal}
          hasItems={cart.length > 0}
        />
      </div>
    </main>
  );
};

export default Cart;
