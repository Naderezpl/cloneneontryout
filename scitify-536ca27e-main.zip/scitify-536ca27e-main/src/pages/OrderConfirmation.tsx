
import React, { useEffect, useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { CheckCircle, Package, Clock, Calendar } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';

type OrderDetails = {
  id: string;
  created_at: string;
  status: string;
  total_price: number;
};

const OrderConfirmation = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { isAuthenticated } = useAuth();
  const [orderDetails, setOrderDetails] = useState<OrderDetails | null>(null);
  const selectedPaymentMethod = location.state?.paymentMethod as string | undefined;
  
  // Get the order ID from location state
  const orderId = location.state?.orderId;
  
  // Fetch order details if we have an order ID
  useEffect(() => {
    const fetchOrderDetails = async () => {
      if (!orderId) return;
      
      try {
        const { data, error } = await supabase
          .from('orders')
          .select('*')
          .eq('id', orderId)
          .single();
        
        if (error) throw error;
        
        setOrderDetails(data);
      } catch (error) {
        console.error('Error fetching order details:', error);
      }
    };
    
    fetchOrderDetails();
  }, [orderId]);
  
  // Redirect to home if no order ID and not coming from checkout
  useEffect(() => {
    if (!orderId && !location.state?.fromCheckout) {
      navigate('/');
    }
  }, [orderId, location.state, navigate]);
  
  // Generate estimated delivery date (7-10 days from now)
  const today = new Date();
  const deliveryStart = new Date(today);
  deliveryStart.setDate(today.getDate() + 7);
  const deliveryEnd = new Date(today);
  deliveryEnd.setDate(today.getDate() + 10);
  const formatDate = (date: Date) => date.toLocaleDateString('en-US', { month: 'long', day: 'numeric' });
  const estimatedDelivery = `${formatDate(deliveryStart)} - ${formatDate(deliveryEnd)}`;
  
  // Use the actual order ID if available, otherwise generate a fake one
  const displayOrderId = orderDetails?.id
    ? orderDetails.id.slice(-6)
    : `ORD-${Math.floor(100000 + Math.random() * 900000)}`;
  
  // Use the actual order date if available, otherwise use today
  const orderDate = orderDetails?.created_at
    ? new Date(orderDetails.created_at)
    : today;
  
  const paymentLabel = selectedPaymentMethod === 'whish-money'
    ? 'Whish Money'
    : selectedPaymentMethod === 'omt'
    ? 'OMT'
    : selectedPaymentMethod === 'cod'
    ? 'Cash On Delivery (COD)'
    : selectedPaymentMethod === 'crypto-usdt'
    ? 'Crypto (USDT)'
    : 'Credit Card';

  return (
    <div className="flex flex-col min-h-screen">
      <main className="flex-grow container mx-auto px-4 py-12">
        <div className="max-w-2xl mx-auto text-center">
          <CheckCircle className="w-16 h-16 mx-auto mb-4 text-green-500" />
          <h1 className="text-3xl font-bold mb-2">Order Confirmed!</h1>
          <p className="text-muted-foreground mb-8">
            Thank you for your order. We've received your purchase and will prepare it for shipping soon.
          </p>
          
          <div className="bg-muted rounded-lg p-6 mb-8">
            <h2 className="text-lg font-medium mb-4">Order Information</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="text-left">
                <p className="text-sm text-muted-foreground mb-1">Order Number</p>
                <p className="font-medium">#{displayOrderId}</p>
              </div>
              <div className="text-left">
                <p className="text-sm text-muted-foreground mb-1">Order Date</p>
                <p className="font-medium">{orderDate.toLocaleDateString('en-US', { 
                  year: 'numeric', 
                  month: 'long', 
                  day: 'numeric' 
                })}</p>
              </div>
              <div className="text-left">
                <p className="text-sm text-muted-foreground mb-1">Payment Method</p>
                <p className="font-medium">{paymentLabel}</p>
              </div>
              <div className="text-left">
                <p className="text-sm text-muted-foreground mb-1">Order Status</p>
                <p className="font-medium capitalize">{orderDetails?.status || 'Pending'}</p>
              </div>
              {orderDetails && (
                <div className="text-left md:col-span-2">
                  <p className="text-sm text-muted-foreground mb-1">Total Amount</p>
                  <p className="font-medium">${orderDetails.total_price.toFixed(2)}</p>
                </div>
              )}
            </div>
          </div>
          
          <div className="space-y-8 mb-8">
            <h2 className="text-xl font-medium">What Happens Next?</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-background rounded-lg p-6 shadow-sm border">
                <Clock className="w-10 h-10 mb-4 text-blue-500" />
                <h3 className="font-medium mb-2">Processing</h3>
                <p className="text-sm text-muted-foreground">
                  Your order is being processed and prepared for shipping.
                </p>
              </div>
              
              <div className="bg-background rounded-lg p-6 shadow-sm border">
                <Package className="w-10 h-10 mb-4 text-purple-500" />
                <h3 className="font-medium mb-2">Shipping</h3>
                <p className="text-sm text-muted-foreground">
                  You'll receive a shipping confirmation email with tracking information.
                </p>
              </div>
              
              <div className="bg-background rounded-lg p-6 shadow-sm border">
                <Calendar className="w-10 h-10 mb-4 text-green-500" />
                <h3 className="font-medium mb-2">Delivery</h3>
                <p className="text-sm text-muted-foreground">
                  Estimated delivery: {estimatedDelivery}
                </p>
              </div>
            </div>
          </div>
          
          {selectedPaymentMethod && selectedPaymentMethod !== 'cod' && (
            <div className="mb-8 rounded-lg border border-primary/30 bg-muted/50 p-6">
              <p className="text-sm text-muted-foreground mb-4">
                Your order number is <span className="font-semibold text-foreground">#{displayOrderId}</span>.
                Continue to the payment page for the transfer details — remember to include this
                order number when sending the money.
              </p>
              <Button
                size="lg"
                onClick={() =>
                  navigate('/payment', {
                    state: {
                      orderId,
                      paymentMethod: selectedPaymentMethod,
                      total: orderDetails?.total_price ?? location.state?.total,
                      usdtAddress: location.state?.usdtAddress,
                    },
                  })
                }
              >
                Continue to Payment
              </Button>
            </div>
          )}

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Button asChild variant="outline" size="lg" className="w-full sm:w-auto">
              <Link to="/shop">Continue Shopping</Link>
            </Button>
          </div>

        </div>
      </main>
    </div>
  );
};

export default OrderConfirmation;
