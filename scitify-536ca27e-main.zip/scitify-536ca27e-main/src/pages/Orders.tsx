import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';

type OrderRow = {
  id: string;
  user_id: string;
  status: string;
  total_price: number;
  created_at: string;
};

const Orders = () => {
  const { isAuthenticated, user } = useAuth();

  const { data: orders = [], isLoading, error } = useQuery({
    queryKey: ['my-orders', user?.id],
    queryFn: async () => {
      if (!isAuthenticated || !user) {
        return [];
      }
      const { data, error } = await supabase
        .from('orders')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });
      if (error) throw error;
      return (data || []) as OrderRow[];
    }
  });

  if (!isAuthenticated) {
    return <div className="container mx-auto px-4 py-8 text-center">Please sign in to view your orders.</div>;
  }
  if (isLoading) {
    return <div className="container mx-auto px-4 py-8 text-center">Loading your orders...</div>;
  }
  if (error) {
    return <div className="container mx-auto px-4 py-8 text-center">Failed to load orders.</div>;
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">My Orders</h1>
      <Card>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Order ID</TableHead>
                <TableHead>Date</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Total</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {orders.map((order: OrderRow) => (
                <TableRow key={order.id}>
                  <TableCell>#{order.id.slice(-6)}</TableCell>
                  <TableCell>{new Date(order.created_at).toLocaleDateString()}</TableCell>
                  <TableCell>{order.status}</TableCell>
                  <TableCell>${Number(order.total_price).toFixed(2)}</TableCell>
                </TableRow>
              ))}
              {orders.length === 0 && (
                <TableRow>
                  <TableCell colSpan={4} className="text-center py-6">No orders found</TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
};

export default Orders;
