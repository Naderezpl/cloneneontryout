
import React, { useState, useEffect } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { Search, Filter, X, ArrowUpDown, Check, Tag, DollarSign, SlidersHorizontal } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import {
  DropdownMenu,
  DropdownMenuCheckboxItem,
  DropdownMenuContent,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Badge } from '@/components/ui/badge';
import { useIsMobile } from '@/hooks/use-mobile';
import { Separator } from '@/components/ui/separator';
import ProductCard from '@/components/ProductCard';
import { supabase } from '@/lib/supabase';
import { Product, adaptProductForUI } from '@/types/product';
import { Card } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import {
  SidebarProvider,
  Sidebar,
  SidebarContent,
  SidebarHeader,
  SidebarTrigger,
  SidebarGroup,
  SidebarGroupLabel,
  SidebarGroupContent,
} from "@/components/ui/sidebar";
import { Skeleton } from '@/components/ui/skeleton';
import { getProductMinPrice } from '@/api/products';

export interface ProductFilters {
  search: string;
  sort: string;
  showInStock: boolean | null;
  priceRange: [number, number];
}

const Shop = () => {
  const { data: categories = [], isLoading: categoriesLoading } = useQuery({
    queryKey: ['categories'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('categories')
        .select('*');
      
      if (error) {
        console.error('Error fetching categories:', error);
        return [];
      }
      
      return data;
    }
  });

  const [searchParams, setSearchParams] = useSearchParams();
  const [searchQuery, setSearchQuery] = useState(searchParams.get('search') || '');
  const [sortOrder, setSortOrder] = useState(searchParams.get('sort') || 'name-asc');
  const [selectedCategories, setSelectedCategories] = useState<string[]>(() => {
    // Support both ?category=id (singular, from CategoryCard/homepage) and ?categories=id1,id2 (plural)
    const singular = searchParams.get('category');
    const plural = searchParams.get('categories');
    if (plural) return plural.split(',');
    if (singular) return [singular];
    return [];
  });
  const [showOnSaleOnly, setShowOnSaleOnly] = useState(searchParams.get('sale') === 'true');
  const [minPrice, setMinPrice] = useState(searchParams.get('minPrice') ? parseInt(searchParams.get('minPrice')!) : 0);
  const [maxPrice, setMaxPrice] = useState(searchParams.get('maxPrice') ? parseInt(searchParams.get('maxPrice')!) : 5000);
  const [priceRange, setPriceRange] = useState<[number, number]>([minPrice, maxPrice]);
  const [maxPossiblePrice, setMaxPossiblePrice] = useState(5000);
  const isMobile = useIsMobile();
  const [isFilterOpen, setIsFilterOpen] = useState(false);

  useEffect(() => {
    const fetchMaxPrice = async () => {
      const { data, error } = await supabase
        .from('product_variants')
        .select('price')
        .order('price', { ascending: false })
        .limit(1);
      
      if (!error && data && data.length > 0) {
        const highestPrice = Math.ceil(data[0].price);
        const roundedMax = Math.ceil(highestPrice / 1000) * 1000;
        setMaxPossiblePrice(roundedMax);
        
        if (!searchParams.get('maxPrice')) {
          setMaxPrice(roundedMax);
          setPriceRange(prevRange => [prevRange[0], roundedMax]);
        }
      }
    };

    fetchMaxPrice();
  }, [searchParams]);

  const { data: products = [], isLoading: productsLoading, error } = useQuery({
    queryKey: ['products', searchQuery, sortOrder, selectedCategories, showOnSaleOnly, priceRange],
    queryFn: async () => {
      console.log('Fetching products...');
      let query = supabase
        .from('products')
        .select('*, product_variants(*), product_images(*)')
        .eq('is_hidden', false); // Add this line to filter out hidden products

      if (searchQuery) {
        query = query.ilike('name', `%${searchQuery}%`);
      }

      if (selectedCategories.length > 0) {
        query = query.in('category_id', selectedCategories);
      }

      if (showOnSaleOnly) {
        query = query.eq('is_on_sale', true);
      }

      const [field, order] = sortOrder.split('-');
      if (field === 'name') {
        query = query.order(field, { ascending: order === 'asc' });
      }

      const { data, error } = await query;

      if (error) {
        console.error('Error fetching products:', error);
        return [];
      }
      
      const mappedProducts = (data || []).map(product => {
        return {
          ...product,
          variants: product.product_variants,
          images: product.product_images
        };
      });

      let adaptedProducts = mappedProducts.map(product => adaptProductForUI(product)) as Product[];
      
      adaptedProducts = adaptedProducts.filter(product => {
        const productPrice = getProductMinPrice(product);
        return productPrice >= priceRange[0] && productPrice <= priceRange[1];
      });

      if (field === 'price') {
        adaptedProducts.sort((a, b) => {
          const priceA = getProductMinPrice(a);
          const priceB = getProductMinPrice(b);
          
          return order === 'asc' ? priceA - priceB : priceB - priceA;
        });
      }

      return adaptedProducts;
    },
  });

  useEffect(() => {
    const newParams = new URLSearchParams();
    if (searchQuery) newParams.set('search', searchQuery);
    if (sortOrder) newParams.set('sort', sortOrder);
    if (selectedCategories.length) newParams.set('categories', selectedCategories.join(','));
    if (showOnSaleOnly) newParams.set('sale', 'true');
    newParams.set('minPrice', priceRange[0].toString());
    newParams.set('maxPrice', priceRange[1].toString());

    setSearchParams(newParams, { replace: true });
  }, [searchQuery, sortOrder, selectedCategories, showOnSaleOnly, priceRange, setSearchParams]);

  const handleCategoryChange = (categoryId: string) => {
    setSelectedCategories((prev) => {
      if (prev.includes(categoryId)) {
        return prev.filter((id) => id !== categoryId);
      } else {
        return [...prev, categoryId];
      }
    });
  };

  const handleSelectAllCategories = () => {
    setSelectedCategories([]);
  };

  const handleApplyPriceRange = () => {
    let min = Math.max(0, minPrice);
    let max = Math.min(maxPossiblePrice, maxPrice);
    
    if (min > max) {
      [min, max] = [max, min];
      setMinPrice(min);
      setMaxPrice(max);
    }
    
    setPriceRange([min, max]);
  };

  const clearFilters = () => {
    setSelectedCategories([]);
    setSearchQuery('');
    setSortOrder('name-asc');
    setShowOnSaleOnly(false);
    setMinPrice(0);
    setMaxPrice(maxPossiblePrice);
    setPriceRange([0, maxPossiblePrice]);
  };
  
  const getCategoryName = (categoryId: string) => {
    const category = categories.find(cat => cat.id === categoryId);
    return category ? category.name : 'Unknown Category';
  };

  const formatPrice = (price: number) => {
    return `$${price.toLocaleString()}`;
  };

  const activeFilterCount = (
    (selectedCategories.length > 0 ? 1 : 0) + 
    (showOnSaleOnly ? 1 : 0) + 
    ((priceRange[0] > 0 || priceRange[1] < maxPossiblePrice) ? 1 : 0)
  );

  const FilterSidebar = () => (
    <div className="w-72 mr-6 flex-shrink-0">
      <Card className="sticky top-8 overflow-auto max-h-[calc(100vh-4rem)] bg-background/95 backdrop-blur-sm border border-border/50 rounded-xl shadow-lg">
        <div className="p-4 border-b border-border/30">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-xl font-semibold flex items-center">
              <SlidersHorizontal className="h-5 w-5 mr-2 text-primary" />
              Filters
            </h3>
            {activeFilterCount > 0 && (
              <Badge className="bg-primary hover:bg-primary/90">{activeFilterCount}</Badge>
            )}
          </div>
          <div className="relative">
            <Input
              type="text"
              placeholder="Search products..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" />
          </div>
        </div>
        
        <div className="p-4">
          <Accordion type="multiple" defaultValue={["price", "categories", "sort", "stock"]}>
            <AccordionItem value="price" className="border-none">
              <AccordionTrigger className="py-3 hover:no-underline">
                <span className="flex items-center text-base font-medium">
                  <DollarSign className="h-4 w-4 mr-2 text-primary" />
                  Price Range
                </span>
              </AccordionTrigger>
              <AccordionContent>
                <div className="space-y-4 pt-2">
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label htmlFor="min-price" className="text-sm text-muted-foreground mb-1 block">
                        Min Price
                      </label>
                      <Input
                        id="min-price"
                        type="number"
                        min={0}
                        value={minPrice}
                        onChange={(e) => setMinPrice(Number(e.target.value))}
                        placeholder="Min"
                      />
                    </div>
                    <div>
                      <label htmlFor="max-price" className="text-sm text-muted-foreground mb-1 block">
                        Max Price
                      </label>
                      <Input
                        id="max-price"
                        type="number"
                        min={0}
                        value={maxPrice}
                        onChange={(e) => setMaxPrice(Number(e.target.value))}
                        placeholder="Max"
                      />
                    </div>
                  </div>
                  <Button 
                    onClick={handleApplyPriceRange}
                    size="sm"
                    className="w-full"
                  >
                    Apply
                  </Button>
                </div>
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="categories" className="border-none">
              <AccordionTrigger className="py-3 hover:no-underline">
                <span className="flex items-center text-base font-medium">
                  <Tag className="h-4 w-4 mr-2 text-primary" />
                  Categories
                </span>
              </AccordionTrigger>
              <AccordionContent>
                <div className="space-y-3 pt-2">
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="all-categories"
                      checked={selectedCategories.length === 0}
                      onCheckedChange={handleSelectAllCategories}
                      className="data-[state=checked]:bg-primary data-[state=checked]:border-primary"
                    />
                    <label 
                      htmlFor="all-categories"
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 hover:text-primary transition-colors"
                    >
                      All Categories
                    </label>
                  </div>
                  
                  {categories.map((category) => (
                    <div key={category.id} className="flex items-center space-x-2">
                      <Checkbox 
                        id={`category-${category.id}`}
                        checked={selectedCategories.includes(category.id)}
                        onCheckedChange={() => handleCategoryChange(category.id)}
                        className="data-[state=checked]:bg-primary data-[state=checked]:border-primary"
                      />
                      <label 
                        htmlFor={`category-${category.id}`}
                        className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 hover:text-primary transition-colors"
                      >
                        {category.name}
                      </label>
                    </div>
                  ))}
                </div>
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="sort" className="border-none">
              <AccordionTrigger className="py-3 hover:no-underline">
                <span className="flex items-center text-base font-medium">
                  <ArrowUpDown className="h-4 w-4 mr-2 text-primary" />
                  Sort By
                </span>
              </AccordionTrigger>
              <AccordionContent>
                <div className="space-y-2 pt-2">
                  {[
                    { label: 'Name (A-Z)', value: 'name-asc' },
                    { label: 'Name (Z-A)', value: 'name-desc' },
                    { label: 'Price (Low to High)', value: 'price-asc' },
                    { label: 'Price (High to Low)', value: 'price-desc' }
                  ].map((option) => (
                    <div key={option.value} className="flex items-center space-x-2">
                      <Checkbox 
                        id={`sort-${option.value}`}
                        checked={sortOrder === option.value}
                        onCheckedChange={() => setSortOrder(option.value)}
                        className="data-[state=checked]:bg-primary data-[state=checked]:border-primary"
                      />
                      <label 
                        htmlFor={`sort-${option.value}`}
                        className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                      >
                        {option.label}
                      </label>
                    </div>
                  ))}
                </div>
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="stock" className="border-none">
              <AccordionTrigger className="py-3 hover:no-underline">
                <span className="flex items-center text-base font-medium">
                  <Check className="h-4 w-4 mr-2 text-primary" />
                  Stock Status
                </span>
              </AccordionTrigger>
              <AccordionContent>
                <div className="pt-2">
            <div className="flex items-center space-x-2">
              <Checkbox 
                id="sale-items"
                checked={showOnSaleOnly}
                onCheckedChange={(checked) => setShowOnSaleOnly(checked === true)}
                className="data-[state=checked]:bg-primary border-primary/30 data-[state=checked]:border-primary"
              />
              <label 
                htmlFor="sale-items"
                className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 flex items-center group"
              >
                <Tag className="h-4 w-4 mr-2 text-primary group-hover:scale-110 transition-transform" />
                <span className="group-hover:text-primary transition-colors">Show Sale Items Only</span>
              </label>
            </div>
                </div>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
          
          {(selectedCategories.length > 0 || showOnSaleOnly || priceRange[0] > 0 || priceRange[1] < maxPossiblePrice) && (
            <div className="pt-4 mt-2 border-t border-border/30">
              <Button 
                variant="outline" 
                size="sm" 
                onClick={clearFilters} 
                className="w-full text-muted-foreground hover:text-foreground transition-colors"
              >
                <X className="h-3.5 w-3.5 mr-1" />
                Clear All Filters
              </Button>
            </div>
          )}
        </div>
      </Card>
    </div>
  );

  const ActiveFilters = () => {
    if (!(selectedCategories.length > 0 || showOnSaleOnly || priceRange[0] > 0 || priceRange[1] < maxPossiblePrice)) {
      return null;
    }
    
    return (
      <div className="mb-6 bg-background/50 backdrop-blur-sm border border-border/30 rounded-lg p-3 animate-fade-in">
        <div className="flex flex-wrap gap-2 items-center">
          <span className="text-sm text-muted-foreground mr-2">Active filters:</span>
          
          {selectedCategories.map(categoryId => (
            <Badge key={categoryId} variant="outline" className="flex items-center gap-1 py-1 px-3 bg-muted/30 hover:bg-muted transition-colors">
              {getCategoryName(categoryId)}
              <X
                className="h-3 w-3 cursor-pointer ml-1 text-muted-foreground hover:text-foreground"
                onClick={() => handleCategoryChange(categoryId)}
              />
            </Badge>
          ))}
          
          {showOnSaleOnly && (
            <Badge variant="outline" className="flex items-center gap-1 py-1 px-3 bg-primary/10 border-primary/20 hover:bg-primary/20 transition-colors">
              <Tag className="h-3 w-3 text-primary" />
              On Sale
              <X
                className="h-3 w-3 cursor-pointer ml-1 text-primary/70 hover:text-primary"
                onClick={() => setShowOnSaleOnly(false)}
              />
            </Badge>
          )}
          
          {(priceRange[0] > 0 || priceRange[1] < maxPossiblePrice) && (
            <Badge variant="outline" className="flex items-center gap-1 py-1 px-3 bg-primary/10 border-primary/20 hover:bg-primary/20 transition-colors">
              <DollarSign className="h-3 w-3 text-primary" />
              {formatPrice(priceRange[0])} - {formatPrice(priceRange[1])}
              <X
                className="h-3 w-3 cursor-pointer ml-1 text-primary/70 hover:text-primary"
                onClick={() => {
                  setMinPrice(0);
                  setMaxPrice(maxPossiblePrice);
                  setPriceRange([0, maxPossiblePrice]);
                }}
              />
            </Badge>
          )}
        </div>
      </div>
    );
  };

  const ProductsGridSkeleton = () => (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
      {Array(8).fill(0).map((_, i) => (
        <Card key={i} className="overflow-hidden">
          <div className="aspect-square w-full">
            <Skeleton className="h-full w-full" />
          </div>
          <div className="p-4 space-y-3">
            <Skeleton className="h-5 w-3/4" />
            <Skeleton className="h-4 w-1/2" />
            <Skeleton className="h-10 w-full" />
          </div>
        </Card>
      ))}
    </div>
  );

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">Shop Tech &amp; Accessories</h1>
        
        {isMobile && (
          <>
            <div className="flex items-center space-x-2">
              <div className="relative flex-1">
                <Input
                  type="text"
                  placeholder="Search..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-8 h-9"
                />
                <Search className="absolute left-2.5 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
              </div>
              
              <Sheet open={isFilterOpen} onOpenChange={setIsFilterOpen}>
                <SheetTrigger asChild>
                  <Button variant="outline" size="sm" className="relative">
                    <Filter className="h-4 w-4" />
                    {activeFilterCount > 0 && (
                      <Badge className="absolute -top-2 -right-2 h-5 w-5 p-0 flex items-center justify-center text-[10px]">{activeFilterCount}</Badge>
                    )}
                  </Button>
                </SheetTrigger>
                <SheetContent side="bottom" className="sm:max-w-md sm:side-left">
                  <SheetHeader>
                    <SheetTitle>Filters</SheetTitle>
                  </SheetHeader>
                  <div className="py-4">
                    <div className="mb-6">
                      <h3 className="text-lg font-medium mb-4">Price Range</h3>
                      <div className="space-y-4">
                        <div className="grid grid-cols-2 gap-2">
                          <div>
                            <label htmlFor="min-price-mobile" className="text-sm text-muted-foreground mb-1 block">
                              Min Price
                            </label>
                            <Input
                              id="min-price-mobile"
                              type="number"
                              min={0}
                              value={minPrice}
                              onChange={(e) => setMinPrice(Number(e.target.value))}
                              placeholder="Min"
                            />
                          </div>
                          <div>
                            <label htmlFor="max-price-mobile" className="text-sm text-muted-foreground mb-1 block">
                              Max Price
                            </label>
                            <Input
                              id="max-price-mobile"
                              type="number"
                              min={0}
                              value={maxPrice}
                              onChange={(e) => setMaxPrice(Number(e.target.value))}
                              placeholder="Max"
                            />
                          </div>
                        </div>
                        <Button 
                          onClick={handleApplyPriceRange}
                          className="w-full"
                        >
                          Apply Price Range
                        </Button>
                      </div>
                    </div>

                    <div className="mb-4">
                      <h3 className="text-lg font-medium mb-2">Categories</h3>
                      <div className="space-y-2">
                        <div className="flex items-center space-x-2">
                          <Checkbox 
                            id="all-categories"
                            checked={selectedCategories.length === 0}
                            onCheckedChange={handleSelectAllCategories}
                            className="data-[state=checked]:bg-primary data-[state=checked]:border-primary"
                          />
                          <label 
                            htmlFor="all-categories"
                            className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 hover:text-primary transition-colors"
                          >
                            All Categories
                          </label>
                        </div>
                        
                        {categories.map((category) => (
                          <div key={category.id} className="flex items-center space-x-2">
                            <Checkbox 
                              id={`category-${category.id}`}
                              checked={selectedCategories.includes(category.id)}
                              onCheckedChange={() => handleCategoryChange(category.id)}
                              className="data-[state=checked]:bg-primary data-[state=checked]:border-primary"
                            />
                            <label 
                              htmlFor={`category-${category.id}`}
                              className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 hover:text-primary transition-colors"
                            >
                              {category.name}
                            </label>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="mb-4">
                      <div className="flex items-center space-x-2">
                        <Checkbox 
                          id="sale-items-mobile"
                          checked={showOnSaleOnly}
                          onCheckedChange={(checked) => setShowOnSaleOnly(checked === true)}
                        />
                        <label 
                          htmlFor="sale-items-mobile"
                          className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          Show Sale Items Only
                        </label>
                      </div>
                    </div>

                    <div className="mb-4">
                      <h3 className="text-lg font-medium mb-2">Sort By</h3>
                      <div className="space-y-2">
                        {[
                          { label: 'Name (A-Z)', value: 'name-asc' },
                          { label: 'Name (Z-A)', value: 'name-desc' },
                          { label: 'Price (Low to High)', value: 'price-asc' },
                          { label: 'Price (High to Low)', value: 'price-desc' }
                        ].map((option) => (
                          <div key={option.value} className="flex items-center space-x-2">
                            <Checkbox 
                              id={`sort-${option.value}`}
                              checked={sortOrder === option.value}
                              onCheckedChange={() => setSortOrder(option.value)}
                            />
                            <label 
                              htmlFor={`sort-${option.value}`}
                              className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                            >
                              {option.label}
                            </label>
                          </div>
                        ))}
                      </div>
                    </div>

                    <Button variant="secondary" className="w-full" onClick={clearFilters}>
                      Clear Filters
                    </Button>
                  </div>
                </SheetContent>
              </Sheet>
              
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="sm">
                    <ArrowUpDown className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuLabel>Sort By</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  {[
                    { label: 'Name (A-Z)', value: 'name-asc' },
                    { label: 'Name (Z-A)', value: 'name-desc' },
                    { label: 'Price (Low to High)', value: 'price-asc' },
                    { label: 'Price (High to Low)', value: 'price-desc' }
                  ].map((option) => (
                    <DropdownMenuCheckboxItem
                      key={option.value}
                      checked={sortOrder === option.value}
                      onCheckedChange={() => setSortOrder(option.value)}
                    >
                      {option.label}
                    </DropdownMenuCheckboxItem>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </>
        )}
      </div>

      <Separator className="mb-6" />

      <div className="flex flex-col md:flex-row">
        {!isMobile && <FilterSidebar />}
        
        <div className="flex-1">
          <ActiveFilters />
          
          {productsLoading ? (
            <ProductsGridSkeleton />
          ) : products.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {products.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <h3 className="text-lg font-medium mb-2">No products found</h3>
              <p className="text-muted-foreground">
                Try adjusting your search or filter criteria
              </p>
              <Button variant="outline" onClick={clearFilters} className="mt-4">
                Clear Filters
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Shop;
