
import React, { useEffect } from 'react';
import FeaturedProducts from '@/components/FeaturedProducts';
import OnSaleProducts from '@/components/OnSaleProducts';
import Testimonials from '@/components/Testimonials';
import Newsletter from '@/components/Newsletter';
import Hero from '@/components/Hero';
import Categories from '@/components/Categories';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { fetchSiteSettings } from '@/api/settings';
import { supabase } from '@/lib/supabase';
import { Truck, Shield, Headphones, Sparkles, Package, Plane, Rocket, Clock, BadgeCheck, Award, Star, Wrench, MessageCircle, Phone as PhoneIcon, LifeBuoy, Bot, Heart, Zap, Globe, Lock, CheckCircle, Gift, Leaf, Crown } from 'lucide-react';
import HomeReviewSection from '@/components/HomeReviewSection';

const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  truck: Truck, package: Package, plane: Plane, rocket: Rocket, clock: Clock,
  shield: Shield, badgecheck: BadgeCheck, award: Award, star: Star, wrench: Wrench,
  headphones: Headphones, messagecircle: MessageCircle, phone: PhoneIcon,
  lifebuoy: LifeBuoy, bot: Bot, sparkles: Sparkles, heart: Heart, zap: Zap,
  globe: Globe, lock: Lock, checkcircle: CheckCircle, gift: Gift, leaf: Leaf, crown: Crown,
};

const getIcon = (name?: string | null) => {
  const IconComp = iconMap[(name || '').toLowerCase()] || Sparkles;
  return <IconComp className="h-5 w-5 text-foreground" />;
};

interface StoreHighlight {
  id: string;
  title: string;
  description: string;
  icon: string;
  is_enabled: boolean;
  position: number;
}

const DEFAULT_ORDER = ['hero','categories','highlights','featured','onsale','about','testimonials','reviews','promotions','newsletter'];

const Index = () => {
  const queryClient = useQueryClient();
  
  useEffect(() => {
    queryClient.invalidateQueries({ queryKey: ['site-settings'] });
  }, [queryClient]);
  
  const { data: settings, isLoading } = useQuery({
    queryKey: ['site-settings'],
    queryFn: fetchSiteSettings,
    refetchOnMount: true,
    staleTime: 0
  });

  const { data: highlights = [] } = useQuery({
    queryKey: ['store-highlights'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('store_highlights')
        .select('*')
        .eq('is_enabled', true)
        .order('position');
      if (error) throw error;
      return data as StoreHighlight[];
    },
  });

  const sectionOrder = settings?.homepage_section_order && Array.isArray(settings.homepage_section_order)
    ? settings.homepage_section_order
    : DEFAULT_ORDER;

  const gridCols = highlights.length <= 2
    ? 'sm:grid-cols-2'
    : highlights.length <= 3
      ? 'sm:grid-cols-2 md:grid-cols-3'
      : highlights.length <= 4
        ? 'sm:grid-cols-2 md:grid-cols-4'
        : 'sm:grid-cols-2 md:grid-cols-3';

  const renderSection = (key: string) => {
    switch (key) {
      case 'hero':
        return <Hero key={key} />;
      case 'categories':
        return <Categories key={key} />;
      case 'highlights':
        return highlights.length > 0 ? (
          <section key={key} className="py-16 md:py-24 bg-background">
            <div className="container mx-auto px-4">
              {settings?.highlights_section_title?.trim() && (
                <div className="text-center mb-10">
                  <h2 className="text-2xl md:text-3xl font-bold text-foreground">{settings.highlights_section_title}</h2>
                </div>
              )}
              <div className={`grid grid-cols-1 ${gridCols} gap-6 md:gap-8 max-w-5xl mx-auto`}>
                {highlights.map((h) => (
                  <div
                    key={h.id}
                    className="flex flex-col items-center text-center gap-4 bg-[hsl(0_0%_100%)] rounded-[2.5rem] px-8 py-10 shadow-[0_4px_6px_-1px_rgb(0_0_0/0.04),0_20px_50px_-6px_rgb(0_0_0/0.06)] hover:-translate-y-1.5 hover:shadow-[0_8px_12px_-2px_rgb(0_0_0/0.06),0_25px_60px_-8px_rgb(0_0_0/0.1)] transition-all duration-300 active:scale-[0.98]"
                  >
                    <div className="w-12 h-12 rounded-full bg-muted flex items-center justify-center">
                      {getIcon(h.icon)}
                    </div>
                    <div>
                      <div className="text-base font-semibold text-foreground">{h.title}</div>
                      {h.description && (
                        <div className="text-sm text-muted-foreground mt-1.5 leading-relaxed">{h.description}</div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>
        ) : null;
      case 'featured':
        return !isLoading && settings?.show_featured_products !== false ? <FeaturedProducts key={key} /> : null;
      case 'onsale':
        return !isLoading && settings?.show_on_sale_products !== false ? <OnSaleProducts key={key} /> : null;
      case 'about':
        return !isLoading && settings?.show_about_section && settings?.about_section_html ? (
          <section key={key} className="bg-background py-20 md:py-28">
            <div className="container mx-auto px-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-16 lg:gap-24 items-center max-w-6xl mx-auto">
                {settings.about_section_image_url && (
                  <div className="order-first rounded-3xl overflow-hidden shadow-[0_4px_6px_-1px_rgb(0_0_0/0.04),0_20px_50px_-6px_rgb(0_0_0/0.1)] transition-shadow duration-300 hover:shadow-[0_8px_12px_-2px_rgb(0_0_0/0.06),0_25px_60px_-8px_rgb(0_0_0/0.12)]">
                    <img
                      src={settings.about_section_image_url}
                      alt="About us"
                      className="w-full h-auto object-cover aspect-[4/5]"
                      loading="lazy"
                    />
                  </div>
                )}
                <div className={`flex flex-col justify-center ${!settings.about_section_image_url ? 'md:col-span-2 max-w-2xl mx-auto text-center' : ''}`}>
                  <h2 className="text-3xl md:text-4xl font-bold tracking-tight text-foreground mb-6 leading-[1.1]">
                    {settings?.about_section_title || 'Our Story'}
                  </h2>
                  <div
                    className="prose prose-lg max-w-none text-muted-foreground [&>p]:leading-relaxed [&>p]:mb-4 [&>h2]:text-foreground [&>h3]:text-foreground"
                    dangerouslySetInnerHTML={{ __html: settings.about_section_html }}
                  />
                </div>
              </div>
            </div>
          </section>
        ) : null;
      case 'testimonials':
        return !isLoading && settings?.show_testimonials_section !== false ? <Testimonials key={key} /> : null;
      case 'reviews':
        return <HomeReviewSection key={key} />;
      case 'promotions':
        return !isLoading && settings?.show_promotions_section && settings?.promotions_html ? (
          <section key={key} className="py-10 bg-muted">
            <div className="container mx-auto px-4">
              <div
                className="prose prose-sm max-w-none text-center"
                dangerouslySetInnerHTML={{ __html: settings.promotions_html }}
              />
            </div>
          </section>
        ) : null;
      case 'newsletter':
        return !isLoading && settings?.show_social_section !== false ? <Newsletter key={key} /> : null;
      default:
        return null;
    }
  };

  return (
    <div className="w-full">
      {sectionOrder.map(renderSection)}
    </div>
  );
};

export default Index;
