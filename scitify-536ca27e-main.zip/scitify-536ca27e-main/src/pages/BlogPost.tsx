
import React, { useEffect, useState } from 'react';
import { Link, useParams, useNavigate } from 'react-router-dom';
import { ChevronRight, Calendar, User, Tag, ArrowLeft, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { blogPosts } from '@/data/blog';
import { Badge } from '@/components/ui/badge';
import ReactMarkdown from 'react-markdown';

const BlogPost = () => {
  const { slug } = useParams<{ slug: string }>();
  const navigate = useNavigate();
  const [post, setPost] = useState(null);
  const [adjacentPosts, setAdjacentPosts] = useState<{ next?: any; prev?: any }>({});

  useEffect(() => {
    if (slug) {
      const currentPost = blogPosts.find(post => post.slug === slug);
      setPost(currentPost);

      const currentIndex = blogPosts.findIndex(post => post.slug === slug);
      const prevPost = currentIndex > 0 ? blogPosts[currentIndex - 1] : null;
      const nextPost = currentIndex < blogPosts.length - 1 ? blogPosts[currentIndex + 1] : null;

      setAdjacentPosts({ next: nextPost, prev: prevPost });
    }
  }, [slug]);

  if (!post) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="text-center">
          <h1 className="text-3xl font-bold mb-4">Post Not Found</h1>
          <p className="text-muted-foreground">
            The post you are looking for does not exist.
          </p>
          <Button asChild>
            <Link to="/blog">Back to Blog</Link>
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <Button variant="ghost" onClick={() => navigate('/blog')}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Blog
        </Button>
      </div>

      <div className="mb-6">
        <h1 className="text-4xl font-bold mb-4">{post.title}</h1>
        <div className="flex items-center text-muted-foreground space-x-2 mb-4">
          <Calendar className="h-4 w-4" />
          <span>{post.date}</span>
          <Separator orientation="vertical" className="h-4" />
          <User className="h-4 w-4" />
          <span>{post.author}</span>
        </div>
        <div className="flex items-center space-x-2">
          {post.tags && post.tags.map((tag) => (
            <Badge key={tag} className="gap-1.5">
              <Tag className="h-3 w-3" />
              <span>{tag}</span>
            </Badge>
          ))}
        </div>
      </div>

      <img src={post.image} alt={post.title} className="w-full rounded-md mb-6" />

      <div className="prose lg:prose-lg dark:prose-invert mb-8">
        <ReactMarkdown>{post.content}</ReactMarkdown>
      </div>

      <Separator className="my-8" />

      <div className="flex justify-between">
        {adjacentPosts.prev ? (
          <Button variant="outline" asChild>
            <Link to={`/blog/${adjacentPosts.prev.slug}`} className="flex items-center">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Previous: {adjacentPosts.prev.title}
            </Link>
          </Button>
        ) : (
          <div></div>
        )}
        {adjacentPosts.next ? (
          <Button variant="outline" asChild>
            <Link to={`/blog/${adjacentPosts.next.slug}`} className="flex items-center">
              Next: {adjacentPosts.next.title}
              <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
        ) : (
          <div></div>
        )}
      </div>
    </div>
  );
};

export default BlogPost;
