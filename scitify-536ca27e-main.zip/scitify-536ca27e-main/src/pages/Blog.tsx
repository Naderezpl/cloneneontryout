
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { ChevronRight, Calendar, User } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { blogPosts, categories } from '@/data/blog';
import { fetchSiteSettings } from '@/api/settings';
import { SiteSettings } from '@/types/settings';

const Blog = () => {
  const [activeCategory, setActiveCategory] = useState('all');
  const [settings, setSettings] = useState<SiteSettings | null>(null);

  useEffect(() => {
    (async () => {
      try {
        const s = await fetchSiteSettings();
        setSettings(s);
      } catch {}
    })();
  }, []);

  const filteredPosts = activeCategory === 'all'
    ? blogPosts
    : blogPosts.filter(post => post.category === activeCategory);

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-4xl font-bold mb-4 text-center">
        The {settings?.company_name ?? 'Store'} Blog
      </h1>
      <p className="text-center text-muted-foreground max-w-3xl mx-auto mb-8">
        Stay updated with the latest trends in neon art, lighting design tips, and behind-the-scenes stories from {settings?.company_name ?? 'our store'}.
      </p>

      {/* Category filters */}
      <div className="flex flex-wrap justify-center gap-2 mb-12">
        <Button
          variant={activeCategory === 'all' ? "default" : "outline"}
          onClick={() => setActiveCategory('all')}
          className="text-sm"
        >
          All
        </Button>
        {categories.map(category => (
          <Button
            key={category.id}
            variant={activeCategory === category.id ? "default" : "outline"}
            onClick={() => setActiveCategory(category.id)}
            className="text-sm"
          >
            {category.name}
          </Button>
        ))}
      </div>

      {/* Blog post list */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredPosts.map(post => (
          <div key={post.slug} className="bg-background rounded-lg shadow-md overflow-hidden">
            <div className="relative aspect-video">
              <img
                src={post.image}
                alt={post.title}
                className="object-cover w-full h-full"
              />
            </div>
            <div className="p-4">
              <h2 className="text-xl font-bold mb-2">{post.title}</h2>
              <div className="flex items-center text-muted-foreground text-sm mb-3">
                <Calendar size={16} className="mr-1" />
                <time dateTime={post.date}>{post.date}</time>
                <span className="mx-2">•</span>
                <User size={16} className="mr-1" />
                <span>{post.author}</span>
              </div>
              <p className="text-muted-foreground mb-3">{post.excerpt}</p>
              <Button asChild variant="link" className="justify-start">
                <Link to={`/blog/${post.slug}`}>
                  Read More
                  <ChevronRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            </div>
          </div>
        ))}
      </div>

      {/* CTA Section */}
      <div className="mt-16 text-center bg-muted rounded-lg p-8 border border-border">
        <h2 className="text-2xl font-bold mb-4">
          Stay Inspired with {settings?.company_name ?? 'Us'}
        </h2>
        <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
          Explore our collection of neon signs and lighting solutions to bring your creative ideas to life.
          From custom designs to ready-made art, find the perfect neon piece for your space.
        </p>
        <Button asChild size="lg" className="bg-primary hover:bg-primary/90">
          <Link to="/shop">Discover Neon Signs</Link>
        </Button>
      </div>
    </div>
  );
};

export default Blog;
