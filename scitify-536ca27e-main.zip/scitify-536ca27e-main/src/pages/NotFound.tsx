
import React, { useEffect } from "react";
import { useLocation, Link } from "react-router-dom";
import { Button } from "@/components/ui/button";

const NotFound = () => {
  const location = useLocation();

  useEffect(() => {
    console.error(
      "404 Error: User attempted to access non-existent route:",
      location.pathname
    );
  }, [location.pathname]);

  return (
    <div className="flex items-center justify-center bg-background py-20">
      <div className="text-center px-4">
        <h1 className="text-8xl font-bold mb-6">
          <span className="neon-text-pink">4</span>
          <span className="neon-text-blue">0</span>
          <span className="neon-text-purple">4</span>
        </h1>
        <p className="text-2xl text-foreground mb-8">
          Oops! This page has gone dark
        </p>
        <p className="text-muted-foreground max-w-md mx-auto mb-8">
          The page you're looking for doesn't exist or has been moved.
          Let's get you back to our glowing collection.
        </p>
        <Button size="lg" asChild>
          <Link to="/">Return to Home</Link>
        </Button>
      </div>
    </div>
  );
};

export default NotFound;
