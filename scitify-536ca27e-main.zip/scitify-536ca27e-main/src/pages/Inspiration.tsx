
import React, { useState } from 'react';
import { inspirationItems, inspirationCategories } from '@/data/inspiration';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { MapPin } from 'lucide-react';

const Inspiration = () => {
  const [activeCategory, setActiveCategory] = useState('all');

  const filteredItems = activeCategory === 'all' 
    ? inspirationItems 
    : inspirationItems.filter(item => item.category === activeCategory);

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-4xl font-bold mb-4 text-center">Neon Inspiration Gallery</h1>
      <p className="text-center text-muted-foreground max-w-3xl mx-auto mb-8">
        Discover iconic neon installations from around the world and get inspired for your own custom design.
        From the dazzling lights of Las Vegas to elegant home decor, explore how neon transforms spaces.
      </p>

      {/* Category filters */}
      <div className="flex flex-wrap justify-center gap-2 mb-12">
        {inspirationCategories.map(category => (
          <Button
            key={category.id}
            variant={activeCategory === category.id ? "default" : "outline"}
            onClick={() => setActiveCategory(category.id)}
            className="text-sm"
          >
            {category.name}
          </Button>
        ))}
      </div>

      {/* Inspiration grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredItems.map(item => (
          <Card key={item.id} className="overflow-hidden bg-black border-muted hover:border-primary transition-colors duration-300">
            <div className="relative aspect-[4/3] overflow-hidden">
              <img 
                src={item.image} 
                alt={item.title} 
                className="object-cover w-full h-full transition-transform duration-500 hover:scale-105"
              />
            </div>
            <CardContent className="p-4">
              <h3 className="text-xl font-bold mb-2">{item.title}</h3>
              <p className="text-muted-foreground mb-3">{item.description}</p>
              {item.location && (
                <div className="flex items-center text-sm text-muted-foreground">
                  <MapPin size={16} className="mr-1" />
                  {item.location}
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {/* CTA Section */}
      <div className="mt-16 text-center bg-muted rounded-lg p-8 border border-border">
        <h2 className="text-2xl font-bold mb-4">Ready to create your own neon masterpiece?</h2>
        <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
          Get inspired by these examples and design a custom neon sign that's uniquely yours.
          Our expert craftsmen will bring your vision to life with premium quality materials.
        </p>
        <Button asChild size="lg" className="bg-primary hover:bg-primary/90">
          <a href="/custom">Start Designing Now</a>
        </Button>
      </div>
    </div>
  );
};

export default Inspiration;
