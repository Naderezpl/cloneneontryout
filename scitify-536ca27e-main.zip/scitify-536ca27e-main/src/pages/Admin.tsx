import React, { useEffect, useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useAuth } from '@/contexts/AuthContext';
import { Navigate } from 'react-router-dom';
import ProductsAdmin from '@/components/admin/ProductsAdmin';
import CategoriesAdmin from '@/components/admin/CategoriesAdmin';
import SiteSettingsAdmin from '@/components/admin/SiteSettingsAdmin';
import ReviewsAdmin from '@/components/admin/ReviewsAdmin';
import PagesAdmin from '@/components/admin/PagesAdmin';
import NavigationAdmin from '@/components/admin/NavigationAdmin';
import OrdersAdmin from '@/components/admin/OrdersAdmin';
import { Card } from '@/components/ui/card';
import NotificationBadge from '@/components/admin/NotificationBadge';
import { useToast } from '@/components/ui/use-toast';
import { seedDummyProducts } from '@/data/seedProducts';
import { seedDefaultPages } from '@/data/seedPages';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Search, ArrowUpDown, Filter, DollarSign } from 'lucide-react';
import DashboardAdmin from '@/components/admin/DashboardAdmin';
import HomepageLayoutAdmin from '@/components/admin/HomepageLayoutAdmin';
import HeroSliderAdmin from '@/components/admin/HeroSliderAdmin';
import CouponsAdmin from '@/components/admin/CouponsAdmin';
import AdminUsersAdmin from '@/components/admin/AdminUsersAdmin';
import {
  DropdownMenu,
  DropdownMenuCheckboxItem,
  DropdownMenuContent,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Separator } from '@/components/ui/separator';
 

// Define filter states for ProductsAdmin
export interface ProductFilters {
  search: string;
  sort: string;
  showInStock: boolean | null;
  priceRange: [number, number];
}

const Admin = () => {
  const { isAuthenticated, isAdmin, hasDbAdminRole, isLoading } = useAuth();
  const { toast } = useToast();
  
  // Default filter state
  const [productFilters, setProductFilters] = useState<ProductFilters>({
    search: '',
    sort: 'name-asc',
    showInStock: null,
    priceRange: [0, 5000]
  });
  
  // Price range input state
  const [minPrice, setMinPrice] = useState(productFilters.priceRange[0]);
  const [maxPrice, setMaxPrice] = useState(productFilters.priceRange[1]);

  // Seed data on initial admin access
  useEffect(() => {
    const seedData = async () => {
      try {
        await seedDummyProducts();
        await seedDefaultPages();
        console.log('Database seeding completed');
      } catch (error) {
        console.error('Error seeding data:', error);
        toast({
          variant: "destructive",
          title: "Database Setup Error",
          description: "There was an issue seeding data. Please check the console for details.",
        });
      }
    };

    if (isAuthenticated && (isAdmin || hasDbAdminRole)) {
      seedData();
    }
  }, [isAuthenticated, isAdmin, hasDbAdminRole, toast]);

  // Show loading while auth state is being restored
  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8 flex items-center justify-center min-h-[60vh]">
        <p className="text-muted-foreground">Loading...</p>
      </div>
    );
  }

  // Redirect if user is not authenticated or lacks admin role
  if (!isAuthenticated || !(isAdmin || hasDbAdminRole)) {
    return <Navigate to="/signin" />;
  }
  
  const handleApplyPriceRange = () => {
    let min = Math.max(0, minPrice);
    let max = Math.min(5000, maxPrice);
    
    if (min > max) {
      [min, max] = [max, min];
      setMinPrice(min);
      setMaxPrice(max);
    }
    
    setProductFilters({
      ...productFilters,
      priceRange: [min, max]
    });
  };

  return (
    <div className="container mx-auto px-2 sm:px-4 py-4 sm:py-8">
      <h1 className="text-2xl sm:text-3xl font-bold mb-4 sm:mb-8">Admin Panel</h1>
      
      <Card className="p-2 sm:p-6 overflow-x-hidden">
        <Tabs defaultValue="dashboard" className="w-full">
          <TabsList className="mb-4 sm:mb-8 flex flex-wrap justify-start sm:justify-center gap-1 sm:gap-2 h-auto">
            <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
            <TabsTrigger value="products">Products</TabsTrigger>
            <TabsTrigger value="categories">Categories</TabsTrigger>
            <TabsTrigger value="navigation">Navigation</TabsTrigger>
            <TabsTrigger value="settings">Site Settings</TabsTrigger>
            <TabsTrigger value="hero-slider">Hero Slider</TabsTrigger>
            <TabsTrigger value="layout">Homepage Layout</TabsTrigger>
            <TabsTrigger value="pages">Pages</TabsTrigger>
            <TabsTrigger value="reviews">Reviews</TabsTrigger>
            <TabsTrigger value="orders" className="relative">
              Orders
              <NotificationBadge />
            </TabsTrigger>
            <TabsTrigger value="coupons">Coupons</TabsTrigger>
            <TabsTrigger value="admins">Admins</TabsTrigger>
          </TabsList>
          
          <TabsContent value="dashboard" className="mt-6">
            <DashboardAdmin />
          </TabsContent>
          
          <TabsContent value="products" className="mt-6">
            <div className="mb-6">
              <div className="flex flex-wrap items-center gap-2 sm:gap-4 mb-4">
                <div className="relative flex-1 min-w-[200px] sm:min-w-[300px]">
                  <Input
                    type="text"
                    placeholder="Search products..."
                    value={productFilters.search}
                    onChange={(e) => setProductFilters({...productFilters, search: e.target.value})}
                    className="pl-10"
                  />
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" />
                </div>
                
                <div>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="outline" size="sm">
                        <ArrowUpDown className="mr-2 h-4 w-4" />
                        Sort By
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="w-48 bg-background border border-border rounded-md shadow-md">
                      <DropdownMenuLabel>Sort By</DropdownMenuLabel>
                      <DropdownMenuSeparator />
                      <DropdownMenuCheckboxItem
                        checked={productFilters.sort === 'name-asc'}
                        onCheckedChange={() => setProductFilters({...productFilters, sort: 'name-asc'})}
                      >
                        Name (A-Z)
                      </DropdownMenuCheckboxItem>
                      <DropdownMenuCheckboxItem
                        checked={productFilters.sort === 'name-desc'}
                        onCheckedChange={() => setProductFilters({...productFilters, sort: 'name-desc'})}
                      >
                        Name (Z-A)
                      </DropdownMenuCheckboxItem>
                      <DropdownMenuCheckboxItem
                        checked={productFilters.sort === 'price-asc'}
                        onCheckedChange={() => setProductFilters({...productFilters, sort: 'price-asc'})}
                      >
                        Price (Low to High)
                      </DropdownMenuCheckboxItem>
                      <DropdownMenuCheckboxItem
                        checked={productFilters.sort === 'price-desc'}
                        onCheckedChange={() => setProductFilters({...productFilters, sort: 'price-desc'})}
                      >
                        Price (High to Low)
                      </DropdownMenuCheckboxItem>
                      <DropdownMenuCheckboxItem
                        checked={productFilters.sort === 'created-desc'}
                        onCheckedChange={() => setProductFilters({...productFilters, sort: 'created-desc'})}
                      >
                        Newest First
                      </DropdownMenuCheckboxItem>
                      <DropdownMenuCheckboxItem
                        checked={productFilters.sort === 'created-asc'}
                        onCheckedChange={() => setProductFilters({...productFilters, sort: 'created-asc'})}
                      >
                        Oldest First
                      </DropdownMenuCheckboxItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
                
                <div>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="outline" size="sm">
                        <Filter className="mr-2 h-4 w-4" />
                        Stock Status
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="w-40 bg-background border border-border rounded-md shadow-md">
                      <DropdownMenuCheckboxItem
                        checked={productFilters.showInStock === null}
                        onCheckedChange={() => setProductFilters({...productFilters, showInStock: null})}
                      >
                        All Products
                      </DropdownMenuCheckboxItem>
                      <DropdownMenuCheckboxItem
                        checked={productFilters.showInStock === true}
                        onCheckedChange={() => setProductFilters({...productFilters, showInStock: true})}
                      >
                        In Stock
                      </DropdownMenuCheckboxItem>
                      <DropdownMenuCheckboxItem
                        checked={productFilters.showInStock === false}
                        onCheckedChange={() => setProductFilters({...productFilters, showInStock: false})}
                      >
                        Out of Stock
                      </DropdownMenuCheckboxItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>

                <div>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="outline" size="sm">
                        <DollarSign className="mr-2 h-4 w-4" />
                        Price Range
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="w-64 p-4 bg-background border border-border rounded-md shadow-md">
                      <h3 className="text-sm font-medium mb-4">Price Range</h3>
                      <div className="grid grid-cols-2 gap-2 mb-3">
                        <div>
                          <label htmlFor="admin-min-price" className="text-xs text-muted-foreground mb-1 block">
                            Min Price
                          </label>
                          <Input
                            id="admin-min-price"
                            type="number"
                            min={0}
                            value={minPrice}
                            onChange={(e) => setMinPrice(Number(e.target.value))}
                            placeholder="Min"
                          />
                        </div>
                        <div>
                          <label htmlFor="admin-max-price" className="text-xs text-muted-foreground mb-1 block">
                            Max Price
                          </label>
                          <Input
                            id="admin-max-price"
                            type="number"
                            min={0}
                            value={maxPrice}
                            onChange={(e) => setMaxPrice(Number(e.target.value))}
                            placeholder="Max"
                          />
                        </div>
                      </div>
                      <Button size="sm" onClick={handleApplyPriceRange} className="w-full">
                        Apply
                      </Button>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>

                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => {
                    setProductFilters({
                      search: '',
                      sort: 'name-asc',
                      showInStock: null,
                      priceRange: [0, 5000]
                    });
                    setMinPrice(0);
                    setMaxPrice(5000);
                  }}
                >
                  Reset Filters
                </Button>
              </div>
              <Separator className="my-4" />
            </div>
            <ProductsAdmin filters={productFilters} />
          </TabsContent>
          
          <TabsContent value="categories" className="mt-6">
            <CategoriesAdmin />
          </TabsContent>
          
          <TabsContent value="navigation" className="mt-6">
            <NavigationAdmin />
          </TabsContent>
          
          <TabsContent value="settings" className="mt-6">
            <SiteSettingsAdmin />
          </TabsContent>
          
          <TabsContent value="layout" className="mt-6">
            <HomepageLayoutAdmin />
          </TabsContent>

          <TabsContent value="hero-slider" className="mt-6">
            <HeroSliderAdmin />
          </TabsContent>
          
          <TabsContent value="pages" className="mt-6">
            <PagesAdmin />
          </TabsContent>
          
          <TabsContent value="reviews" className="mt-6">
            <ReviewsAdmin />
          </TabsContent>
          
          <TabsContent value="orders" className="mt-6">
            <OrdersAdmin />
          </TabsContent>

          <TabsContent value="coupons" className="mt-6">
            <CouponsAdmin />
          </TabsContent>

          <TabsContent value="admins" className="mt-6">
            <AdminUsersAdmin />
          </TabsContent>
        </Tabs>
      </Card>
    </div>
  );
};

export default Admin;
