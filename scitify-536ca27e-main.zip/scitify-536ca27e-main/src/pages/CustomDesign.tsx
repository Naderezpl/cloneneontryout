
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { useToast } from '@/components/ui/use-toast';
import { v4 as uuidv4 } from 'uuid';
import Footer from '@/components/Footer';
import { 
  Form, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormControl, 
  FormMessage 
} from '@/components/ui/form';

import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import * as z from "zod";
import { ChevronDown, EyeIcon, Move, Plus, Send, Shuffle, Sliders, Type, Upload } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

const fontOptions = [
  { id: 'neonline', name: 'Neon Line', style: 'font-mono tracking-wide' },
  { id: 'neontube', name: 'Neon Tube', style: 'font-mono tracking-wider' },
  { id: 'monocraft', name: 'Monocraft', style: 'font-mono uppercase tracking-wide' },
  { id: 'outlinedmono', name: 'Outlined Mono', style: 'font-mono font-light tracking-wide' },
  { id: 'neonscript', name: 'Neon Script', style: 'font-mono italic tracking-wide' },
  { id: 'slimline', name: 'Slim Line', style: 'font-mono font-thin tracking-wide' },
];

const colorOptions = [
  { id: 'pink', name: 'Neon Pink', class: 'neon-text-pink', value: '#ff00ff' },
  { id: 'blue', name: 'Ice Blue', class: 'neon-text-blue', value: '#00ffff' },
  { id: 'purple', name: 'Neon Purple', class: 'neon-text-purple', value: '#9b30ff' },
  { id: 'yellow', name: 'Yellow', class: 'neon-text-yellow', value: '#ffff00' },
  { id: 'green', name: 'Green', class: 'neon-text-green', value: '#00ff00' },
  { id: 'red', name: 'Red', class: 'neon-text-red', value: '#ff0000' },
];

const sizeOptions = [
  { id: 'small', name: 'Small (40cm)', price: 149 },
  { id: 'medium', name: 'Medium (60cm)', price: 199 },
  { id: 'large', name: 'Large (80cm)', price: 249 },
  { id: 'xlarge', name: 'Extra Large (100cm)', price: 299 },
];

const backgroundOptions = [
  { id: 'brick', name: 'Brick Wall', src: 'https://images.unsplash.com/photo-1558310357-e5b9c31b8d46?q=80&w=2070&auto=format&fit=crop' },
  { id: 'concrete', name: 'Concrete Wall', src: 'https://images.unsplash.com/photo-1601045569976-904b461aeb71?q=80&w=2070&auto=format&fit=crop' },
  { id: 'dark', name: 'Dark Room', src: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?q=80&w=2070&auto=format&fit=crop' },
  { id: 'cafe', name: 'Cafe Shop', src: 'https://images.unsplash.com/photo-1514933651103-005eec06c04b?q=80&w=2074&auto=format&fit=crop' },
];

const backingOptions = [
  { id: 'clear', name: 'Clear Acrylic', price: 0 },
  { id: 'black', name: 'Black Acrylic', price: 20 },
  { id: 'cut', name: 'Cut to Letter Shape', price: 50 },
];

const formSchema = z.object({
  text: z.string().min(1, "Text is required").max(50, "Text must be 50 characters or less"),
  font: z.string(),
  color: z.string(),
  size: z.string(),
  backing: z.string(),
  brightness: z.array(z.number()).default([70]),
  background: z.string().default('brick'),
});

const CustomDesign = () => {
  const { toast } = useToast();
  const [previewText, setPreviewText] = useState('Your Text Here');
  const [previewFont, setPreviewFont] = useState(fontOptions[0].style);
  const [previewColor, setPreviewColor] = useState(colorOptions[0].class);
  const [previewSize, setPreviewSize] = useState(sizeOptions[1].id);
  const [previewBackground, setPreviewBackground] = useState(backgroundOptions[0].src);
  const [totalPrice, setTotalPrice] = useState(199);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      text: '',
      font: fontOptions[0].id,
      color: colorOptions[0].id,
      size: sizeOptions[1].id,
      backing: backingOptions[0].id,
      brightness: [70],
      background: backgroundOptions[0].id,
    },
  });

  const onSubmit = (values: z.infer<typeof formSchema>) => {
    toast({
      title: "Design Added to Cart",
      description: `Your custom ${values.text} neon sign has been added to your cart.`,
    });
    
    console.log(values);
  };

  const calculatePrice = (size, backing) => {
    const selectedSize = sizeOptions.find(s => s.id === size);
    const selectedBacking = backingOptions.find(b => b.id === backing);
    
    return (selectedSize?.price || 0) + (selectedBacking?.price || 0);
  };

  const updatePreview = (text, font, color, size, backing, background) => {
    if (text) setPreviewText(text);
    
    const selectedFont = fontOptions.find(f => f.id === font);
    if (selectedFont) setPreviewFont(selectedFont.style);
    
    const selectedColor = colorOptions.find(c => c.id === color);
    if (selectedColor) setPreviewColor(selectedColor.class);
    
    if (size) setPreviewSize(size);
    
    const selectedBackground = backgroundOptions.find(b => b.id === background);
    if (selectedBackground) setPreviewBackground(selectedBackground.src);
    
    const newPrice = calculatePrice(size, backing);
    setTotalPrice(newPrice);
  };

  React.useEffect(() => {
    const subscription = form.watch((value, { name }) => {
      updatePreview(
        value.text || previewText, 
        value.font,
        value.color,
        value.size,
        value.backing,
        value.background
      );
    });
    
    return () => subscription.unsubscribe();
  }, [form.watch]);

  const getPreviewSizeClass = () => {
    switch(previewSize) {
      case 'small': return 'text-5xl';
      case 'medium': return 'text-6xl';
      case 'large': return 'text-7xl';
      case 'xlarge': return 'text-8xl';
      default: return 'text-6xl';
    }
  };

  const renderNeonText = (text) => {
    return text.split('').map((char, index) => {
      if (char === ' ') {
        return <span key={index} className="px-2"></span>;
      }
      return (
        <span key={index} className="neon-tube" style={{ marginRight: char === ' ' ? '0.5em' : '0.1em' }}>
          {char}
        </span>
      );
    });
  };

  return (
    <div className="flex flex-col min-h-screen">
      <main className="flex-grow">
        <div className="container mx-auto px-4 py-8">
          <h1 className="text-3xl font-bold mb-6">Design Your Custom Neon Sign</h1>
          
          <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
            <div className="lg:col-span-3 bg-black rounded-lg border border-muted">
              <div 
                className="w-full rounded-md overflow-hidden relative flex items-center justify-center mb-4"
                style={{
                  backgroundColor: '#000',
                  height: '600px'
                }}
              >
                <div 
                  className={`
                    ${previewColor} 
                    ${previewFont} 
                    ${getPreviewSizeClass()} 
                    font-bold 
                    z-10 
                    text-center 
                    px-6 
                    py-4 
                    leading-tight 
                    neon-tube-text
                    max-w-[90%]
                  `}
                >
                  {renderNeonText(previewText)}
                </div>
              </div>
              
              <div className="flex gap-4 justify-center mb-4 p-4">
                <Button variant="outline" size="sm" className="gap-2">
                  <EyeIcon size={16} /> Preview on Wall
                </Button>
                <Button variant="outline" size="sm" className="gap-2">
                  <Shuffle size={16} /> Random Design
                </Button>
              </div>
              
              <div className="bg-black/60 p-4 rounded-md m-4">
                <div className="flex justify-between items-center">
                  <h4 className="text-xl font-bold">Total Price</h4>
                  <p className="text-2xl font-bold text-primary">${totalPrice}</p>
                </div>
                <p className="text-muted-foreground text-sm">Includes VAT, free shipping within the US</p>
                
                <div className="mt-4 grid grid-cols-2 gap-4">
                  <Button size="lg" className="w-full bg-primary text-white hover:bg-primary/90 gap-2" onClick={form.handleSubmit(onSubmit)}>
                    <Send size={16} /> Add to Cart
                  </Button>
                  <Button variant="outline" size="lg" className="w-full">
                    Save Design
                  </Button>
                </div>
              </div>
            </div>
            
            <div className="lg:col-span-2">
              <Tabs defaultValue="text" className="w-full">
                <TabsList className="grid grid-cols-4 mb-6">
                  <TabsTrigger value="text" className="gap-2">
                    <Type size={16} /> Text
                  </TabsTrigger>
                  <TabsTrigger value="style" className="gap-2">
                    <Sliders size={16} /> Style
                  </TabsTrigger>
                  <TabsTrigger value="size" className="gap-2">
                    <Move size={16} /> Size
                  </TabsTrigger>
                  <TabsTrigger value="uploads" className="gap-2">
                    <Upload size={16} /> Uploads
                  </TabsTrigger>
                </TabsList>
                
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                    <TabsContent value="text" className="space-y-4">
                      <FormField
                        control={form.control}
                        name="text"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Your Text</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="Enter your text here" 
                                {...field} 
                                className="text-lg" 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                        <FormField
                          control={form.control}
                          name="font"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Font Style</FormLabel>
                              <div className="grid grid-cols-2 gap-2">
                                {fontOptions.map((font) => (
                                  <Button
                                    key={font.id}
                                    type="button"
                                    variant={field.value === font.id ? "default" : "outline"}
                                    className={`justify-start ${font.style} h-auto py-2`}
                                    onClick={() => field.onChange(font.id)}
                                  >
                                    {font.name}
                                  </Button>
                                ))}
                              </div>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="color"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Neon Color</FormLabel>
                              <div className="grid grid-cols-3 gap-2">
                                {colorOptions.map((color) => (
                                  <Button
                                    key={color.id}
                                    type="button"
                                    variant="outline"
                                    className={`h-auto p-0 overflow-hidden ${field.value === color.id ? 'ring-2 ring-primary' : ''}`}
                                    onClick={() => field.onChange(color.id)}
                                  >
                                    <div className="flex flex-col items-center w-full">
                                      <div 
                                        className="w-full h-6" 
                                        style={{ backgroundColor: color.value }}
                                      ></div>
                                      <span className="text-xs py-1">{color.name}</span>
                                    </div>
                                  </Button>
                                ))}
                              </div>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                      
                      <FormField
                        control={form.control}
                        name="background"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Background</FormLabel>
                            <div className="grid grid-cols-2 gap-2">
                              {backgroundOptions.map((bg) => (
                                <Button
                                  key={bg.id}
                                  type="button"
                                  variant="outline"
                                  className={`h-auto p-0 overflow-hidden ${field.value === bg.id ? 'ring-2 ring-primary' : ''}`}
                                  onClick={() => field.onChange(bg.id)}
                                >
                                  <div className="flex flex-col items-center w-full">
                                    <div 
                                      className="w-full h-16 bg-cover bg-center" 
                                      style={{ backgroundImage: `url(${bg.src})` }}
                                    ></div>
                                    <span className="text-xs py-1">{bg.name}</span>
                                  </div>
                                </Button>
                              ))}
                            </div>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </TabsContent>
                    
                    <TabsContent value="style" className="space-y-4">
                      <FormField
                        control={form.control}
                        name="brightness"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Brightness</FormLabel>
                            <div className="pt-2">
                              <Slider
                                defaultValue={field.value}
                                max={100}
                                step={1}
                                onValueChange={field.onChange}
                              />
                            </div>
                            <div className="flex justify-between">
                              <span className="text-xs text-muted-foreground">Low</span>
                              <span className="text-xs text-muted-foreground">High</span>
                            </div>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="backing"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Backing Options</FormLabel>
                            <div className="space-y-2">
                              {backingOptions.map((option) => (
                                <div
                                  key={option.id}
                                  className={`p-3 border rounded-md cursor-pointer ${
                                    field.value === option.id 
                                      ? 'border-primary bg-primary/10' 
                                      : 'border-border hover:border-primary/50'
                                  }`}
                                  onClick={() => field.onChange(option.id)}
                                >
                                  <div className="flex justify-between">
                                    <span className="font-medium">{option.name}</span>
                                    <span>
                                      {option.price === 0 ? 'Included' : `+$${option.price}`}
                                    </span>
                                  </div>
                                </div>
                              ))}
                            </div>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </TabsContent>
                    
                    <TabsContent value="size" className="space-y-4">
                      <FormField
                        control={form.control}
                        name="size"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Size</FormLabel>
                            <div className="space-y-2">
                              {sizeOptions.map((option) => (
                                <div
                                  key={option.id}
                                  className={`p-3 border rounded-md cursor-pointer ${
                                    field.value === option.id 
                                      ? 'border-primary bg-primary/10' 
                                      : 'border-border hover:border-primary/50'
                                  }`}
                                  onClick={() => field.onChange(option.id)}
                                >
                                  <div className="flex justify-between">
                                    <span className="font-medium">{option.name}</span>
                                    <span>${option.price}</span>
                                  </div>
                                </div>
                              ))}
                            </div>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </TabsContent>
                    
                    <TabsContent value="uploads" className="space-y-4">
                      <div className="border-2 border-dashed border-muted rounded-lg p-8 text-center">
                        <div className="mx-auto flex flex-col items-center">
                          <Upload className="h-10 w-10 text-muted-foreground mb-2" />
                          <h3 className="text-xl font-semibold">Upload Your Design</h3>
                          <p className="text-muted-foreground mb-4">
                            Drag and drop your files here, or click to browse
                          </p>
                          <Button type="button">
                            <Plus className="mr-2 h-4 w-4" /> Select Files
                          </Button>
                          <p className="text-xs text-muted-foreground mt-2">
                            Supported formats: JPG, PNG, SVG, AI (max 10MB)
                          </p>
                        </div>
                      </div>
                      
                      <div className="bg-muted/30 p-4 rounded-md">
                        <h3 className="font-medium mb-2">Custom Design Request</h3>
                        <p className="text-sm text-muted-foreground mb-4">
                          Need help with a complex design? Our designers can assist you.
                        </p>
                        <Button type="button" variant="outline" className="w-full">
                          Contact Design Team
                        </Button>
                      </div>
                    </TabsContent>
                  </form>
                </Form>
              </Tabs>
            </div>
          </div>
          
          <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-4 border border-muted rounded-lg">
              <h3 className="font-bold text-lg mb-2">Quality Guaranteed</h3>
              <p className="text-muted-foreground">
                All our neon signs are handcrafted using premium LED technology for a bright, long-lasting glow.
              </p>
            </div>
            
            <div className="p-4 border border-muted rounded-lg">
              <h3 className="font-bold text-lg mb-2">Free Shipping</h3>
              <p className="text-muted-foreground">
                Enjoy free shipping on all orders within the United States. International shipping available.
              </p>
            </div>
            
            <div className="p-4 border border-muted rounded-lg">
              <h3 className="font-bold text-lg mb-2">2-Year Warranty</h3>
              <p className="text-muted-foreground">
                All our neon signs come with a 2-year warranty and lifetime customer support.
              </p>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default CustomDesign;
