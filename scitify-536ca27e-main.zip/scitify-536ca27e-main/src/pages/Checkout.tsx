
import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Separator } from '@/components/ui/separator';
import { Card, CardContent } from '@/components/ui/card';
import { useCart } from '@/contexts/cart';
import { useToast } from '@/components/ui/use-toast';
import { Banknote, Wallet, Coins } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { v4 as uuidv4 } from 'uuid';
import { useQuery } from '@tanstack/react-query';
import { fetchSiteSettings } from '@/api/settings';

const Checkout = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { cart, clearCart, getTotalPrice } = useCart();
  const { toast } = useToast();
  const { isAuthenticated, user } = useAuth();
  const { data: settings } = useQuery({ queryKey: ['site-settings'], queryFn: fetchSiteSettings });

  // Coupon from cart page
  const passedCoupon = (location.state as any)?.coupon ?? null;
  const [appliedCoupon, setAppliedCoupon] = useState<any>(passedCoupon);

  const [paymentMethod, setPaymentMethod] = useState('cod');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    address: '',
    city: '',
    country: '',
    zipCode: '',
    state: '',
  });

  const USDT_ADDRESS = import.meta.env.VITE_USDT_WALLET_ADDRESS || '0xF3aF895067A702E034e4A7de5098c29E6955663c';

  useEffect(() => {
    if (cart.length === 0) {
      navigate('/cart');
    }
  }, [cart, navigate]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const sendOrderEmails = async (orderId: string, fallbackItemsText: string) => {
    try {
      const adminEmailLocal = (() => {
        try { return localStorage.getItem('orderNotificationEmail') || ''; } catch { return ''; }
      })();
      const adminEmail = settings?.order_notification_email || adminEmailLocal || '';
      const { data, error } = await supabase.functions.invoke('send-order-notification', {
        body: { orderId, adminEmail, paymentMethod, paymentStatus: 'Pending' }
      });
      if (error) throw error;
      if (!data || (data as any)?.success !== true) {
        throw new Error('Order email not sent');
      }
    } catch (err) {
      // Automatic-only mode: do not open any mail clients
      console.warn('Automatic order email failed:', err);
    }
  };

  const createPayment = async (orderId: string) => {
    const callbackUrl = encodeURIComponent(`${window.location.origin}/webhook?order_id=${orderId}`);
    const params = new URLSearchParams({
      callback: callbackUrl,
      address: USDT_ADDRESS,
      post: '0',
      json: '0',
      pending: '1',
      multi_token: '0',
      convert: '1'
    });
    const response = await fetch(`https://api.cryptapi.io/btc/create/?${params.toString()}`);
    const data = await response.json();
    return data;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      // Allow both authenticated and guest checkout
      const userId = isAuthenticated && user ? user.id : null;

      const requiredFields = ['name','email','phone','address','city','country','zipCode'] as const;
      const missing = requiredFields.filter(k => !String(formData[k]).trim());
      const emailValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email);
      const phoneDigits = (formData.phone || '').replace(/\D/g, '');
      const phoneValid = phoneDigits.length >= 5;
      if (missing.length > 0 || !emailValid || !phoneValid) {
        if (missing.length > 0) throw new Error('Please fill all contact and shipping fields.');
        if (!emailValid) throw new Error('Please enter a valid email.');
        if (!phoneValid) throw new Error('Please enter a valid phone number.');
      }

      const now = new Date().toISOString();
      const orderId = uuidv4();
      const subtotalPrice = Number(getTotalPrice());

      // Re-validate coupon at checkout with customer email
      let couponDiscount = 0;
      let validatedCoupon = appliedCoupon;
      if (appliedCoupon) {
        const { data: validation } = await supabase.rpc('validate_coupon', {
          p_code: appliedCoupon.code,
          p_subtotal: subtotalPrice,
          p_customer_email: formData.email,
        });
        if (validation?.valid) {
          couponDiscount = validation.discount;
        } else {
          validatedCoupon = null;
          setAppliedCoupon(null);
          toast({ variant: 'destructive', title: 'Coupon invalid', description: validation?.error || 'Coupon could not be applied.' });
        }
      }
      const totalPrice = Math.max(0, subtotalPrice - couponDiscount);

      const shippingAddress = [
        formData.address,
        `${formData.city}, ${formData.country}`,
        `${formData.state ? formData.state + ' ' : ''}${formData.zipCode}`
      ].join('\n');

      const { error: orderError } = await supabase
        .from('orders')
        .insert({
          id: orderId,
          user_id: userId,
          status: 'pending',
          total_price: totalPrice,
          created_at: now,
          customer_name: formData.name,
          customer_email: formData.email,
          customer_phone: formData.phone,
          shipping_address: shippingAddress,
          payment_method: paymentMethod,
          is_paid: false,
        });

      if (orderError) {
        throw orderError;
      }

      // Insert order items; unit_cost and expense will be handled by DB trigger
      for (const item of cart) {
        const variantLabel = item.variant.variant_name && item.variant.variant_name !== 'Default'
          ? ` - ${item.variant.variant_name}`
          : '';
        const { error: itemError } = await supabase
          .from('order_items')
          .insert({
            id: uuidv4(),
            order_id: orderId,
            product_id: item.product.id,
            quantity: item.quantity,
            price: item.variant.price,
            variant_data: item.variant as any,
            created_at: now,
          });
        if (itemError) {
          throw itemError;
        }
      }

      const itemsForEmail = cart.map(i => {
        const vLabel = i.variant.variant_name && i.variant.variant_name !== 'Default' ? ` - ${i.variant.variant_name}` : '';
        return `- ${i.product.name}${vLabel} x${i.quantity} @ $${i.variant.price}`;
      }).join('\n');

      if (paymentMethod === 'crypto-usdt') {
        try {
          const payment = await createPayment(orderId);
          toast({
            title: "Crypto payment created",
            description: "Follow the instructions to complete your payment.",
          });
          if (payment?.payment_url) {
            window.open(payment.payment_url, '_blank');
          }
        } catch (err) {
          toast({
            variant: "destructive",
            title: "Crypto setup failed",
            description: "Could not initialize crypto payment.",
          });
        }
      }

      try {
        await sendOrderEmails(orderId, itemsForEmail);
      } catch (emailErr) {
        // Silently continue; email delivery is best-effort
        console.warn('Order email send error:', emailErr);
      }

      // Record coupon usage
      if (validatedCoupon && couponDiscount > 0) {
        await supabase.from('coupon_usages').insert({
          coupon_id: validatedCoupon.coupon_id,
          order_id: orderId,
          customer_email: formData.email,
          user_id: userId,
          discount_applied: couponDiscount,
        });
        // Increment usage_count via raw SQL-safe approach
        await supabase.from('coupons').update({ usage_count: (appliedCoupon?.usage_count ?? 0) + 1 }).eq('id', validatedCoupon.coupon_id);
      }

      clearCart();
      toast({
        title: "Order confirmed!",
        description: "Thank you for your order. You will receive an email with the details.",
      });
      navigate('/order/confirmation', {
        state: {
          fromCheckout: true,
          paymentMethod,
          orderId,
          total: totalPrice,
          usdtAddress: USDT_ADDRESS,
        },
      });

    } catch (error) {
      toast({
        variant: "destructive",
        title: "Checkout failed",
        description: `There was an error processing your order. ${error instanceof Error ? error.message : ''}`,
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  if (cart.length === 0) {
    return (
      <div className="container mx-auto px-4 py-8 text-center">
        <h2 className="text-2xl font-bold mb-4">Your cart is empty</h2>
        <p className="text-muted-foreground mb-6">
          Looks like you haven't added anything to your cart yet.
        </p>
        <Button onClick={() => navigate('/shop')}>Continue Shopping</Button>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8 text-center">Checkout</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Contact Information & Shipping Details */}
        <Card>
          <CardContent className="space-y-6">
            <h2 className="text-xl font-semibold">Contact Information</h2>
            <Input
              type="email"
              name="email"
              placeholder="Email"
              value={formData.email}
              onChange={handleInputChange}
              required
            />
            <Input
              type="tel"
              name="phone"
              placeholder="Phone Number"
              value={formData.phone}
              onChange={handleInputChange}
              required
            />

            <Separator />

            <h2 className="text-xl font-semibold">Shipping Address</h2>
            <Input
              type="text"
              name="name"
              placeholder="Full Name"
              value={formData.name}
              onChange={handleInputChange}
              required
            />
            <Input
              type="text"
              name="address"
              placeholder="Address"
              value={formData.address}
              onChange={handleInputChange}
              required
            />
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Input
                type="text"
                name="city"
                placeholder="City"
                value={formData.city}
                onChange={handleInputChange}
                required
              />
              <Input
                type="text"
                name="country"
                placeholder="Country"
                value={formData.country}
                onChange={handleInputChange}
                required
              />
              <Input
                type="text"
                name="zipCode"
                placeholder="Postal Code"
                value={formData.zipCode}
                onChange={handleInputChange}
                required
              />
            </div>
          </CardContent>
        </Card>

        {/* Order Summary & Payment */}
        <Card>
          <CardContent className="space-y-6">
            <h2 className="text-xl font-semibold">Order Summary</h2>
            <ul className="space-y-3">
              {cart.map(item => {
                const variantLabel = item.variant.variant_name && item.variant.variant_name !== 'Default'
                  ? ` - ${item.variant.variant_name}`
                  : '';
                return (
                  <li key={item.id} className="flex justify-between items-start gap-4">
                    <div>
                      <span className="font-medium">{item.product.name}{variantLabel}</span>
                      <span className="text-sm text-muted-foreground ml-2">×{item.quantity}</span>
                    </div>
                    <span className="whitespace-nowrap">${(item.variant.price * item.quantity).toFixed(2)}</span>
                  </li>
                );
              })}
            </ul>
            <Separator />
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Subtotal</span>
              <span>${getTotalPrice()}</span>
            </div>
            {appliedCoupon && (
              <div className="flex justify-between text-sm text-green-600">
                <span>Discount ({appliedCoupon.code})</span>
                <span>-${appliedCoupon.discount.toFixed(2)}</span>
              </div>
            )}
            <div className="flex justify-between font-semibold">
              <span>Total</span>
              <span>${Math.max(0, Number(getTotalPrice()) - (appliedCoupon?.discount || 0)).toFixed(2)}</span>
            </div>

            <Separator />

            <h2 className="text-xl font-semibold">Payment Method</h2>
            <RadioGroup defaultValue="cod" className="flex flex-col gap-2" onValueChange={setPaymentMethod}>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="whish-money" id="whish-money" />
                <Label htmlFor="whish-money" className="flex items-center">
                  <Wallet className="mr-2 h-4 w-4" />
                  Whish Money
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="omt" id="omt" />
                <Label htmlFor="omt" className="flex items-center">
                  <Wallet className="mr-2 h-4 w-4" />
                  OMT
                </Label>
              </div>

              <div className="flex items-center space-x-2">
                <RadioGroupItem value="cod" id="cod" />
                <Label htmlFor="cod" className="flex items-center">
                  <Banknote className="mr-2 h-4 w-4" />
                  Cash On Delivery (COD)
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="crypto-usdt" id="crypto-usdt" />
                <Label htmlFor="crypto-usdt" className="flex items-center">
                  <Coins className="mr-2 h-4 w-4" />
                  Crypto (USDT)
                </Label>
              </div>
            </RadioGroup>

            {paymentMethod === 'crypto-usdt' && (
              <div className="rounded border p-4 space-y-2">
                <p className="text-sm text-muted-foreground">
                  Send USDT (ERC20) to the address below. After sending, place your order.
                </p>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-medium">USDT (ERC20):</span>
                    <span className="text-xs break-all">{USDT_ADDRESS || 'Configure VITE_USDT_WALLET_ADDRESS'}</span>
                  </div>
                </div>
              </div>
            )}

            <Button className="w-full" onClick={handleSubmit} disabled={isSubmitting}>
              {isSubmitting ? "Processing..." : "Place Order"}
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Checkout;
