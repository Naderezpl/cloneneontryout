
export type InspirationItem = {
  id: number;
  title: string;
  description: string;
  image: string;
  location?: string;
  category: string;
};

export const inspirationItems: InspirationItem[] = [
  {
    id: 1,
    title: "Las Vegas Strip",
    description: "The iconic neon lights of the Las Vegas Strip have defined the city's visual identity for decades.",
    image: "https://images.unsplash.com/photo-1581351721010-8cf859cb14a4?q=80&w=2070&auto=format&fit=crop",
    location: "Las Vegas, Nevada",
    category: "Famous Locations"
  },
  {
    id: 2,
    title: "Times Square",
    description: "New York's Times Square is known worldwide for its dazzling displays of neon and LED lighting.",
    image: "https://images.unsplash.com/photo-1589267125329-0d763d3482d1?q=80&w=2073&auto=format&fit=crop",
    location: "New York City, NY",
    category: "Famous Locations"
  },
  {
    id: 3,
    title: "Retro Diner",
    description: "Classic American diners often feature nostalgic neon signs that evoke the 1950s era.",
    image: "https://images.unsplash.com/photo-1555992828-65a978fc16a9?q=80&w=2070&auto=format&fit=crop",
    location: "Route 66",
    category: "Retro"
  },
  {
    id: 4,
    title: "Tokyo Nightlife",
    description: "Tokyo's districts like Shinjuku and Shibuya are renowned for their vibrant neon cityscape.",
    image: "https://images.unsplash.com/photo-1503899036084-c55cdd92da26?q=80&w=2074&auto=format&fit=crop",
    location: "Tokyo, Japan",
    category: "Famous Locations"
  },
  {
    id: 5,
    title: "Modern Home Bar",
    description: "Home bars can be transformed with custom neon signs that create an inviting atmosphere.",
    image: "https://images.unsplash.com/photo-1543791243-5de75bc46d30?q=80&w=1974&auto=format&fit=crop",
    category: "Home Decor"
  },
  {
    id: 6,
    title: "Wedding Decor",
    description: "Custom neon signs add a romantic and personal touch to wedding venues and celebrations.",
    image: "https://images.unsplash.com/photo-1519741347686-c1e0aadf4611?q=80&w=2070&auto=format&fit=crop",
    category: "Events"
  },
  {
    id: 7,
    title: "Minimalist Bedroom",
    description: "Simple neon phrases can enhance a minimalist bedroom design with a gentle glow.",
    image: "https://images.unsplash.com/photo-1494203484021-3c454daf695d?q=80&w=2080&auto=format&fit=crop",
    category: "Home Decor"
  },
  {
    id: 8,
    title: "Neon Museum",
    description: "The Neon Museum in Las Vegas preserves iconic signs from the city's colorful past.",
    image: "https://images.unsplash.com/photo-1577101442031-0d51a23cdb36?q=80&w=1974&auto=format&fit=crop",
    location: "Las Vegas, Nevada",
    category: "Museums"
  },
  {
    id: 9,
    title: "Chinatown Entrance",
    description: "Many Chinatown districts around the world feature striking neon gateway arches.",
    image: "https://images.unsplash.com/photo-1583396759538-86505e7145a9?q=80&w=1974&auto=format&fit=crop",
    category: "Famous Locations"
  },
  {
    id: 10,
    title: "Indie Cafe",
    description: "Small businesses often use neon signs to create a unique brand identity and ambiance.",
    image: "https://images.unsplash.com/photo-1554118811-1e0d58224f24?q=80&w=2047&auto=format&fit=crop",
    category: "Business"
  },
  {
    id: 11,
    title: "Hong Kong Streets",
    description: "Hong Kong's dense urban landscape is famous for its mesmerizing array of neon signs.",
    image: "https://images.unsplash.com/photo-1536599018102-9f803c140fc1?q=80&w=1928&auto=format&fit=crop",
    location: "Hong Kong",
    category: "Famous Locations"
  },
  {
    id: 12,
    title: "Art Gallery",
    description: "Contemporary art installations often incorporate neon as a medium for expression.",
    image: "https://images.unsplash.com/photo-1518998053901-5348d3961a04?q=80&w=1974&auto=format&fit=crop",
    category: "Art"
  }
];

export const inspirationCategories = [
  { id: "all", name: "All Inspiration" },
  { id: "Famous Locations", name: "Famous Locations" },
  { id: "Home Decor", name: "Home Decor" },
  { id: "Business", name: "Business Signs" },
  { id: "Events", name: "Events & Celebrations" },
  { id: "Retro", name: "Retro & Vintage" },
  { id: "Art", name: "Art & Design" },
  { id: "Museums", name: "Museums & Exhibitions" }
];
