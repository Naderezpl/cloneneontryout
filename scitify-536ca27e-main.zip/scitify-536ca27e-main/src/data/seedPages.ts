import { supabase } from "@/lib/supabase";

type SeedPage = {
  slug: string;
  title: string;
  content_html: string;
  meta_title?: string | null;
  meta_description?: string | null;
};

const PAGES: SeedPage[] = [
  {
    slug: "about",
    title: "About Us",
    meta_title: "About Us",
    meta_description: "Scitify builds fast, modern websites without heavy monthly platform costs.",
    content_html: `
      <h2>About Us</h2>
      <p><strong>At Scitify</strong>, we specialize in building fast, modern, and fully customized websites for businesses that want more control than traditional website platforms.</p>
      <p>Our mission is simple: provide powerful online stores and websites <strong>without</strong> forcing businesses into expensive monthly platform subscriptions.</p>
      <p>Instead of charging monthly platform fees, we develop fully functional websites through a <strong>one-time purchase</strong>, giving our clients full control over their online presence.</p>
      <h3>Every website we create is optimized for</h3>
      <ul>
        <li>Speed and performance</li>
        <li>Modern design</li>
        <li>Mobile responsiveness</li>
        <li>Scalable ecommerce functionality</li>
      </ul>
      <p>Our development process typically takes <strong>1–5 business days</strong>, depending on the requested features and our current project queue.</p>
      <p>After development, websites are hosted on our secure infrastructure to ensure reliability, uptime, and technical support.</p>
      <p>At Scitify, we focus on helping businesses launch online quickly with professional, reliable websites built for long-term success.</p>
    `,
  },
  {
    slug: "shipping-policy",
    title: "Development Time & Payment",
    meta_title: "Development Time & Payment",
    meta_description: "Project delivery timelines and payment structure for Scitify.",
    content_html: `
      <h2>Development Time</h2>
      <p>For website development services, delivery time is typically <strong>1–5 business days</strong> after we receive all required content, assets, and access.</p>
      <h3>Delivery Depends On</h3>
      <ul>
        <li>Project complexity</li>
        <li>Requested features</li>
        <li>Current development workload</li>
      </ul>
      <h3>What You Receive</h3>
      <ul>
        <li>Hosting activation (when managed by us)</li>
        <li>Website login credentials</li>
        <li>Admin access to manage the site</li>
      </ul>
      <h2>Payment Policy</h2>
      <p>All website development projects require <strong>100% payment upfront</strong> before development begins. We do not offer 50% / 50% payment structures.</p>
      <h3>One‑Time Website Purchase</h3>
      <p>Unlike subscription platforms, Scitify websites are delivered through a <strong>one‑time purchase</strong> for development.</p>
      <h3>Hosting Fees</h3>
      <p>After development, websites must remain connected to our <strong>annual hosting</strong> service (or your own if self‑hosted) to stay online and functional. If hosting expires and is not renewed, the site may be unavailable until hosting is reactivated.</p>
      <h3>Refunds</h3>
      <p>Because development work begins immediately and is custom, refunds may not be available once development has started.</p>
      <h2>Physical Products (If Applicable)</h2>
      <p>If your store includes physical products, shipping timelines are shown at checkout and may vary by destination and carrier.</p>
    `,
  },
  {
    slug: "care-instructions",
    title: "Hosting & Care",
    meta_title: "Hosting & Care Instructions",
    meta_description: "Annual hosting requirements and ongoing care for your site.",
    content_html: `
      <h2>Care Instructions</h2>
      <p>To keep your website operating smoothly after development by Scitify, please follow these guidelines:</p>
      <ul>
        <li>Maintain an <strong>active hosting subscription</strong>.</li>
        <li>Avoid modifying core system files unless advised by support.</li>
        <li>Keep your admin credentials secure.</li>
        <li>Regularly update content and products via the admin panel.</li>
      </ul>
      <p><em>Failure to maintain active hosting may cause the website to stop operating until hosting is renewed.</em></p>
    `,
  },
  {
    slug: "privacy-policy",
    title: "Privacy Policy",
    meta_title: "Privacy Policy",
    meta_description: "How Scitify collects, uses, and protects your information.",
    content_html: `
      <h2>Privacy Policy</h2>
      <p>At Scitify, we respect your privacy and are committed to protecting your personal information.</p>
      <h3>Information We Collect</h3>
      <ul>
        <li>Name and email address</li>
        <li>Billing details</li>
        <li>Website project requirements</li>
        <li>Usage data and analytics</li>
      </ul>
      <h3>How We Use Your Information</h3>
      <ul>
        <li>Process orders and payments</li>
        <li>Deliver website development services</li>
        <li>Provide customer support</li>
        <li>Improve our services and platform performance</li>
      </ul>
      <h3>Data Security</h3>
      <p>We implement security measures designed to protect your information from unauthorized access, alteration, or disclosure.</p>
      <h3>Third‑Party Services</h3>
      <p>We may use trusted third‑party processors and analytics tools, each governed by their own privacy policies.</p>
    `,
  },
  {
    slug: "terms-of-service",
    title: "Terms of Service",
    meta_title: "Terms of Service",
    meta_description: "Terms governing Scitify services.",
    content_html: `
      <h2>Terms of Service</h2>
      <h3>Service Description</h3>
      <p>Scitify provides custom website development and hosting services for businesses and individuals.</p>
      <h3>Development Time</h3>
      <p>Most projects are completed within <strong>1–5 business days</strong>, depending on feature requirements, complexity, and current order volume.</p>
      <h3>Ownership</h3>
      <p>Once development is completed and delivered, clients gain access to manage their website through the provided admin panel.</p>
      <h3>Hosting Requirement</h3>
      <p>Websites require active hosting to remain operational. If hosting is not renewed annually, the site may become unavailable until hosting is restored.</p>
      <h3>Changes to Services</h3>
      <p>We reserve the right to update, improve, or modify our services when necessary.</p>
      <h3>Payments</h3>
      <ul>
        <li>Projects require <strong>100% upfront payment</strong> before development begins.</li>
        <li>Websites are delivered as a <strong>one‑time purchase</strong> for development.</li>
        <li>Annual hosting fees apply after development to keep the site online.</li>
        <li>Refunds may not be available once custom development has started.</li>
      </ul>
    `,
  },
];

export const seedDefaultPages = async () => {
  const now = new Date().toISOString();
  for (const p of PAGES) {
    const { error: upsertError } = await supabase
      .from('pages')
      .upsert({
        slug: p.slug,
        title: p.title,
        content_html: p.content_html,
        meta_title: p.meta_title ?? p.title,
        meta_description: p.meta_description ?? null,
        enabled: true,
        created_at: now,
        updated_at: now,
      }, { onConflict: 'slug' });
    if (upsertError) {
      console.error('seedDefaultPages: upsert error', p.slug, upsertError);
    }
  }
};
