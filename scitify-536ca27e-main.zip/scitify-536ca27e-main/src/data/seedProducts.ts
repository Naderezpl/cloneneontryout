
import { supabase } from "@/lib/supabase";
import { v4 as uuidv4 } from "uuid";

export const seedDummyProducts = async () => {
  const now = new Date().toISOString();

  // Check if we already have some products to avoid duplicating
  const { count } = await supabase
    .from('products')
    .select('*', { count: 'exact', head: true });
    
  if (count && count > 0) {
    console.log(`Database already has ${count} products, skipping seed data.`);
    return;
  }
  
  // Create T-Shirt product with color variants
  const tshirtId = uuidv4();
  await supabase.from('products').insert({
    id: tshirtId,
    name: 'Premium T-Shirt',
    description: 'High-quality cotton t-shirt, perfect for everyday wear. Comfortable fit and durable material.',
    category_id: null,
    created_at: now
  });
  
  // Add T-Shirt variants
  const tshirtVariants = [
    {
      id: uuidv4(),
      product_id: tshirtId,
      variant_name: 'Red',
      price: 24.99,
      stock_quantity: 20,
      created_at: now,
      updated_at: now
    },
    {
      id: uuidv4(),
      product_id: tshirtId,
      variant_name: 'Blue',
      price: 24.99,
      stock_quantity: 15,
      created_at: now,
      updated_at: now
    },
    {
      id: uuidv4(),
      product_id: tshirtId,
      variant_name: 'Black',
      price: 29.99, // Black costs more
      stock_quantity: 25,
      created_at: now,
      updated_at: now
    }
  ];
  
  await supabase.from('product_variants').insert(tshirtVariants);
  
  // Add T-Shirt images
  const tshirtImages = [
    {
      id: uuidv4(),
      product_id: tshirtId,
      variant_id: tshirtVariants[0].id, // Red
      image_url: 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8cmVkJTIwdHNoaXJ0fGVufDB8fDB8fHww',
      title: 'Red T-Shirt',
      position: 0,
      created_at: now
    },
    {
      id: uuidv4(),
      product_id: tshirtId,
      variant_id: tshirtVariants[1].id, // Blue
      image_url: 'https://plus.unsplash.com/premium_photo-1682096992977-9c42151824b5?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8Ymx1ZSUyMHRzaGlydHxlbnwwfHwwfHx8MA%3D%3D',
      title: 'Blue T-Shirt',
      position: 0,
      created_at: now
    },
    {
      id: uuidv4(),
      product_id: tshirtId,
      variant_id: tshirtVariants[2].id, // Black
      image_url: 'https://images.unsplash.com/photo-1618517351616-38fb9c5210c6?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8YmxhY2slMjB0c2hpcnR8ZW58MHx8MHx8fDA%3D',
      title: 'Black T-Shirt',
      position: 0,
      created_at: now
    },
    {
      id: uuidv4(),
      product_id: tshirtId,
      variant_id: null, // Product-level image
      image_url: 'https://images.unsplash.com/photo-1576566588028-4147f3842f27?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8dHNoaXJ0fGVufDB8fDB8fHww',
      title: 'T-Shirt Collection',
      position: 0,
      created_at: now
    }
  ];
  
  await supabase.from('product_images').insert(tshirtImages);
  
  // Create Sneakers product with size and color variants
  const sneakersId = uuidv4();
  await supabase.from('products').insert({
    id: sneakersId,
    name: 'Urban Sneakers',
    description: 'Stylish and comfortable urban sneakers with cushioned insoles and durable outsoles. Perfect for casual wear.',
    category_id: null,
    created_at: now
  });
  
  // Add Sneakers variants
  const sizes = [40, 42, 44];
  const colors = ['White', 'Black'];
  const sneakerVariants = [];
  
  for (const size of sizes) {
    for (const color of colors) {
      sneakerVariants.push({
        id: uuidv4(),
        product_id: sneakersId,
        variant_name: `Size ${size}, ${color}`,
        price: size === 44 ? 119.99 : 99.99, // Larger sizes cost more
        stock_quantity: Math.floor(Math.random() * 10) + 5, // Random stock between 5-15
        created_at: now,
        updated_at: now
      });
    }
  }
  
  await supabase.from('product_variants').insert(sneakerVariants);
  
  // Add Sneakers images
  const sneakerImages = [
    {
      id: uuidv4(),
      product_id: sneakersId,
      variant_id: sneakerVariants[0].id, // Size 40, White
      image_url: 'https://images.unsplash.com/photo-1600269452121-4f2416e55c28?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8d2hpdGUlMjBzbmVha2Vyc3xlbnwwfHwwfHx8MA%3D%3D',
      title: 'White Sneakers',
      position: 0,
      created_at: now
    },
    {
      id: uuidv4(),
      product_id: sneakersId,
      variant_id: sneakerVariants[1].id, // Size 40, Black
      image_url: 'https://images.unsplash.com/photo-1605408499391-6368c628ef42?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTJ8fGJsYWNrJTIwc25lYWtlcnN8ZW58MHx8MHx8fDA%3D',
      title: 'Black Sneakers',
      position: 0,
      created_at: now
    },
    {
      id: uuidv4(),
      product_id: sneakersId,
      variant_id: null, // Product-level image
      image_url: 'https://images.unsplash.com/photo-1549298916-b41d501d3772?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NHx8c25lYWtlcnN8ZW58MHx8MHx8fDA%3D',
      title: 'Sneakers Collection',
      position: 0,
      created_at: now
    }
  ];
  
  await supabase.from('product_images').insert(sneakerImages);
  
  // Create Wooden Sign product with material variants
  const signId = uuidv4();
  await supabase.from('products').insert({
    id: signId,
    name: 'Custom Engraved Wooden Sign',
    description: 'Beautiful wooden sign with custom engraving. Perfect for home decor, gifts, or business signage. Each piece is carefully crafted from high-quality wood.',
    category_id: null,
    created_at: now
  });
  
  // Add Wooden Sign variants
  const signVariants = [
    {
      id: uuidv4(),
      product_id: signId,
      variant_name: 'Oak Wood',
      price: 89.99,
      stock_quantity: 10,
      created_at: now,
      updated_at: now
    },
    {
      id: uuidv4(),
      product_id: signId,
      variant_name: 'Walnut Wood',
      price: 129.99, // Walnut is more expensive
      stock_quantity: 5,
      created_at: now,
      updated_at: now
    }
  ];
  
  await supabase.from('product_variants').insert(signVariants);
  
  // Add Wooden Sign images
  const signImages = [
    {
      id: uuidv4(),
      product_id: signId,
      variant_id: signVariants[0].id, // Oak
      image_url: 'https://images.unsplash.com/photo-1611486212557-88502d09f34b?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8b2FrJTIwd29vZHxlbnwwfHwwfHx8MA%3D%3D',
      title: 'Oak Wood Sign',
      position: 0,
      created_at: now
    },
    {
      id: uuidv4(),
      product_id: signId,
      variant_id: signVariants[1].id, // Walnut
      image_url: 'https://images.unsplash.com/photo-1599524514370-7d5d8ba3ac76?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8d2FsbnV0JTIwd29vZHxlbnwwfHwwfHx8MA%3D%3D',
      title: 'Walnut Wood Sign',
      position: 0,
      created_at: now
    },
    {
      id: uuidv4(),
      product_id: signId,
      variant_id: null, // Product-level image
      image_url: 'https://images.unsplash.com/photo-1558591710-4b4a1ae0f04d?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8d29vZGVuJTIwc2lnbnxlbnwwfHwwfHx8MA%3D%3D',
      title: 'Custom Wooden Sign',
      position: 0,
      created_at: now
    }
  ];
  
  await supabase.from('product_images').insert(signImages);
  
  console.log('Successfully seeded 3 products with variants and images!');
};
