export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      products: {
        Row: {
          id: string
          name: string
          description: string
          category_id: string | null
          created_at: string
        }
        Insert: {
          id?: string
          name: string
          description: string
          category_id?: string | null
          created_at?: string
        }
        Update: {
          id?: string
          name?: string
          description?: string
          category_id?: string | null
          created_at?: string
        }
      }
      product_variants: {
        Row: {
          id: string
          product_id: string
          variant_name: string
          price: number
          stock_quantity: number
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          product_id: string
          variant_name: string
          price: number
          stock_quantity?: number
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          product_id?: string
          variant_name?: string
          price?: number
          stock_quantity?: number
          created_at?: string
          updated_at?: string
        }
      }
      product_images: {
        Row: {
          id: string
          product_id: string
          variant_id: string | null
          image_url: string
          created_at: string
          title: string | null
          url: string | null
          position: number | null
        }
        Insert: {
          id?: string
          product_id: string
          variant_id?: string | null
          image_url: string
          created_at?: string
          title?: string | null
          url?: string | null
          position?: number | null
        }
        Update: {
          id?: string
          product_id?: string
          variant_id?: string | null
          image_url?: string
          created_at?: string
          title?: string | null
          url?: string | null
          position?: number | null
        }
      }
      categories: {
        Row: {
          id: string
          name: string
          created_at: string
        }
        Insert: {
          id?: string
          name: string
          created_at?: string
        }
        Update: {
          id?: string
          name?: string
          created_at?: string
        }
      }
      site_settings: {
        Row: {
          id: number
          company_name: string
          logo_url: string
          contact_email: string
          contact_phone: string
          contact_address: string
          order_notification_email: string | null;
          updated_at: string
          created_at: string
        }
        Insert: {
          id?: number
          company_name: string
          logo_url: string
          contact_email: string
          contact_phone: string
          contact_address: string
          order_notification_email?: string | null;
          updated_at?: string
          created_at?: string
        }
        Update: {
          id?: number
          company_name?: string
          logo_url?: string
          contact_email?: string
          contact_phone?: string
          contact_address?: string
          order_notification_email?: string | null;
          updated_at?: string
          created_at?: string
        }
      }
      orders: {
        Row: {
          id: string
          user_id: string
          status: string
          total_price: number
          created_at: string
        }
        Insert: {
          id?: string
          user_id: string
          status: string
          total_price: number
          created_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          status?: string
          total_price?: number
          created_at?: string
        }
      }
      order_items: {
        Row: {
          id: string
          order_id: string
          product_id: string
          quantity: number
          price: number
          created_at: string
        }
        Insert: {
          id?: string
          order_id: string
          product_id: string
          quantity: number
          price: number
          created_at?: string
        }
        Update: {
          id?: string
          order_id?: string
          product_id?: string
          quantity?: number
          price?: number
          created_at?: string
        }
      }
      cart_items: {
        Row: {
          id: string
          user_id: string
          product_id: string
          quantity: number
          created_at: string
        }
        Insert: {
          id?: string
          user_id: string
          product_id: string
          quantity: number
          created_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          product_id?: string
          quantity?: number
          created_at?: string
        }
      }
      favorites: {
        Row: {
          id: string
          user_id: string
          product_id: string
          created_at: string
        }
        Insert: {
          id?: string
          user_id: string
          product_id: string
          created_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          product_id?: string
          created_at?: string
        }
      }
      users: {
        Row: {
          id: string
          email: string
          password_hash: string
          created_at: string
        }
        Insert: {
          id?: string
          email: string
          password_hash: string
          created_at?: string
        }
        Update: {
          id?: string
          email?: string
          password_hash?: string
          created_at?: string
        }
      }
      user_roles: {
        Row: {
          id: number
          user_id: string
          role: string
          created_at: string
        }
        Insert: {
          id?: number
          user_id: string
          role: string
          created_at?: string
        }
        Update: {
          id?: number
          user_id?: string
          role?: string
          created_at?: string
        }
      }
      notifications: {
        Row: {
          id: number
          user_id: string | null
          type: string
          message: string
          is_read: boolean
          created_at: string
        }
        Insert: {
          id?: number
          user_id?: string | null
          type: string
          message: string
          is_read?: boolean
          created_at?: string
        }
        Update: {
          id?: number
          user_id?: string | null
          type?: string
          message?: string
          is_read?: boolean
          created_at?: string
        }
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      create_user_roles_table: {
        Args: Record<string, never>
        Returns: boolean
      }
      create_notifications_table: {
        Args: Record<string, never>
        Returns: boolean
      }
      create_orders_table: {
        Args: Record<string, never>
        Returns: boolean
      }
    }
    Enums: {
      [_ in never]: never
    }
  }
  storage: {
    Buckets: {
      imageassets: {
        Row: {
          id: string
          name: string
          owner: string | null
          created_at: string | null
          updated_at: string | null
          public: boolean | null
          avif_autodetection: boolean | null
          file_size_limit: number | null
          allowed_mime_types: string[] | null
        }
      }
    }
    Objects: {
      [_ in string]: {
        Row: {
          name: string
          bucket_id: string
          owner: string | null
          created_at: string | null
          updated_at: string | null
          last_accessed_at: string | null
          metadata: Json | null
        }
      }
    }
  }
}

// Types for the updated data model
export type Product = Database['public']['Tables']['products']['Row'];
export type ProductVariant = Database['public']['Tables']['product_variants']['Row'];
export type ProductImage = Database['public']['Tables']['product_images']['Row'];
