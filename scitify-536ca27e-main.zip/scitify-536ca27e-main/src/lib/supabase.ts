import { supabase as typedSupabase } from '@/integrations/supabase/client';

// Export as any to avoid type errors with tables not yet in generated types
export const supabase = typedSupabase as any;
