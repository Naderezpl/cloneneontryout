import { supabase } from '@/lib/supabase';

export const createStorageBucket = async (): Promise<boolean> => {
  try {
    // Check if the buckets already exist
    const { data: buckets } = await supabase.storage.listBuckets();
    
    // Check for 'imageassets' bucket
    const imageAssetsBucketExists = buckets?.some(bucket => bucket.name === 'imageassets');
    if (!imageAssetsBucketExists) {
      // Create the assets bucket for storing general assets
      const { error: assetsError } = await supabase.storage.createBucket('imageassets', {
        public: true,
      });
      
      if (assetsError) {
        console.error('Error creating imageassets storage bucket:', assetsError);
        
        if (assetsError.message.includes('permission') || assetsError.message.includes('policy')) {
          console.info('Note: This may be due to RLS policies.');
        }
        
        return false;
      }
      console.info('Storage bucket "imageassets" created successfully');
    } else {
      console.info('Storage bucket "imageassets" already exists');
      
      // Try to update the bucket to ensure it's public
      try {
        await supabase.storage.updateBucket('imageassets', {
          public: true,
        });
        console.info('Updated "imageassets" bucket to be public');
      } catch (updateError) {
        console.error('Note: Could not update bucket visibility:', updateError);
      }
    }
    
    return true;
  } catch (error) {
    console.error('Error setting up storage buckets:', error);
    return false;
  }
};

export const setupSupabaseResources = async () => {
  await createStorageBucket();
  console.info('Supabase resources setup complete');
};
