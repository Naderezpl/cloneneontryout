export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.4"
  }
  public: {
    Tables: {
      auto_reorder_queue: {
        Row: {
          created_at: string | null
          error_message: string | null
          id: string
          processed_at: string | null
          product_id: string | null
          quantity: number | null
          reminder_id: string | null
          status: string | null
          updated_at: string | null
          user_id: string | null
        }
        Insert: {
          created_at?: string | null
          error_message?: string | null
          id?: string
          processed_at?: string | null
          product_id?: string | null
          quantity?: number | null
          reminder_id?: string | null
          status?: string | null
          updated_at?: string | null
          user_id?: string | null
        }
        Update: {
          created_at?: string | null
          error_message?: string | null
          id?: string
          processed_at?: string | null
          product_id?: string | null
          quantity?: number | null
          reminder_id?: string | null
          status?: string | null
          updated_at?: string | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "auto_reorder_queue_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "auto_reorder_queue_reminder_id_fkey"
            columns: ["reminder_id"]
            isOneToOne: false
            referencedRelation: "replenishment_reminders"
            referencedColumns: ["id"]
          },
        ]
      }
      cart_items: {
        Row: {
          created_at: string
          id: string
          product_id: string
          quantity: number
          updated_at: string
          user_id: string
          variant_data: Json | null
        }
        Insert: {
          created_at?: string
          id?: string
          product_id: string
          quantity?: number
          updated_at?: string
          user_id: string
          variant_data?: Json | null
        }
        Update: {
          created_at?: string
          id?: string
          product_id?: string
          quantity?: number
          updated_at?: string
          user_id?: string
          variant_data?: Json | null
        }
        Relationships: [
          {
            foreignKeyName: "cart_items_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
        ]
      }
      categories: {
        Row: {
          background_color: string | null
          created_at: string
          description: string | null
          id: string
          image_url: string | null
          is_visible: boolean | null
          name: string
          position: number | null
          slug: string | null
          text_color: string | null
        }
        Insert: {
          background_color?: string | null
          created_at?: string
          description?: string | null
          id?: string
          image_url?: string | null
          is_visible?: boolean | null
          name: string
          position?: number | null
          slug?: string | null
          text_color?: string | null
        }
        Update: {
          background_color?: string | null
          created_at?: string
          description?: string | null
          id?: string
          image_url?: string | null
          is_visible?: boolean | null
          name?: string
          position?: number | null
          slug?: string | null
          text_color?: string | null
        }
        Relationships: []
      }
      competitor_prices: {
        Row: {
          fetched_at: string
          id: number
          price: number
          product_id: string
          source_id: number
        }
        Insert: {
          fetched_at?: string
          id?: number
          price: number
          product_id: string
          source_id: number
        }
        Update: {
          fetched_at?: string
          id?: number
          price?: number
          product_id?: string
          source_id?: number
        }
        Relationships: [
          {
            foreignKeyName: "competitor_prices_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "competitor_prices_source_id_fkey"
            columns: ["source_id"]
            isOneToOne: false
            referencedRelation: "competitor_sources"
            referencedColumns: ["id"]
          },
        ]
      }
      competitor_sources: {
        Row: {
          base_url: string | null
          created_at: string
          id: number
          is_active: boolean
          name: string
          source_type: string
          updated_at: string
        }
        Insert: {
          base_url?: string | null
          created_at?: string
          id?: number
          is_active?: boolean
          name: string
          source_type: string
          updated_at?: string
        }
        Update: {
          base_url?: string | null
          created_at?: string
          id?: number
          is_active?: boolean
          name?: string
          source_type?: string
          updated_at?: string
        }
        Relationships: []
      }
      coupon_usages: {
        Row: {
          coupon_id: string
          created_at: string
          customer_email: string
          discount_applied: number
          id: string
          order_id: string | null
          user_id: string | null
        }
        Insert: {
          coupon_id: string
          created_at?: string
          customer_email: string
          discount_applied?: number
          id?: string
          order_id?: string | null
          user_id?: string | null
        }
        Update: {
          coupon_id?: string
          created_at?: string
          customer_email?: string
          discount_applied?: number
          id?: string
          order_id?: string | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "coupon_usages_coupon_id_fkey"
            columns: ["coupon_id"]
            isOneToOne: false
            referencedRelation: "coupons"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "coupon_usages_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
        ]
      }
      coupons: {
        Row: {
          code: string
          code_upper: string | null
          created_at: string
          discount_type: string
          discount_value: number
          expires_at: string | null
          id: string
          is_active: boolean
          max_uses: number | null
          max_uses_per_customer: number | null
          min_subtotal: number | null
          starts_at: string | null
          updated_at: string
          usage_count: number
        }
        Insert: {
          code: string
          code_upper?: string | null
          created_at?: string
          discount_type?: string
          discount_value?: number
          expires_at?: string | null
          id?: string
          is_active?: boolean
          max_uses?: number | null
          max_uses_per_customer?: number | null
          min_subtotal?: number | null
          starts_at?: string | null
          updated_at?: string
          usage_count?: number
        }
        Update: {
          code?: string
          code_upper?: string | null
          created_at?: string
          discount_type?: string
          discount_value?: number
          expires_at?: string | null
          id?: string
          is_active?: boolean
          max_uses?: number | null
          max_uses_per_customer?: number | null
          min_subtotal?: number | null
          starts_at?: string | null
          updated_at?: string
          usage_count?: number
        }
        Relationships: []
      }
      customer_product_replenishment_settings: {
        Row: {
          created_at: string | null
          custom_reminder_days: number | null
          id: string
          is_enabled: boolean | null
          last_reminder_sent: string | null
          product_id: string | null
          updated_at: string | null
          user_id: string | null
        }
        Insert: {
          created_at?: string | null
          custom_reminder_days?: number | null
          id?: string
          is_enabled?: boolean | null
          last_reminder_sent?: string | null
          product_id?: string | null
          updated_at?: string | null
          user_id?: string | null
        }
        Update: {
          created_at?: string | null
          custom_reminder_days?: number | null
          id?: string
          is_enabled?: boolean | null
          last_reminder_sent?: string | null
          product_id?: string | null
          updated_at?: string | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "customer_product_replenishment_settings_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
        ]
      }
      customer_purchase_patterns: {
        Row: {
          average_reorder_days: number | null
          confidence_score: number | null
          created_at: string | null
          first_purchase_date: string | null
          id: string
          is_active: boolean | null
          last_purchase_date: string | null
          predicted_reorder_date: string | null
          product_id: string | null
          total_purchases: number | null
          updated_at: string | null
          user_id: string | null
        }
        Insert: {
          average_reorder_days?: number | null
          confidence_score?: number | null
          created_at?: string | null
          first_purchase_date?: string | null
          id?: string
          is_active?: boolean | null
          last_purchase_date?: string | null
          predicted_reorder_date?: string | null
          product_id?: string | null
          total_purchases?: number | null
          updated_at?: string | null
          user_id?: string | null
        }
        Update: {
          average_reorder_days?: number | null
          confidence_score?: number | null
          created_at?: string | null
          first_purchase_date?: string | null
          id?: string
          is_active?: boolean | null
          last_purchase_date?: string | null
          predicted_reorder_date?: string | null
          product_id?: string | null
          total_purchases?: number | null
          updated_at?: string | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "customer_purchase_patterns_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
        ]
      }
      customer_replenishment_settings: {
        Row: {
          created_at: string | null
          id: string
          is_enabled: boolean | null
          max_monthly_reminders: number | null
          preferred_channel: string | null
          quiet_hours_end: string | null
          quiet_hours_start: string | null
          reminder_lead_days: number | null
          updated_at: string | null
          user_id: string | null
        }
        Insert: {
          created_at?: string | null
          id?: string
          is_enabled?: boolean | null
          max_monthly_reminders?: number | null
          preferred_channel?: string | null
          quiet_hours_end?: string | null
          quiet_hours_start?: string | null
          reminder_lead_days?: number | null
          updated_at?: string | null
          user_id?: string | null
        }
        Update: {
          created_at?: string | null
          id?: string
          is_enabled?: boolean | null
          max_monthly_reminders?: number | null
          preferred_channel?: string | null
          quiet_hours_end?: string | null
          quiet_hours_start?: string | null
          reminder_lead_days?: number | null
          updated_at?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      expenses: {
        Row: {
          amount: number
          category: string
          created_at: string
          date: string
          id: number
          note: string | null
          order_id: string | null
          product_id: string | null
        }
        Insert: {
          amount?: number
          category: string
          created_at?: string
          date?: string
          id?: number
          note?: string | null
          order_id?: string | null
          product_id?: string | null
        }
        Update: {
          amount?: number
          category?: string
          created_at?: string
          date?: string
          id?: number
          note?: string | null
          order_id?: string | null
          product_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "expenses_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "expenses_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
        ]
      }
      favorites: {
        Row: {
          created_at: string
          id: string
          product_id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          product_id: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          product_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "favorites_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
        ]
      }
      homepage_slides: {
        Row: {
          button1_link: string | null
          button1_text: string | null
          button2_link: string | null
          button2_text: string | null
          created_at: string | null
          display_order: number
          id: number
          image_url: string
          is_active: boolean
          mobile_crop_data: Json | null
          subtitle: string | null
          title: string
        }
        Insert: {
          button1_link?: string | null
          button1_text?: string | null
          button2_link?: string | null
          button2_text?: string | null
          created_at?: string | null
          display_order?: number
          id?: number
          image_url: string
          is_active?: boolean
          mobile_crop_data?: Json | null
          subtitle?: string | null
          title?: string
        }
        Update: {
          button1_link?: string | null
          button1_text?: string | null
          button2_link?: string | null
          button2_text?: string | null
          created_at?: string | null
          display_order?: number
          id?: number
          image_url?: string
          is_active?: boolean
          mobile_crop_data?: Json | null
          subtitle?: string | null
          title?: string
        }
        Relationships: []
      }
      nav_items: {
        Row: {
          created_at: string
          id: string
          is_enabled: boolean | null
          order: number | null
          title: string
          updated_at: string
          url: string
        }
        Insert: {
          created_at?: string
          id?: string
          is_enabled?: boolean | null
          order?: number | null
          title: string
          updated_at?: string
          url: string
        }
        Update: {
          created_at?: string
          id?: string
          is_enabled?: boolean | null
          order?: number | null
          title?: string
          updated_at?: string
          url?: string
        }
        Relationships: []
      }
      notifications: {
        Row: {
          created_at: string
          id: number
          is_read: boolean | null
          message: string
          order_id: string | null
          type: string
          user_id: string | null
        }
        Insert: {
          created_at?: string
          id?: number
          is_read?: boolean | null
          message: string
          order_id?: string | null
          type: string
          user_id?: string | null
        }
        Update: {
          created_at?: string
          id?: number
          is_read?: boolean | null
          message?: string
          order_id?: string | null
          type?: string
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "notifications_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
        ]
      }
      order_items: {
        Row: {
          created_at: string
          id: string
          order_id: string
          price: number
          product_id: string | null
          quantity: number
          unit_cost: number | null
          variant_data: Json | null
        }
        Insert: {
          created_at?: string
          id?: string
          order_id: string
          price: number
          product_id?: string | null
          quantity?: number
          unit_cost?: number | null
          variant_data?: Json | null
        }
        Update: {
          created_at?: string
          id?: string
          order_id?: string
          price?: number
          product_id?: string | null
          quantity?: number
          unit_cost?: number | null
          variant_data?: Json | null
        }
        Relationships: [
          {
            foreignKeyName: "order_items_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "order_items_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
        ]
      }
      orders: {
        Row: {
          created_at: string
          customer_email: string | null
          customer_name: string | null
          customer_phone: string | null
          id: string
          is_paid: boolean
          paid_at: string | null
          payment_method: string | null
          shipping_address: string | null
          status: string | null
          total_price: number | null
          user_id: string | null
        }
        Insert: {
          created_at?: string
          customer_email?: string | null
          customer_name?: string | null
          customer_phone?: string | null
          id?: string
          is_paid?: boolean
          paid_at?: string | null
          payment_method?: string | null
          shipping_address?: string | null
          status?: string | null
          total_price?: number | null
          user_id?: string | null
        }
        Update: {
          created_at?: string
          customer_email?: string | null
          customer_name?: string | null
          customer_phone?: string | null
          id?: string
          is_paid?: boolean
          paid_at?: string | null
          payment_method?: string | null
          shipping_address?: string | null
          status?: string | null
          total_price?: number | null
          user_id?: string | null
        }
        Relationships: []
      }
      pages: {
        Row: {
          content_html: string
          created_at: string | null
          enabled: boolean
          hero_image_url: string | null
          id: number
          meta_description: string | null
          meta_title: string | null
          slug: string
          title: string
          updated_at: string | null
        }
        Insert: {
          content_html?: string
          created_at?: string | null
          enabled?: boolean
          hero_image_url?: string | null
          id?: number
          meta_description?: string | null
          meta_title?: string | null
          slug: string
          title: string
          updated_at?: string | null
        }
        Update: {
          content_html?: string
          created_at?: string | null
          enabled?: boolean
          hero_image_url?: string | null
          id?: number
          meta_description?: string | null
          meta_title?: string | null
          slug?: string
          title?: string
          updated_at?: string | null
        }
        Relationships: []
      }
      pricing_global_settings: {
        Row: {
          created_at: string
          high_inventory_threshold: number
          id: number
          low_inventory_threshold: number
          max_price_step: number
          updated_at: string
        }
        Insert: {
          created_at?: string
          high_inventory_threshold?: number
          id?: number
          low_inventory_threshold?: number
          max_price_step?: number
          updated_at?: string
        }
        Update: {
          created_at?: string
          high_inventory_threshold?: number
          id?: number
          low_inventory_threshold?: number
          max_price_step?: number
          updated_at?: string
        }
        Relationships: []
      }
      pricing_history: {
        Row: {
          changed_at: string
          context: Json | null
          id: number
          new_price: number
          old_price: number
          product_id: string
          reason: string
        }
        Insert: {
          changed_at?: string
          context?: Json | null
          id?: number
          new_price: number
          old_price: number
          product_id: string
          reason: string
        }
        Update: {
          changed_at?: string
          context?: Json | null
          id?: number
          new_price?: number
          old_price?: number
          product_id?: string
          reason?: string
        }
        Relationships: [
          {
            foreignKeyName: "pricing_history_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
        ]
      }
      product_faqs: {
        Row: {
          answer: string
          created_at: string
          id: string
          position: number | null
          product_id: string
          question: string
        }
        Insert: {
          answer: string
          created_at?: string
          id?: string
          position?: number | null
          product_id: string
          question: string
        }
        Update: {
          answer?: string
          created_at?: string
          id?: string
          position?: number | null
          product_id?: string
          question?: string
        }
        Relationships: [
          {
            foreignKeyName: "product_faqs_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
        ]
      }
      product_images: {
        Row: {
          created_at: string
          id: string
          image_url: string
          position: number | null
          product_id: string | null
          title: string | null
          variant_id: string | null
        }
        Insert: {
          created_at?: string
          id?: string
          image_url: string
          position?: number | null
          product_id?: string | null
          title?: string | null
          variant_id?: string | null
        }
        Update: {
          created_at?: string
          id?: string
          image_url?: string
          position?: number | null
          product_id?: string | null
          title?: string | null
          variant_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "product_images_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "product_images_variant_id_fkey"
            columns: ["variant_id"]
            isOneToOne: false
            referencedRelation: "product_variants"
            referencedColumns: ["id"]
          },
        ]
      }
      product_pricing_settings: {
        Row: {
          cost_price: number
          created_at: string
          dynamic_pricing_enabled: boolean
          id: number
          last_computed_price: number | null
          last_run_at: string | null
          min_margin_percent: number
          product_id: string
          updated_at: string
        }
        Insert: {
          cost_price: number
          created_at?: string
          dynamic_pricing_enabled?: boolean
          id?: number
          last_computed_price?: number | null
          last_run_at?: string | null
          min_margin_percent?: number
          product_id: string
          updated_at?: string
        }
        Update: {
          cost_price?: number
          created_at?: string
          dynamic_pricing_enabled?: boolean
          id?: number
          last_computed_price?: number | null
          last_run_at?: string | null
          min_margin_percent?: number
          product_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "product_pricing_settings_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: true
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
        ]
      }
      product_recommendations: {
        Row: {
          created_at: string
          position: number | null
          product_id: string
          recommended_product_id: string
        }
        Insert: {
          created_at?: string
          position?: number | null
          product_id: string
          recommended_product_id: string
        }
        Update: {
          created_at?: string
          position?: number | null
          product_id?: string
          recommended_product_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "product_recommendations_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "product_recommendations_recommended_product_id_fkey"
            columns: ["recommended_product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
        ]
      }
      product_replenishment_settings: {
        Row: {
          average_usage_days: number | null
          category_replenishable: boolean | null
          created_at: string | null
          id: string
          is_replenishable: boolean | null
          max_monthly_reminders: number | null
          minimum_confidence_score: number | null
          product_id: string | null
          updated_at: string | null
        }
        Insert: {
          average_usage_days?: number | null
          category_replenishable?: boolean | null
          created_at?: string | null
          id?: string
          is_replenishable?: boolean | null
          max_monthly_reminders?: number | null
          minimum_confidence_score?: number | null
          product_id?: string | null
          updated_at?: string | null
        }
        Update: {
          average_usage_days?: number | null
          category_replenishable?: boolean | null
          created_at?: string | null
          id?: string
          is_replenishable?: boolean | null
          max_monthly_reminders?: number | null
          minimum_confidence_score?: number | null
          product_id?: string | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "product_replenishment_settings_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: true
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
        ]
      }
      product_variants: {
        Row: {
          compare_at_price: number | null
          created_at: string
          id: string
          is_on_sale: boolean | null
          original_price: number | null
          price: number
          product_id: string
          sku: string | null
          stock_quantity: number | null
          updated_at: string
          variant_name: string
        }
        Insert: {
          compare_at_price?: number | null
          created_at?: string
          id?: string
          is_on_sale?: boolean | null
          original_price?: number | null
          price: number
          product_id: string
          sku?: string | null
          stock_quantity?: number | null
          updated_at?: string
          variant_name: string
        }
        Update: {
          compare_at_price?: number | null
          created_at?: string
          id?: string
          is_on_sale?: boolean | null
          original_price?: number | null
          price?: number
          product_id?: string
          sku?: string | null
          stock_quantity?: number | null
          updated_at?: string
          variant_name?: string
        }
        Relationships: [
          {
            foreignKeyName: "product_variants_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
        ]
      }
      products: {
        Row: {
          category_id: string | null
          created_at: string
          description: string | null
          id: string
          is_featured: boolean | null
          is_hidden: boolean | null
          is_on_sale: boolean | null
          name: string
          price: number | null
          product_cost: number
          show_description: boolean
          show_faq: boolean
          show_recommendations: boolean
          track_stock: boolean | null
          updated_at: string
          variant_options: Json | null
        }
        Insert: {
          category_id?: string | null
          created_at?: string
          description?: string | null
          id?: string
          is_featured?: boolean | null
          is_hidden?: boolean | null
          is_on_sale?: boolean | null
          name: string
          price?: number | null
          product_cost?: number
          show_description?: boolean
          show_faq?: boolean
          show_recommendations?: boolean
          track_stock?: boolean | null
          updated_at?: string
          variant_options?: Json | null
        }
        Update: {
          category_id?: string | null
          created_at?: string
          description?: string | null
          id?: string
          is_featured?: boolean | null
          is_hidden?: boolean | null
          is_on_sale?: boolean | null
          name?: string
          price?: number | null
          product_cost?: number
          show_description?: boolean
          show_faq?: boolean
          show_recommendations?: boolean
          track_stock?: boolean | null
          updated_at?: string
          variant_options?: Json | null
        }
        Relationships: [
          {
            foreignKeyName: "products_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "categories"
            referencedColumns: ["id"]
          },
        ]
      }
      replenishment_reminders: {
        Row: {
          channel: string
          created_at: string | null
          id: string
          message_content: string | null
          order_id: string | null
          product_id: string | null
          reminder_date: string | null
          response_at: string | null
          response_message: string | null
          response_status: string | null
          sent_at: string | null
          updated_at: string | null
          user_id: string | null
        }
        Insert: {
          channel: string
          created_at?: string | null
          id?: string
          message_content?: string | null
          order_id?: string | null
          product_id?: string | null
          reminder_date?: string | null
          response_at?: string | null
          response_message?: string | null
          response_status?: string | null
          sent_at?: string | null
          updated_at?: string | null
          user_id?: string | null
        }
        Update: {
          channel?: string
          created_at?: string | null
          id?: string
          message_content?: string | null
          order_id?: string | null
          product_id?: string | null
          reminder_date?: string | null
          response_at?: string | null
          response_message?: string | null
          response_status?: string | null
          sent_at?: string | null
          updated_at?: string | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "replenishment_reminders_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "replenishment_reminders_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
        ]
      }
      reviews: {
        Row: {
          created_at: string | null
          enabled: boolean | null
          featured: boolean | null
          id: number
          position: number | null
          product_id: string | null
          rating: number
          review_text: string
          reviewer_name: string
          reviewer_photo_url: string | null
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          enabled?: boolean | null
          featured?: boolean | null
          id?: number
          position?: number | null
          product_id?: string | null
          rating: number
          review_text: string
          reviewer_name: string
          reviewer_photo_url?: string | null
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          enabled?: boolean | null
          featured?: boolean | null
          id?: number
          position?: number | null
          product_id?: string | null
          rating?: number
          review_text?: string
          reviewer_name?: string
          reviewer_photo_url?: string | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "reviews_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
        ]
      }
      site_settings: {
        Row: {
          about_content: string | null
          about_section_html: string | null
          about_section_image_url: string | null
          about_section_title: string | null
          ai_moderation_enabled: boolean | null
          announcement_bar_bg_color: string | null
          announcement_bar_enabled: boolean
          announcement_bar_text: string | null
          auto_publish_min_stars: number | null
          block_spam_reviews: boolean | null
          company_name: string | null
          concept_final_slider_enabled: boolean
          concept_image_url: string | null
          contact_address: string | null
          contact_email: string | null
          contact_phone: string | null
          created_at: string
          currency: string
          favicon_url: string | null
          featured_products_description: string | null
          featured_products_layout: Json | null
          featured_products_title: string | null
          final_image_url: string | null
          footer_copyright: string | null
          free_shipping_enabled: boolean | null
          free_shipping_text: string | null
          hero_media_mode: string
          hero_slide_duration_ms: number
          hero_slider_autoplay: boolean
          hero_slider_enabled: boolean
          hero_slider_interval_ms: number
          hero_slider_pause_on_hover: boolean
          hero_video_mobile_crop: Json | null
          hero_video_url: string | null
          highlights_section_title: string | null
          homepage_section_order: Json | null
          id: number
          logo_url: string | null
          meta_description: string | null
          meta_title: string | null
          moderation_enabled: boolean | null
          omt_number: string | null
          omt_owner_name: string | null
          on_sale_products_description: string | null
          on_sale_products_layout: Json | null
          on_sale_products_title: string | null
          order_email_enabled: boolean | null
          order_notification_email: string | null
          payment_apple_pay_enabled: boolean | null
          payment_cod_enabled: boolean | null
          payment_google_pay_enabled: boolean | null
          payment_instructions: string | null
          payment_mastercard_enabled: boolean | null
          payment_paypal_enabled: boolean | null
          payment_visa_enabled: boolean | null
          payment_whish_money_enabled: boolean | null
          promotions_html: string | null
          quality_description: string | null
          quality_enabled: boolean | null
          quality_icon: string | null
          quality_title: string | null
          returns_text: string | null
          secure_payments_enabled: boolean | null
          secure_payments_text: string | null
          send_below_stars_to_moderation: number | null
          shipping_description: string | null
          shipping_enabled: boolean | null
          shipping_icon: string | null
          shipping_time_max_days: number | null
          shipping_time_min_days: number | null
          shipping_title: string | null
          show_about_section: boolean | null
          show_featured_products: boolean | null
          show_on_sale_products: boolean | null
          show_promotions_section: boolean | null
          show_social_section: boolean | null
          show_testimonials_section: boolean | null
          site_description: string | null
          site_title: string | null
          social_facebook_enabled: boolean | null
          social_facebook_url: string | null
          social_instagram_enabled: boolean | null
          social_instagram_url: string | null
          social_tiktok_enabled: boolean | null
          social_tiktok_url: string | null
          social_twitter_enabled: boolean | null
          social_twitter_url: string | null
          social_whatsapp_enabled: boolean | null
          social_whatsapp_url: string | null
          social_youtube_enabled: boolean | null
          social_youtube_url: string | null
          store_email: string | null
          support_description: string | null
          support_enabled: boolean | null
          support_icon: string | null
          support_title: string | null
          updated_at: string
          video_feed_autoplay_enabled: boolean | null
          video_feed_count: number | null
          video_feed_enabled: boolean | null
          video_feed_refresh_minutes: number | null
          whatsapp_enabled: boolean
          whatsapp_number1: string | null
          whatsapp_number2: string | null
          whish_number: string | null
          whish_owner_name: string | null
        }
        Insert: {
          about_content?: string | null
          about_section_html?: string | null
          about_section_image_url?: string | null
          about_section_title?: string | null
          ai_moderation_enabled?: boolean | null
          announcement_bar_bg_color?: string | null
          announcement_bar_enabled?: boolean
          announcement_bar_text?: string | null
          auto_publish_min_stars?: number | null
          block_spam_reviews?: boolean | null
          company_name?: string | null
          concept_final_slider_enabled?: boolean
          concept_image_url?: string | null
          contact_address?: string | null
          contact_email?: string | null
          contact_phone?: string | null
          created_at?: string
          currency?: string
          favicon_url?: string | null
          featured_products_description?: string | null
          featured_products_layout?: Json | null
          featured_products_title?: string | null
          final_image_url?: string | null
          footer_copyright?: string | null
          free_shipping_enabled?: boolean | null
          free_shipping_text?: string | null
          hero_media_mode?: string
          hero_slide_duration_ms?: number
          hero_slider_autoplay?: boolean
          hero_slider_enabled?: boolean
          hero_slider_interval_ms?: number
          hero_slider_pause_on_hover?: boolean
          hero_video_mobile_crop?: Json | null
          hero_video_url?: string | null
          highlights_section_title?: string | null
          homepage_section_order?: Json | null
          id?: number
          logo_url?: string | null
          meta_description?: string | null
          meta_title?: string | null
          moderation_enabled?: boolean | null
          omt_number?: string | null
          omt_owner_name?: string | null
          on_sale_products_description?: string | null
          on_sale_products_layout?: Json | null
          on_sale_products_title?: string | null
          order_email_enabled?: boolean | null
          order_notification_email?: string | null
          payment_apple_pay_enabled?: boolean | null
          payment_cod_enabled?: boolean | null
          payment_google_pay_enabled?: boolean | null
          payment_instructions?: string | null
          payment_mastercard_enabled?: boolean | null
          payment_paypal_enabled?: boolean | null
          payment_visa_enabled?: boolean | null
          payment_whish_money_enabled?: boolean | null
          promotions_html?: string | null
          quality_description?: string | null
          quality_enabled?: boolean | null
          quality_icon?: string | null
          quality_title?: string | null
          returns_text?: string | null
          secure_payments_enabled?: boolean | null
          secure_payments_text?: string | null
          send_below_stars_to_moderation?: number | null
          shipping_description?: string | null
          shipping_enabled?: boolean | null
          shipping_icon?: string | null
          shipping_time_max_days?: number | null
          shipping_time_min_days?: number | null
          shipping_title?: string | null
          show_about_section?: boolean | null
          show_featured_products?: boolean | null
          show_on_sale_products?: boolean | null
          show_promotions_section?: boolean | null
          show_social_section?: boolean | null
          show_testimonials_section?: boolean | null
          site_description?: string | null
          site_title?: string | null
          social_facebook_enabled?: boolean | null
          social_facebook_url?: string | null
          social_instagram_enabled?: boolean | null
          social_instagram_url?: string | null
          social_tiktok_enabled?: boolean | null
          social_tiktok_url?: string | null
          social_twitter_enabled?: boolean | null
          social_twitter_url?: string | null
          social_whatsapp_enabled?: boolean | null
          social_whatsapp_url?: string | null
          social_youtube_enabled?: boolean | null
          social_youtube_url?: string | null
          store_email?: string | null
          support_description?: string | null
          support_enabled?: boolean | null
          support_icon?: string | null
          support_title?: string | null
          updated_at?: string
          video_feed_autoplay_enabled?: boolean | null
          video_feed_count?: number | null
          video_feed_enabled?: boolean | null
          video_feed_refresh_minutes?: number | null
          whatsapp_enabled?: boolean
          whatsapp_number1?: string | null
          whatsapp_number2?: string | null
          whish_number?: string | null
          whish_owner_name?: string | null
        }
        Update: {
          about_content?: string | null
          about_section_html?: string | null
          about_section_image_url?: string | null
          about_section_title?: string | null
          ai_moderation_enabled?: boolean | null
          announcement_bar_bg_color?: string | null
          announcement_bar_enabled?: boolean
          announcement_bar_text?: string | null
          auto_publish_min_stars?: number | null
          block_spam_reviews?: boolean | null
          company_name?: string | null
          concept_final_slider_enabled?: boolean
          concept_image_url?: string | null
          contact_address?: string | null
          contact_email?: string | null
          contact_phone?: string | null
          created_at?: string
          currency?: string
          favicon_url?: string | null
          featured_products_description?: string | null
          featured_products_layout?: Json | null
          featured_products_title?: string | null
          final_image_url?: string | null
          footer_copyright?: string | null
          free_shipping_enabled?: boolean | null
          free_shipping_text?: string | null
          hero_media_mode?: string
          hero_slide_duration_ms?: number
          hero_slider_autoplay?: boolean
          hero_slider_enabled?: boolean
          hero_slider_interval_ms?: number
          hero_slider_pause_on_hover?: boolean
          hero_video_mobile_crop?: Json | null
          hero_video_url?: string | null
          highlights_section_title?: string | null
          homepage_section_order?: Json | null
          id?: number
          logo_url?: string | null
          meta_description?: string | null
          meta_title?: string | null
          moderation_enabled?: boolean | null
          omt_number?: string | null
          omt_owner_name?: string | null
          on_sale_products_description?: string | null
          on_sale_products_layout?: Json | null
          on_sale_products_title?: string | null
          order_email_enabled?: boolean | null
          order_notification_email?: string | null
          payment_apple_pay_enabled?: boolean | null
          payment_cod_enabled?: boolean | null
          payment_google_pay_enabled?: boolean | null
          payment_instructions?: string | null
          payment_mastercard_enabled?: boolean | null
          payment_paypal_enabled?: boolean | null
          payment_visa_enabled?: boolean | null
          payment_whish_money_enabled?: boolean | null
          promotions_html?: string | null
          quality_description?: string | null
          quality_enabled?: boolean | null
          quality_icon?: string | null
          quality_title?: string | null
          returns_text?: string | null
          secure_payments_enabled?: boolean | null
          secure_payments_text?: string | null
          send_below_stars_to_moderation?: number | null
          shipping_description?: string | null
          shipping_enabled?: boolean | null
          shipping_icon?: string | null
          shipping_time_max_days?: number | null
          shipping_time_min_days?: number | null
          shipping_title?: string | null
          show_about_section?: boolean | null
          show_featured_products?: boolean | null
          show_on_sale_products?: boolean | null
          show_promotions_section?: boolean | null
          show_social_section?: boolean | null
          show_testimonials_section?: boolean | null
          site_description?: string | null
          site_title?: string | null
          social_facebook_enabled?: boolean | null
          social_facebook_url?: string | null
          social_instagram_enabled?: boolean | null
          social_instagram_url?: string | null
          social_tiktok_enabled?: boolean | null
          social_tiktok_url?: string | null
          social_twitter_enabled?: boolean | null
          social_twitter_url?: string | null
          social_whatsapp_enabled?: boolean | null
          social_whatsapp_url?: string | null
          social_youtube_enabled?: boolean | null
          social_youtube_url?: string | null
          store_email?: string | null
          support_description?: string | null
          support_enabled?: boolean | null
          support_icon?: string | null
          support_title?: string | null
          updated_at?: string
          video_feed_autoplay_enabled?: boolean | null
          video_feed_count?: number | null
          video_feed_enabled?: boolean | null
          video_feed_refresh_minutes?: number | null
          whatsapp_enabled?: boolean
          whatsapp_number1?: string | null
          whatsapp_number2?: string | null
          whish_number?: string | null
          whish_owner_name?: string | null
        }
        Relationships: []
      }
      store_highlights: {
        Row: {
          created_at: string
          description: string | null
          icon: string | null
          id: string
          is_enabled: boolean
          position: number
          title: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          icon?: string | null
          id?: string
          is_enabled?: boolean
          position?: number
          title?: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          description?: string | null
          icon?: string | null
          id?: string
          is_enabled?: boolean
          position?: number
          title?: string
          updated_at?: string
        }
        Relationships: []
      }
      user_profiles: {
        Row: {
          created_at: string
          email: string | null
          id: string
          name: string | null
          user_id: string
        }
        Insert: {
          created_at?: string
          email?: string | null
          id?: string
          name?: string | null
          user_id: string
        }
        Update: {
          created_at?: string
          email?: string | null
          id?: string
          name?: string | null
          user_id?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      video_feed: {
        Row: {
          account_handle: string | null
          autoplay: boolean | null
          created_at: string
          enabled: boolean | null
          id: number
          item_count: number | null
          platform: string | null
          published_at: string | null
          refresh_minutes: number | null
          row_type: string
          settings_id: number | null
          thumbnail_url: string | null
          title: string | null
          updated_at: string
          url: string | null
        }
        Insert: {
          account_handle?: string | null
          autoplay?: boolean | null
          created_at?: string
          enabled?: boolean | null
          id?: number
          item_count?: number | null
          platform?: string | null
          published_at?: string | null
          refresh_minutes?: number | null
          row_type: string
          settings_id?: number | null
          thumbnail_url?: string | null
          title?: string | null
          updated_at?: string
          url?: string | null
        }
        Update: {
          account_handle?: string | null
          autoplay?: boolean | null
          created_at?: string
          enabled?: boolean | null
          id?: number
          item_count?: number | null
          platform?: string | null
          published_at?: string | null
          refresh_minutes?: number | null
          row_type?: string
          settings_id?: number | null
          thumbnail_url?: string | null
          title?: string | null
          updated_at?: string
          url?: string | null
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      clamp_price_step: {
        Args: { current_price: number; max_step: number; target_price: number }
        Returns: number
      }
      compute_dynamic_price: { Args: { p_product_id: string }; Returns: number }
      compute_min_allowed_price: {
        Args: { cost_price: number; margin_pct: number }
        Returns: number
      }
      delete_stale_unpaid_orders: { Args: never; Returns: undefined }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      is_admin: { Args: never; Returns: boolean }
      match_products: {
        Args: { match_limit?: number; query_embedding: string }
        Returns: {
          product_id: string
          similarity: number
        }[]
      }
      run_dynamic_pricing_cycle: { Args: never; Returns: undefined }
      validate_coupon: {
        Args: { p_code: string; p_customer_email: string; p_subtotal: number }
        Returns: Json
      }
    }
    Enums: {
      app_role: "admin" | "moderator" | "user"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "moderator", "user"],
    },
  },
} as const
