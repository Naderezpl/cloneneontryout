import { supabase } from "@/lib/supabase";
import { fetchSiteSettings } from "@/api/settings";

export interface Review {
  id?: number;
  product_id?: string | null;
  reviewer_name: string;
  reviewer_photo_url?: string | null;
  rating: number;
  review_text: string;
  featured?: boolean;
  enabled?: boolean;
  position?: number;
  created_at?: string;
  updated_at?: string;
}

export type ModerationStatus = 'approved' | 'pending' | 'rejected';

export interface ModerationResult {
  status: ModerationStatus;
  aiScore: number;
  reasons: string[];
}

export function analyzeReviewContent(rating: number, text: string): ModerationResult {
  const t = (text || '').toLowerCase();
  const offensive = [
    'idiot','stupid','dumb','trash','hate','racist','sexist','fraud','scam'
  ];
  const complaint = [
    'broken','not working','late','delay','refund','return','bad quality','poor quality','fake','counterfeit','damaged','defective','doesn\'t work','didn\'t work','missing','never arrived','no response'
  ];
  const spamIndicators = [
    'http://','https://','.com','.ru','.cn','free money','click here','buy now'
  ];
  const repeatedChar = /(.)\1{4,}/;
  const repeatedPhrase = /(.+)\s+\1{2,}/;
  let score = 0.5;
  const reasons: string[] = [];
  let hasOffensive = false;
  for (const w of offensive) {
    if (t.includes(w)) {
      hasOffensive = true;
      reasons.push('offensive_language');
      score -= 0.3;
      break;
    }
  }
  let hasSpam = false;
  for (const s of spamIndicators) {
    if (t.includes(s)) {
      hasSpam = true;
      reasons.push('spam_pattern');
      score -= 0.3;
      break;
    }
  }
  if (repeatedChar.test(t) || repeatedPhrase.test(t)) {
    hasSpam = true;
    reasons.push('repetition_pattern');
    score -= 0.2;
  }
  let hasComplaint = false;
  for (const c of complaint) {
    if (t.includes(c)) {
      hasComplaint = true;
      reasons.push('complaint_keywords');
      score -= 0.1;
      break;
    }
  }
  if ((text || '').length < 5) {
    reasons.push('too_short');
    score -= 0.1;
  } else if ((text || '').length > 500) {
    reasons.push('too_long');
    score -= 0.05;
  }
  if (rating >= 4 && !hasSpam && !hasOffensive) {
    score += 0.2;
  }
  if (rating <= 2) {
    reasons.push('low_rating');
    score -= 0.1;
  }
  if (score > 0.6 && !hasSpam && !hasOffensive && rating >= 4) {
    return { status: 'approved', aiScore: Math.min(1, Math.max(0, score)), reasons };
  }
  if (hasOffensive || hasSpam) {
    return { status: 'rejected', aiScore: Math.min(1, Math.max(0, score)), reasons };
  }
  return { status: 'pending', aiScore: Math.min(1, Math.max(0, score)), reasons };
}

export async function listReviews(productId?: string) {
  let query = supabase.from('reviews').select('*').order('created_at', { ascending: false });
  if (productId) query = query.eq('product_id', productId);
  const { data, error } = await query;
  if (error) throw new Error(error.message);
  return (data || []) as Review[];
}

export async function upsertReview(review: Partial<Review>) {
  const payload = { ...review };
  const { data, error } = await supabase.from('reviews').upsert(payload).select().single();
  if (error) throw new Error(error.message);
  return data as Review;
}

export async function deleteReview(id: number) {
  const { error } = await supabase.from('reviews').delete().eq('id', id);
  if (error) throw new Error(error.message);
}

export async function createReview(review: {
  product_id?: string | null;
  reviewer_name: string;
  rating: number;
  review_text: string;
}) {
  const settings = await fetchSiteSettings().catch(() => null as any);
  const moderationEnabled = settings?.moderation_enabled ?? true;
  const aiEnabled = settings?.ai_moderation_enabled ?? true;
  const autoPublishMinStars = settings?.auto_publish_min_stars ?? 4;
  const sendBelowStarsToModeration = settings?.send_below_stars_to_moderation ?? 3;
  const blockSpam = settings?.block_spam_reviews ?? true;
  const a = aiEnabled ? analyzeReviewContent(Number(review.rating) || 5, review.review_text || '') : { status: 'approved', aiScore: 0.8, reasons: [] as string[] };
  let status: ModerationStatus = 'approved';
  if (!moderationEnabled) {
    status = 'approved';
  } else {
    if (a.status === 'rejected' && blockSpam) {
      status = 'rejected';
    } else if ((Number(review.rating) || 5) >= autoPublishMinStars && a.status !== 'rejected') {
      status = 'approved';
    } else if ((Number(review.rating) || 5) <= sendBelowStarsToModeration || a.status === 'pending') {
      status = 'pending';
    } else {
      status = 'approved';
    }
  }
  const payload = {
    product_id: review.product_id ?? null,
    reviewer_name: review.reviewer_name,
    rating: Math.max(1, Math.min(5, Number(review.rating) || 5)),
    review_text: review.review_text,
    enabled: status === 'approved',
    featured: false,
  };
  const { data, error } = await supabase
    .from('reviews')
    .insert(payload)
    .select()
    .single();
  if (error) throw new Error(error.message);
  const inserted = data as Review;
  try {
    await supabase.from('review_moderation_logs').insert({
      review_id: inserted.id,
      moderation_status: status,
      ai_score: a.aiScore,
      moderation_reason: (a.reasons || []).join(', '),
    });
  } catch (_) {}
  if (status === 'rejected') {
    try {
      await supabase.from('review_flags').insert({
        review_id: inserted.id,
        flag_type: 'spam_or_abusive',
      });
    } catch (_) {}
  }
  return inserted;
}

export async function addReviewReply(reviewId: number, replyText: string) {
  try {
    await supabase.from('review_moderation_logs').insert({
      review_id: reviewId,
      flag_type: 'reply',
      moderation_reason: replyText,
    });
  } catch (_) {}
}
