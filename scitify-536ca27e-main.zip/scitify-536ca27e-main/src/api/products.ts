import { supabase } from "@/lib/supabase";
import { Product, ProductVariant, ProductImage, Category, adaptProductForUI } from "@/types/product";

export async function fetchProducts(): Promise<Product[]> {
  const { data: productsData, error: productsError } = await supabase
    .from('products')
    .select('*')
    .eq('is_hidden', false);
  
  if (productsError) {
    console.error('Error fetching products:', productsError);
    throw new Error(productsError.message);
  }

  // Get variants and images for each product
  const products = await Promise.all((productsData || []).map(async (product) => {
    const adaptedProduct: Product = {
      id: product.id,
      name: product.name,
      description: product.description || '',
      category_id: product.category_id || '',
      is_hidden: product.is_hidden,
      is_featured: product.is_featured,
      is_on_sale: product.is_on_sale,
      track_stock: product.track_stock
    };
    
    // Fetch variants
    const { data: variants, error: variantsError } = await supabase
      .from('product_variants')
      .select('*')
      .eq('product_id', product.id);
    
    if (variantsError) {
      console.error(`Error fetching variants for product ${product.id}:`, variantsError);
    } else {
      adaptedProduct.variants = variants || [];
    }

    // Fetch images
    const { data: images, error: imagesError } = await supabase
      .from('product_images')
      .select('*')
      .eq('product_id', product.id)
      .order('position');
    
    if (imagesError) {
      console.error(`Error fetching images for product ${product.id}:`, imagesError);
    } else {
      adaptedProduct.images = images || [];

      // Assign images to variants
      if (adaptedProduct.variants && images) {
        adaptedProduct.variants.forEach(variant => {
          variant.images = images.filter(image => image.variant_id === variant.id);
        });
      }
    }
    
    return adaptedProduct;
  }));
  
  return products;
}

export async function fetchProduct(id: string): Promise<Product | null> {
  // Fetch the product
  const { data: product, error: productError } = await supabase
    .from('products')
    .select('*')
    .eq('id', id)
    .single();
  
  if (productError) {
    console.error(`Error fetching product ${id}:`, productError);
    throw new Error(productError.message);
  }

  if (!product) return null;

  const adaptedProduct: Product = {
    id: product.id,
    name: product.name,
    description: product.description || '',
    category_id: product.category_id || '',
    is_hidden: product.is_hidden,
    is_featured: product.is_featured,
    is_on_sale: product.is_on_sale,
    track_stock: product.track_stock
  };

  // Fetch variants
  const { data: variants, error: variantsError } = await supabase
    .from('product_variants')
    .select('*')
    .eq('product_id', id);
  
  if (variantsError) {
    console.error(`Error fetching variants for product ${id}:`, variantsError);
  } else {
    adaptedProduct.variants = variants || [];
  }

  // Fetch images
  const { data: images, error: imagesError } = await supabase
    .from('product_images')
    .select('*')
    .eq('product_id', id)
    .order('position');
  
  if (imagesError) {
    console.error(`Error fetching images for product ${id}:`, imagesError);
  } else {
    adaptedProduct.images = images || [];

    // Assign images to variants
    if (adaptedProduct.variants && images) {
      adaptedProduct.variants.forEach(variant => {
        variant.images = images.filter(image => image.variant_id === variant.id);
      });
    }
  }
  
  return adaptedProduct;
}

export async function fetchCategories(): Promise<Category[]> {
  const { data, error } = await supabase
    .from('categories')
    .select('*')
    .order('name');
  
  if (error) {
    console.error('Error fetching categories:', error);
    throw new Error(error.message);
  }
  
  return data || [];
}

export async function fetchFeaturedProducts(): Promise<Product[]> {
  const { data, error } = await supabase
    .from('products')
    .select('*, product_variants(*), product_images(*)')
    .eq('is_featured', true)
    .eq('is_hidden', false)
    .limit(4);
  
  if (error) {
    console.error('Error fetching featured products:', error);
    throw new Error(error.message);
  }

  // Map the product_variants to variants and product_images to images
  const mappedProducts = (data || []).map(product => {
    return {
      ...product,
      variants: product.product_variants,
      images: product.product_images
    };
  });

  // Use adaptProductForUI to fix the type conversion
  return mappedProducts.map(product => adaptProductForUI(product));
}

export async function fetchPopularProducts(): Promise<Product[]> {
  // We'll just return all products for now
  return fetchProducts();
}

export async function searchProducts(query: string): Promise<Product[]> {
  const { data, error } = await supabase
    .from('products')
    .select('*')
    .eq('is_hidden', false)
    .ilike('name', `%${query}%`)
    .or(`description.ilike.%${query}%`);
  
  if (error) {
    console.error('Error searching products:', error);
    throw new Error(error.message);
  }

  const products = await Promise.all((data || []).map(async (product) => {
    const adaptedProduct: Product = {
      id: product.id,
      name: product.name,
      description: product.description || '',
      category_id: product.category_id || '',
      is_hidden: product.is_hidden,
      is_featured: product.is_featured,
      is_on_sale: product.is_on_sale,
      track_stock: product.track_stock
    };
    
    // Fetch variants
    const { data: variants, error: variantsError } = await supabase
      .from('product_variants')
      .select('*')
      .eq('product_id', product.id);
    
    if (variantsError) {
      console.error(`Error fetching variants for product ${product.id}:`, variantsError);
    } else {
      adaptedProduct.variants = variants || [];
    }

    // Fetch images
    const { data: images, error: imagesError } = await supabase
      .from('product_images')
      .select('*')
      .eq('product_id', product.id)
      .order('position');
    
    if (imagesError) {
      console.error(`Error fetching images for product ${product.id}:`, imagesError);
    } else {
      adaptedProduct.images = images || [];
    }
    
    return adaptedProduct;
  }));
  
  return products;
}

export function getProductMinPrice(product: Product): number {
  if (!product.variants || product.variants.length === 0) {
    return product.price || 0;
  }
  
  return Math.min(...product.variants.map(variant => variant.price));
}
