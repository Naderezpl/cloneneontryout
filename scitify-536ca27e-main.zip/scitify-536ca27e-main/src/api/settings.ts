
import { supabase } from "@/lib/supabase";
import { SiteSettings } from "@/types/settings";

export async function fetchSiteSettings(): Promise<SiteSettings> {
  const { data, error } = await supabase
    .from('site_settings')
    .select('*')
    .order('id', { ascending: false })
    .limit(1)
    .maybeSingle();

  if (error) {
    console.error('Error fetching site settings:', error);
    // Return default values if no settings found
    if (error.code === 'PGRST116' || error.message.includes('No rows')) {
      return getDefaultSettings();
    }
    throw new Error(error.message);
  }

  // Add a cache-busting timestamp to ensure we're not getting cached data
  console.log('Fetched site settings at:', new Date().toISOString());
  
  return {
    site_title: data?.site_title || data?.company_name || 'LINKORA',
    site_description: data?.site_description || '',
    logo_url: data?.logo_url || '/logo.png',
    favicon_url: data?.favicon_url || data?.logo_url || '/logo.png',
    store_email: data?.store_email || data?.contact_email || data?.order_notification_email || 'info@linkora.com',
    order_email_enabled: data?.order_email_enabled === undefined ? true : !!data?.order_email_enabled,
    order_notification_email: data?.order_notification_email || data?.contact_email || 'info@linkora.com',
    meta_title: data?.meta_title || data?.company_name || 'LINKORA',
    meta_description: data?.meta_description || '',
    company_name: data?.company_name || 'LINKORA',
    contact_email: data?.contact_email || 'info@linkora.com',
    contact_phone: data?.contact_phone || '(555) 123-4567',
    contact_address: data?.contact_address || '123 Neon Street, Glow City, NG 12345',
    whatsapp_enabled: data?.whatsapp_enabled === undefined ? false : !!data?.whatsapp_enabled,
    whatsapp_number1: data?.whatsapp_number1 ?? null,
    whatsapp_number2: data?.whatsapp_number2 ?? null,
    show_featured_products:
      data?.show_featured_products === undefined ? true : !!data?.show_featured_products,
    show_on_sale_products:
      data?.show_on_sale_products === undefined ? true : !!data?.show_on_sale_products,
    featured_products_title: data?.featured_products_title || "",
    on_sale_products_title: data?.on_sale_products_title || "",
    featured_products_description: data?.featured_products_description || "",
    on_sale_products_description: data?.on_sale_products_description || "",
    show_about_section: data?.show_about_section === undefined ? false : !!data?.show_about_section,
    about_section_title: data?.about_section_title || "Our Story",
    about_section_html: data?.about_section_html || "",
    about_section_image_url: data?.about_section_image_url ?? null,
    show_testimonials_section: data?.show_testimonials_section === undefined ? true : !!data?.show_testimonials_section,
    show_social_section: data?.show_social_section === undefined ? true : !!data?.show_social_section,
    show_promotions_section: data?.show_promotions_section === undefined ? false : !!data?.show_promotions_section,
    promotions_html: data?.promotions_html || "",
    free_shipping_enabled: data?.free_shipping_enabled === undefined ? true : !!data?.free_shipping_enabled,
    free_shipping_text: data?.free_shipping_text || "Free Shipping over $50",
    secure_payments_enabled: data?.secure_payments_enabled === undefined ? true : !!data?.secure_payments_enabled,
    secure_payments_text: data?.secure_payments_text || "Secure Payments",
    payment_visa_enabled: !!data?.payment_visa_enabled,
    payment_mastercard_enabled: !!data?.payment_mastercard_enabled,
    payment_apple_pay_enabled: !!data?.payment_apple_pay_enabled,
    payment_google_pay_enabled: !!data?.payment_google_pay_enabled,
    payment_paypal_enabled: !!data?.payment_paypal_enabled,
    payment_cod_enabled: data?.payment_cod_enabled === undefined ? true : !!data?.payment_cod_enabled,
    payment_whish_money_enabled: !!data?.payment_whish_money_enabled,
    whish_number: data?.whish_number ?? null,
    whish_owner_name: data?.whish_owner_name ?? null,
    omt_number: data?.omt_number ?? null,
    omt_owner_name: data?.omt_owner_name ?? null,
    payment_instructions: data?.payment_instructions ?? null,
    footer_copyright: data?.footer_copyright || "",
    social_instagram_enabled: !!data?.social_instagram_enabled,
    social_instagram_url: data?.social_instagram_url ?? null,
    social_facebook_enabled: !!data?.social_facebook_enabled,
    social_facebook_url: data?.social_facebook_url ?? null,
    social_tiktok_enabled: !!data?.social_tiktok_enabled,
    social_tiktok_url: data?.social_tiktok_url ?? null,
    social_youtube_enabled: !!data?.social_youtube_enabled,
    social_youtube_url: data?.social_youtube_url ?? null,
    social_whatsapp_enabled: !!data?.social_whatsapp_enabled,
    social_whatsapp_url: data?.social_whatsapp_url ?? null,
    social_twitter_enabled: !!data?.social_twitter_enabled,
    social_twitter_url: data?.social_twitter_url ?? null,
    shipping_enabled: data?.shipping_enabled === undefined ? true : !!data?.shipping_enabled,
    shipping_title: data?.shipping_title || '',
    shipping_description: data?.shipping_description || '',
    shipping_icon: data?.shipping_icon ?? 'Truck',
    quality_enabled: data?.quality_enabled === undefined ? true : !!data?.quality_enabled,
    quality_title: data?.quality_title || 'Premium materials and trusted performance',
    quality_description: data?.quality_description || '',
    quality_icon: data?.quality_icon ?? 'Shield',
    support_enabled: data?.support_enabled === undefined ? true : !!data?.support_enabled,
    support_title: data?.support_title || 'Always here to help',
    support_description: data?.support_description || '',
    support_icon: data?.support_icon ?? 'Headphones',
    video_feed_enabled: data?.video_feed_enabled === undefined ? false : !!data?.video_feed_enabled,
    video_feed_count: data?.video_feed_count === undefined ? 6 : Number(data?.video_feed_count),
    video_feed_refresh_minutes: data?.video_feed_refresh_minutes === undefined ? 30 : Number(data?.video_feed_refresh_minutes),
    video_feed_autoplay_enabled: data?.video_feed_autoplay_enabled === undefined ? false : !!data?.video_feed_autoplay_enabled,
    hero_slider_enabled: data?.hero_slider_enabled === undefined ? true : !!data?.hero_slider_enabled,
    hero_slider_autoplay: data?.hero_slider_autoplay === undefined ? true : !!data?.hero_slider_autoplay,
    hero_slider_interval_ms: data?.hero_slider_interval_ms === undefined ? 5000 : Number(data?.hero_slider_interval_ms),
    hero_slider_pause_on_hover: data?.hero_slider_pause_on_hover === undefined ? true : !!data?.hero_slider_pause_on_hover,
    concept_final_slider_enabled: data?.concept_final_slider_enabled === undefined ? true : !!data?.concept_final_slider_enabled,
    concept_image_url: data?.concept_image_url ?? null,
    final_image_url: data?.final_image_url ?? null,
    homepage_section_order: Array.isArray(data?.homepage_section_order) ? data.homepage_section_order : ['hero','categories','highlights','featured','onsale','about','testimonials','reviews','promotions','newsletter'],
    hero_media_mode: data?.hero_media_mode || 'video',
    hero_video_url: data?.hero_video_url ?? null,
    hero_slide_duration_ms: data?.hero_slide_duration_ms ?? 5000,
    announcement_bar_enabled: data?.announcement_bar_enabled === undefined ? true : !!data?.announcement_bar_enabled,
    announcement_bar_text: data?.announcement_bar_text ?? '',
    announcement_bar_bg_color: data?.announcement_bar_bg_color ?? '#1a1a1a',
    hero_video_mobile_crop: data?.hero_video_mobile_crop ?? null,
    returns_text: data?.returns_text || 'Easy Returns',
    highlights_section_title: data?.highlights_section_title ?? null,
  };
}

export function getDefaultSettings(): SiteSettings {
  return {
    site_title: 'LINKORA',
    site_description: '',
    logo_url: '/logo.png',
    favicon_url: '/logo.png',
    store_email: 'info@linkora.com',
    order_email_enabled: true,
    order_notification_email: 'info@linkora.com',
    meta_title: 'LINKORA',
    meta_description: '',
    company_name: 'LINKORA',
    contact_email: 'info@linkora.com',
    contact_phone: '(555) 123-4567',
    contact_address: '123 Neon Street, Glow City, NG 12345',
    whatsapp_enabled: false,
    whatsapp_number1: null,
    whatsapp_number2: null,
    show_featured_products: true,
    show_on_sale_products: true,
    featured_products_title: '',
    on_sale_products_title: '',
    featured_products_description: '',
    on_sale_products_description: '',
    show_about_section: false,
    about_section_title: 'Our Story',
    about_section_html: '',
    about_section_image_url: null,
    show_testimonials_section: true,
    show_social_section: true,
    show_promotions_section: false,
    promotions_html: '',
    free_shipping_enabled: true,
    free_shipping_text: 'Free Shipping over $50',
    secure_payments_enabled: true,
    secure_payments_text: 'Secure Payments',
    payment_visa_enabled: false,
    payment_mastercard_enabled: false,
    payment_apple_pay_enabled: false,
    payment_google_pay_enabled: false,
    payment_paypal_enabled: false,
    payment_cod_enabled: true,
    payment_whish_money_enabled: false,
    whish_number: null,
    whish_owner_name: null,
    omt_number: null,
    omt_owner_name: null,
    payment_instructions: null,
    footer_copyright: '',
    social_instagram_enabled: false,
    social_instagram_url: null,
    social_facebook_enabled: false,
    social_facebook_url: null,
    social_tiktok_enabled: false,
    social_tiktok_url: null,
    social_youtube_enabled: false,
    social_youtube_url: null,
    social_whatsapp_enabled: false,
    social_whatsapp_url: null,
    social_twitter_enabled: false,
    social_twitter_url: null,
    shipping_enabled: true,
    shipping_title: '',
    shipping_description: '',
    shipping_icon: 'Truck',
    quality_enabled: true,
    quality_title: 'Premium materials and trusted performance',
    quality_description: '',
    quality_icon: 'Shield',
    support_enabled: true,
    support_title: 'Always here to help',
    support_description: '',
    support_icon: 'Headphones',
    video_feed_enabled: false,
    video_feed_count: 6,
    video_feed_refresh_minutes: 30,
    video_feed_autoplay_enabled: false,
    hero_slider_enabled: true,
    hero_slider_autoplay: true,
    hero_slider_interval_ms: 5000,
    hero_slider_pause_on_hover: true,
    concept_final_slider_enabled: true,
    concept_image_url: null,
    final_image_url: null,
    homepage_section_order: ['hero','categories','highlights','featured','onsale','about','testimonials','reviews','promotions','newsletter'],
    hero_media_mode: 'video',
    hero_video_url: null,
    hero_slide_duration_ms: 5000,
    announcement_bar_enabled: true,
    announcement_bar_text: '',
    announcement_bar_bg_color: '#1a1a1a',
    hero_video_mobile_crop: null,
    returns_text: 'Easy Returns',
    highlights_section_title: null,
  };
}

export async function updateSiteSettings(settings: Partial<SiteSettings>): Promise<SiteSettings> {
  const { data: existingSettings, error: fetchError } = await supabase
    .from('site_settings')
    .select('*')
    .order('id', { ascending: false })
    .limit(1)
    .maybeSingle();

  const now = new Date().toISOString();

  if (fetchError && fetchError.code !== 'PGRST116') {
    console.error('Error fetching existing site settings:', fetchError);
    throw new Error(fetchError.message);
  }

  if (existingSettings) {
    const { data, error } = await supabase
      .from('site_settings')
      .update({
        ...settings,
        updated_at: now,
      })
      .eq('id', existingSettings.id)
      ;

    if (error) {
      console.error('Error updating site settings:', error);
      throw new Error(error.message);
    }

    return fetchSiteSettings();
  } else {
    // Create new record with defaults plus provided settings
    const defaultSettings = getDefaultSettings();

    const { data, error } = await supabase
      .from('site_settings')
      .insert({
        ...defaultSettings,
        ...settings,
        created_at: now,
        updated_at: now,
      })
      ;

    if (error) {
      console.error('Error creating site settings:', error);
      throw new Error(error.message);
    }

    return fetchSiteSettings();
  }
}

export async function updateSingleSetting(field: string, value: any): Promise<SiteSettings> {
  return updateSiteSettings({ [field]: value } as Partial<SiteSettings>);
}

export async function fetchNavItems() {
  const { data, error } = await supabase
    .from('nav_items')
    .select('*')
    .order('order');

  if (error) {
    console.error('Error fetching nav items:', error);
    throw new Error(error.message);
  }

  return data;
}
