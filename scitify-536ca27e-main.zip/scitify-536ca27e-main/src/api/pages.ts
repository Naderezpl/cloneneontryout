import { supabase } from "@/lib/supabase";

export interface CmsPage {
  id?: number;
  slug: string;
  title: string;
  content_html: string;
  meta_title?: string | null;
  meta_description?: string | null;
  enabled: boolean;
  hero_image_url?: string | null;
  updated_at?: string;
  created_at?: string;
}

export async function fetchPageBySlug(slug: string): Promise<CmsPage | null> {
  const { data, error } = await supabase
    .from('pages')
    .select('*')
    .eq('slug', slug)
    .maybeSingle();
  if (error) {
    if (error.code === 'PGRST116') return null;
    throw new Error(error.message);
  }
  return data as CmsPage | null;
}

export async function upsertPage(page: Partial<CmsPage>) {
  const now = new Date().toISOString();
  const payload: any = { ...page, updated_at: now };
  if (!payload.created_at) payload.created_at = now;
  const { data, error } = await supabase
    .from('pages')
    .upsert(payload, { onConflict: 'slug' })
    .select()
    .maybeSingle();
  if (error) {
    throw new Error(error.message);
  }
  return data as CmsPage;
}

export async function listPages(): Promise<CmsPage[]> {
  const { data, error } = await supabase
    .from('pages')
    .select('*')
    .order('slug', { ascending: true });
  if (error) {
    throw new Error(error.message);
  }
  return (data || []) as CmsPage[];
}
