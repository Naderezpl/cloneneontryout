import React, { createContext, useState, useContext, useEffect } from 'react';
import { useToast } from '@/components/ui/use-toast';
import { Product } from '@/types/product';
import { supabase } from '@/lib/supabase';
import { useAuth } from './AuthContext';
import { getUserFavorites, saveFavorite, removeFavorite } from '@/utils/userDataServices';

// Key for storing favorites in localStorage
const FAVORITES_STORAGE_KEY = 'neon_favorites';

interface FavoritesContextType {
  favorites: Product[];
  addToFavorites: (product: Product) => void;
  removeFromFavorites: (productId: string) => void;
  isInFavorites: (productId: string) => boolean;
  isFavorite: (productId: string) => boolean;
  toggleFavorite: (product: Product) => void;
}

const FavoritesContext = createContext<FavoritesContextType | undefined>(undefined);

export const useFavorites = () => {
  const context = useContext(FavoritesContext);
  if (!context) {
    throw new Error('useFavorites must be used within a FavoritesProvider');
  }
  return context;
};

export const FavoritesProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [favorites, setFavorites] = useState<Product[]>([]);
  const { toast } = useToast();
  const { user, isAuthenticated } = useAuth();

  // Load favorites from localStorage or database when component mounts
  useEffect(() => {
    const loadFavorites = async () => {
      try {
        if (isAuthenticated && user) {
          console.log('Fetching favorites for user:', user.id);
          // Load favorites from database for authenticated users
          const userFavorites = await getUserFavorites(user.id);
          console.log('Retrieved favorites from DB:', userFavorites);
          setFavorites(userFavorites);
        } else {
          // Load favorites from localStorage for non-authenticated users
          const storedFavorites = localStorage.getItem(FAVORITES_STORAGE_KEY);
          if (storedFavorites) {
            console.log('Retrieved favorites from localStorage');
            setFavorites(JSON.parse(storedFavorites));
          } else {
            setFavorites([]);
          }
        }
      } catch (error) {
        console.error('Error loading favorites:', error);
        setFavorites([]);
      }
    };

    loadFavorites();
  }, [isAuthenticated, user]);

  // Save favorites to localStorage whenever they change for non-authenticated users
  useEffect(() => {
    if (!isAuthenticated) {
      console.log('Saving favorites to localStorage:', favorites);
      if (favorites.length > 0) {
        localStorage.setItem(FAVORITES_STORAGE_KEY, JSON.stringify(favorites));
      } else {
        // Clear localStorage when favorites are empty
        localStorage.removeItem(FAVORITES_STORAGE_KEY);
      }
    }
  }, [favorites, isAuthenticated]);

  const addToFavorites = async (product: Product) => {
    // If already in favorites, don't add again
    if (isInFavorites(product.id)) return;

    try {
      if (isAuthenticated && user) {
        // Add to database for authenticated users
        const success = await saveFavorite(user.id, product.id);
        
        if (!success) {
          throw new Error('Failed to save favorite to database');
        }
      }

      // Update local state for all users
      setFavorites(prev => [...prev, product]);
      toast({
        title: "Added to favorites",
        description: `${product.name} has been added to your favorites.`
      });
      
    } catch (error) {
      console.error('Error adding to favorites:', error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to add item to favorites."
      });
    }
  };

  const removeFromFavorites = async (productId: string) => {
    try {
      if (isAuthenticated && user) {
        // Remove from database for authenticated users
        const success = await removeFavorite(user.id, productId);
        
        if (!success) {
          throw new Error('Failed to remove favorite from database');
        }
      }

      // Update local state for all users
      setFavorites(prev => prev.filter(item => item.id !== productId));
      toast({
        title: "Removed from favorites",
        description: "Item has been removed from your favorites."
      });
    } catch (error) {
      console.error('Error removing from favorites:', error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to remove item from favorites."
      });
    }
  };

  const isInFavorites = (productId: string) => {
    return favorites.some(item => item.id === productId);
  };

  // Add an alias for isInFavorites to match what's used in ProductCard
  const isFavorite = isInFavorites;

  // Add the toggleFavorite function
  const toggleFavorite = (product: Product) => {
    if (isInFavorites(product.id)) {
      removeFromFavorites(product.id);
    } else {
      addToFavorites(product);
    }
  };

  return (
    <FavoritesContext.Provider value={{ 
      favorites, 
      addToFavorites, 
      removeFromFavorites, 
      isInFavorites, 
      isFavorite,
      toggleFavorite 
    }}>
      {children}
    </FavoritesContext.Provider>
  );
};
