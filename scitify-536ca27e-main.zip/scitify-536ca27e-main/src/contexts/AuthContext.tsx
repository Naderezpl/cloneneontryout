import React, { createContext, useContext, useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { User, Session } from '@supabase/supabase-js';
import { CART_STORAGE_KEY } from '@/contexts/cart/cartTypes';

type AuthUser = User & {
  user_metadata: {
    name?: string;
  };
};

interface AuthContextType {
  user: AuthUser | null;
  session: Session | null;
  isAuthenticated: boolean;
  isAdmin: boolean;
  hasDbAdminRole: boolean;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<void>;
  signup: (name: string, email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

const ADMIN_EMAILS = ['admin@gmail.com'];

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  const [hasDbAdminRole, setHasDbAdminRole] = useState(false);

  useEffect(() => {
    let mounted = true;

    supabase.auth.getSession().then(async ({ data: { session } }) => {
      if (!mounted) return;
      setSession(session);
      setUser(session?.user as AuthUser || null);
      
      if (session?.user?.email) {
        const isUserAdmin = ADMIN_EMAILS.includes(session.user.email);
        setIsAdmin(isUserAdmin);
      }
      
      if (session?.user) {
        await checkAdminStatus(session.user.id, session.user.email);
      }
      
      if (mounted) setIsLoading(false);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      if (!mounted) return;
      setSession(session);
      setUser(session?.user as AuthUser || null);
      
      if (session?.user?.email) {
        const isUserAdmin = ADMIN_EMAILS.includes(session.user.email);
        setIsAdmin(isUserAdmin);
      }
      
      if (session?.user) {
        // Don't reset hasDbAdminRole — let checkAdminStatus update it
        checkAdminStatus(session.user.id, session.user.email);
      } else {
        setIsAdmin(false);
        setHasDbAdminRole(false);
        setIsLoading(false);
      }
    });

    return () => {
      mounted = false;
      subscription.unsubscribe();
    };
  }, []);

  const checkAdminStatus = async (userId: string, email?: string | null) => {
    try {
      const { data, error } = await supabase
        .from('user_roles')
        .select('role')
        .eq('user_id', userId)
        .eq('role', 'admin')
        .single();
      const emailAdmin = email ? ADMIN_EMAILS.includes(email) : false;
      if (error) {
        console.log('Admin check DB error, using email fallback:', error?.code, emailAdmin);
        setIsAdmin(emailAdmin);
        setHasDbAdminRole(false);
        return;
      }
      const isUserAdmin = data ? true : emailAdmin;
      setHasDbAdminRole(!!data);
      console.log('Admin check combined (db/email):', isUserAdmin);
      setIsAdmin(isUserAdmin);
    } catch (error) {
      console.error('Error checking admin status:', error);
      const emailAdmin = email ? ADMIN_EMAILS.includes(email) : false;
      setIsAdmin(emailAdmin);
      setHasDbAdminRole(false);
    }
  };

  const login = async (email: string, password: string): Promise<void> => {
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });
      
      if (error) throw error;
      
      if (data.user) {
        await checkAdminStatus(data.user.id, data.user.email);
      }
    } catch (error) {
      console.error('Error during login:', error);
      throw error;
    }
  };

  const signup = async (name: string, email: string, password: string): Promise<void> => {
    try {
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            name,
          },
          emailRedirectTo: window.location.origin,
        },
      });
      
      if (error) throw error;
      
      // Check if user already exists (Supabase returns user with identities = [] for existing users)
      if (data.user && data.user.identities && data.user.identities.length === 0) {
        throw new Error('An account with this email already exists. Please sign in instead.');
      }
      
      // Profile is created automatically via database trigger (handle_new_user)
      // No need to manually insert into user_profiles
    } catch (error) {
      console.error('Error during signup:', error);
      throw error;
    }
  };

  const logout = async (): Promise<void> => {
    try {
      console.log('Logging out: Clearing cart from localStorage');
      localStorage.removeItem(CART_STORAGE_KEY);
      
      const { error } = await supabase.auth.signOut();
      if (error) throw error;
      setUser(null);
      setSession(null);
      setIsAdmin(false);
      setHasDbAdminRole(false);
    } catch (error) {
      console.error('Error during logout:', error);
      setUser(null);
      setSession(null);
      setIsAdmin(false);
      setHasDbAdminRole(false);
      throw error;
    }
  };

  const value = {
    user,
    session,
    isAuthenticated: !!user,
    isAdmin,
    hasDbAdminRole,
    isLoading,
    login,
    signup,
    logout,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};
