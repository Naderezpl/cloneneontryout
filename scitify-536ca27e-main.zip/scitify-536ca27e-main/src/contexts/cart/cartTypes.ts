
import { Product, ProductVariant } from '@/types/product';

export const CART_STORAGE_KEY = 'neonSignShop_cart';

export interface CartItem {
  id: string;
  product: Product;
  variant: ProductVariant;
  quantity: number;
}

export enum CartActionType {
  INITIALIZE = 'INITIALIZE',
  ADD_ITEM = 'ADD_ITEM',
  REMOVE_ITEM = 'REMOVE_ITEM',
  UPDATE_QUANTITY = 'UPDATE_QUANTITY',
  CLEAR_CART = 'CLEAR_CART',
}

export type CartAction =
  | { type: CartActionType.INITIALIZE; payload: CartItem[] }
  | { type: CartActionType.ADD_ITEM; payload: CartItem }
  | { type: CartActionType.REMOVE_ITEM; payload: string }
  | { type: CartActionType.UPDATE_QUANTITY; payload: { productId: string; quantity: number } }
  | { type: CartActionType.CLEAR_CART };

export interface CartContextType {
  cart: CartItem[];
  cartItems: CartItem[]; // Alias for backward compatibility
  addToCart: (product: Product, quantity?: number, variant?: ProductVariant) => Promise<void>;
  removeFromCart: (productId: string) => Promise<void>;
  updateQuantity: (productId: string, quantity: number) => Promise<void>;
  clearCart: () => Promise<void>;
  getItemCount: () => number;
  getCartCount: () => number; // Alias for backward compatibility
  getTotalPrice: () => number;
  getCartTotal: () => number; // Alias for backward compatibility
}
