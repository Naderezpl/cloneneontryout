
import { CartItem, CartAction, CartActionType } from './cartTypes';

export const cartReducer = (state: CartItem[], action: CartAction): CartItem[] => {
  switch (action.type) {
    case CartActionType.INITIALIZE:
      return action.payload;
    
    case CartActionType.ADD_ITEM: {
      const newItem = action.payload;
      const existingItem = state.find(item => item.id === newItem.id);
      
      if (existingItem) {
        return state.map(item =>
          item.id === newItem.id ? { ...item, quantity: item.quantity + newItem.quantity } : item
        );
      } else {
        return [...state, newItem];
      }
    }
    
    case CartActionType.REMOVE_ITEM:
      return state.filter(item => item.id !== action.payload);
    
    case CartActionType.UPDATE_QUANTITY:
      return state.map(item =>
        item.id === action.payload.productId ? { ...item, quantity: action.payload.quantity } : item
      );
    
    case CartActionType.CLEAR_CART:
      return [];
    
    default:
      return state;
  }
};
