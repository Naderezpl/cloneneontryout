
import { useContext } from 'react';
import { CartContext } from './CartContext';

// Custom hook for accessing cart context
export const useCart = () => useContext(CartContext);
