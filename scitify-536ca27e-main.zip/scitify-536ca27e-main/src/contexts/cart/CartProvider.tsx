
import React, { useReducer, useEffect, useState, useRef, ReactNode } from 'react';
import { Product } from '@/types/product';
import { useAuth } from '@/contexts/AuthContext';
import { 
  getUserCart, 
  saveCartItem, 
  updateCartItemQuantity, 
  removeCartItem, 
  clearUserCart,
  mergeLocalAndDbCart
} from '@/utils/userDataServices';
import { CartContext } from './CartContext';
import { CartItem, CART_STORAGE_KEY, CartActionType } from './cartTypes';
import { cartReducer } from './cartReducer';
import { getItemCount, getTotalPrice } from './cartUtils';
import { useToast } from '@/hooks/use-toast';

// Debounce utility function
const debounce = <T extends (...args: any[]) => any>(
  func: T,
  wait: number
): ((...args: Parameters<T>) => Promise<ReturnType<T>>) => {
  let timeout: ReturnType<typeof setTimeout> | null = null;
  
  return (...args: Parameters<T>): Promise<ReturnType<T>> => {
    return new Promise((resolve, reject) => {
      if (timeout) clearTimeout(timeout);
      
      timeout = setTimeout(() => {
        try {
          const result = func(...args);
          resolve(result);
        } catch (error) {
          reject(error);
        }
      }, wait);
    });
  };
};

interface CartProviderProps {
  children: ReactNode;
}

export const CartProvider = ({ children }: CartProviderProps) => {
  const [cart, dispatch] = useReducer(cartReducer, []);
  const [initialized, setInitialized] = useState(false);
  const { isAuthenticated, user, isLoading } = useAuth();
  const hasMerged = useRef(false);
  const { toast } = useToast();

  // Clear cart on logout
  useEffect(() => {
    if (!isLoading && !isAuthenticated && initialized) {
      console.log('User logged out, clearing cart display and local storage');
      dispatch({ type: CartActionType.CLEAR_CART });
      localStorage.removeItem(CART_STORAGE_KEY);
      hasMerged.current = false;
    }
  }, [isAuthenticated, isLoading, initialized]);

  // Initialize cart
  useEffect(() => {
    const initializeCart = async () => {
      if (isLoading) return;

      console.log('Initializing cart, auth state:', { 
        isAuthenticated, 
        userId: user?.id, 
        isLoading, 
        hasMerged: hasMerged.current 
      });

      try {
        if (isAuthenticated && user) {
          // For authenticated users, handle local cart merging
          if (!hasMerged.current) {
            console.log('Checking for local cart to merge');
            const storedCart = localStorage.getItem(CART_STORAGE_KEY);
            
            if (storedCart) {
              const localCart = JSON.parse(storedCart);
              
              if (localCart && localCart.length > 0) {
                console.log('Found local cart to merge:', localCart);
                
                // Merge local cart into DB
                await mergeLocalAndDbCart(user.id, localCart);
                console.log('Local cart merged with DB cart');
                
                // Clear local storage after successful merge
                localStorage.removeItem(CART_STORAGE_KEY);
              }
            }
            
            // Mark as merged to prevent future merges until logout
            hasMerged.current = true;
          }

          // After potential merge, load the latest cart from DB
          console.log('Loading cart from database for user:', user.id);
          const dbCartItems = await getUserCart(user.id);
          console.log('Loaded DB cart items:', dbCartItems);
          dispatch({ type: CartActionType.INITIALIZE, payload: dbCartItems || [] });
        } else {
          // For anonymous users, use localStorage
          console.log('Loading cart from localStorage');
          const storedCart = localStorage.getItem(CART_STORAGE_KEY);
          if (storedCart) {
            const localCartItems = JSON.parse(storedCart);
            console.log('Loaded local cart items:', localCartItems);
            dispatch({ type: CartActionType.INITIALIZE, payload: localCartItems });
          } else {
            // If no stored cart, ensure the cart is empty
            dispatch({ type: CartActionType.CLEAR_CART });
          }
        }
      } catch (error) {
        console.error('Error initializing cart:', error);
        toast({
          title: "Error",
          description: "Failed to load your cart. Please try again.",
          variant: "destructive"
        });
      }
      
      setInitialized(true);
    };

    initializeCart();
  }, [isAuthenticated, user, isLoading, toast]);

  // Update localStorage whenever cart changes (for non-authenticated users)
  useEffect(() => {
    if (!initialized || isAuthenticated || isLoading) return;
    
    console.log('Saving cart to localStorage:', cart);
    localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(cart));
  }, [cart, isAuthenticated, isLoading, initialized]);

  // Cart operations with optimistic updates
  const addToCart = async (product: Product, quantity: number = 1, explicitVariant?: import('@/types/product').ProductVariant) => {
    // Use explicitly passed variant, or fall back to first variant
    const variant = explicitVariant 
      || (product.variants && product.variants.length > 0 
        ? product.variants[0] 
        : { 
            id: 'default', 
            product_id: product.id, 
            variant_name: 'Default', 
            price: product.price || 0, 
            stock_quantity: 0 
          });
    
    // Use variant ID as the cart item ID for unique variant identification
    const cartItemId = variant.id || product.id;
    
    // Create cart item
    const newItem: CartItem = { 
      id: cartItemId, 
      product, 
      variant, 
      quantity 
    };

    try {
      // Optimistic update
      if (!isAuthenticated) {
        dispatch({ type: CartActionType.ADD_ITEM, payload: newItem });
      }

      if (isAuthenticated && user) {
        // If user is authenticated, save to database
        await saveCartItem(user.id, newItem);
        // Reload cart from database to ensure we have the latest data
        const updatedCart = await getUserCart(user.id);
        dispatch({ type: CartActionType.INITIALIZE, payload: updatedCart });
      }

      toast({
        title: "Item added",
        description: `${product.name} has been added to your cart.`
      });
    } catch (error) {
      console.error('Error adding item to cart:', error);
      
      // Rollback local update if authenticated but DB update failed
      if (isAuthenticated && !isLoading) {
        const updatedCart = await getUserCart(user!.id);
        dispatch({ type: CartActionType.INITIALIZE, payload: updatedCart });
      }
      
      toast({
        title: "Error",
        description: "Failed to add item to cart. Please try again.",
        variant: "destructive"
      });
    }
  };

  const removeFromCart = async (productId: string) => {
    try {
      // Optimistic update for UI
      dispatch({ type: CartActionType.REMOVE_ITEM, payload: productId });

      if (isAuthenticated && user) {
        // If user is authenticated, remove from database
        await removeCartItem(user.id, productId);
      }
    } catch (error) {
      console.error('Error removing item from cart:', error);
      
      // Reload original cart on error
      if (isAuthenticated && user) {
        const updatedCart = await getUserCart(user.id);
        dispatch({ type: CartActionType.INITIALIZE, payload: updatedCart });
      } else if (!isAuthenticated) {
        // For local storage, reload from there
        const storedCart = localStorage.getItem(CART_STORAGE_KEY);
        if (storedCart) {
          dispatch({ type: CartActionType.INITIALIZE, payload: JSON.parse(storedCart) });
        }
      }
      
      toast({
        title: "Error",
        description: "Failed to remove item from cart. Please try again.",
        variant: "destructive"
      });
    }
  };

  // Debounced version of updateCartItemQuantity for API calls
  const debouncedUpdateCartItem = useRef(
    debounce(async (userId: string, productId: string, quantity: number) => {
      return await updateCartItemQuantity(userId, productId, quantity);
    }, 300)
  ).current;

  const updateQuantity = async (productId: string, quantity: number) => {
    try {
      // Optimistic update for UI
      dispatch({ 
        type: CartActionType.UPDATE_QUANTITY, 
        payload: { productId, quantity } 
      });

      if (isAuthenticated && user) {
        // Use debounced update for authenticated users to prevent API spam
        await debouncedUpdateCartItem(user.id, productId, quantity);
      }
    } catch (error) {
      console.error('Error updating item quantity:', error);
      
      // Reload original cart on error
      if (isAuthenticated && user) {
        const updatedCart = await getUserCart(user.id);
        dispatch({ type: CartActionType.INITIALIZE, payload: updatedCart });
      } else if (!isAuthenticated) {
        // For local storage, reload from there
        const storedCart = localStorage.getItem(CART_STORAGE_KEY);
        if (storedCart) {
          dispatch({ type: CartActionType.INITIALIZE, payload: JSON.parse(storedCart) });
        }
      }

      toast({
        title: "Error",
        description: "Failed to update quantity. Please try again.",
        variant: "destructive"
      });
    }
  };

  const clearCart = async () => {
    try {
      // Optimistic update for UI
      dispatch({ type: CartActionType.CLEAR_CART });

      if (isAuthenticated && user) {
        // If user is authenticated, clear from database
        await clearUserCart(user.id);
      } else {
        // For non-authenticated users, clear local storage
        localStorage.removeItem(CART_STORAGE_KEY);
      }

      toast({
        title: "Cart cleared",
        description: "All items have been removed from your cart."
      });
    } catch (error) {
      console.error('Error clearing cart:', error);
      
      // Reload original cart on error
      if (isAuthenticated && user) {
        const updatedCart = await getUserCart(user.id);
        dispatch({ type: CartActionType.INITIALIZE, payload: updatedCart });
      }

      toast({
        title: "Error",
        description: "Failed to clear cart. Please try again.",
        variant: "destructive"
      });
    }
  };

  return (
    <CartContext.Provider
      value={{
        cart,
        cartItems: cart, // Add alias for compatibility
        addToCart,
        removeFromCart,
        updateQuantity,
        clearCart,
        getItemCount: () => getItemCount(cart),
        getCartCount: () => getItemCount(cart),
        getTotalPrice: () => getTotalPrice(cart),
        getCartTotal: () => getTotalPrice(cart),
      }}
    >
      {children}
    </CartContext.Provider>
  );
};
