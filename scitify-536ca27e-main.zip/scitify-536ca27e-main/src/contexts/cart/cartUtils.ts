
import { CartItem } from './cartTypes';

// Functions to calculate cart metrics
export const getItemCount = (cart: CartItem[]): number => {
  return cart.reduce((count, item) => count + item.quantity, 0);
};

export const getTotalPrice = (cart: CartItem[]): number => {
  return cart.reduce((total, item) => total + (item.variant.price * item.quantity), 0);
};
