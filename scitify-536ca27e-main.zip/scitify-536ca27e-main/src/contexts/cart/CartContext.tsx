
import { createContext } from 'react';
import { CartContextType } from './cartTypes';

// Default context values
const defaultCartContext: CartContextType = {
  cart: [],
  cartItems: [],
  addToCart: async () => Promise.resolve(),
  removeFromCart: async () => Promise.resolve(),
  updateQuantity: async () => Promise.resolve(),
  clearCart: async () => Promise.resolve(),
  getItemCount: () => 0,
  getCartCount: () => 0,
  getTotalPrice: () => 0,
  getCartTotal: () => 0,
};

// Create the context with default values
export const CartContext = createContext<CartContextType>(defaultCartContext);
