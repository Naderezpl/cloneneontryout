
import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { fetchFeaturedProducts } from '@/api/products';
import { fetchSiteSettings } from '@/api/settings';
import ProductGrid from './ProductGrid';

const FeaturedProducts = () => {
  const { data: products = [], isLoading: isLoadingProducts, error: productsError } = useQuery({
    queryKey: ['featured-products'],
    queryFn: fetchFeaturedProducts,
    staleTime: 0, // Ensure we refetch when component mounts
    refetchOnMount: true
  });

  const { data: settings } = useQuery({
    queryKey: ['site-settings'],
    queryFn: fetchSiteSettings,
    staleTime: 0, // Ensure we refetch when component mounts
    refetchOnMount: true
  });

  if (isLoadingProducts) {
    return (
      <section className="py-16 bg-background">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Featured Neon Signs</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Loading our featured products...
            </p>
          </div>
        </div>
      </section>
    );
  }

  if (productsError || products.length === 0) {
    return null;
  }

  return (
    <ProductGrid
      products={products}
      title={settings?.featured_products_title?.trim() || ''}
      description={settings?.featured_products_description?.trim() || ''}
      viewAllLink="/shop"
      viewAllText="View All Products"
      columns={3}
      rows={1}
      featured={true}
      variant="featured"
    />
  );
};

export default FeaturedProducts;
