
import React, { useEffect, useState } from 'react';
import { Outlet } from 'react-router-dom';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import WhatsAppWidget from '@/components/WhatsAppWidget';
import { fetchSiteSettings } from '@/api/settings';
import { SiteSettings } from '@/types/settings';

class AppErrorBoundary extends React.Component<{ children: React.ReactNode }, { hasError: boolean }> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { hasError: false };
  }
  static getDerivedStateFromError() {
    return { hasError: true };
  }
  componentDidCatch() {}
  render() {
    if (this.state.hasError) {
      return (
        <div className="container mx-auto px-4 py-16 text-center">
          <div className="text-2xl font-bold mb-2">Something went wrong</div>
          <div className="text-muted-foreground">Please refresh or go back to continue.</div>
        </div>
      );
    }
    return this.props.children;
  }
}

const Layout = () => {
  const [settings, setSettings] = useState<SiteSettings | null>(null);

  useEffect(() => {
    // Immediate IIFE to allow async/await in useEffect
    (async () => {
      try {
        console.log('Fetching site settings for layout and favicon...');
        const siteSettings = await fetchSiteSettings();
        console.log('Retrieved site settings:', siteSettings);
        setSettings(siteSettings);
        
        try {
          const title = siteSettings.site_title || siteSettings.meta_title || siteSettings.company_name;
          if (title) document.title = title;
          const desc = siteSettings.meta_description || siteSettings.site_description || '';
          if (desc) {
            let meta = document.querySelector('meta[name="description"]') as HTMLMetaElement | null;
            if (!meta) {
              meta = document.createElement('meta');
              meta.setAttribute('name', 'description');
              document.head.appendChild(meta);
            }
            meta.setAttribute('content', desc);
          }
        } catch {}
        
        // Update favicon dynamically with more detailed logging
        if (siteSettings.favicon_url || siteSettings.logo_url) {
          console.log('Updating favicon with URL:', siteSettings.favicon_url || siteSettings.logo_url);
          
          // Find the favicon link element by ID first (preferred method)
          let faviconLink = document.getElementById('dynamic-favicon') as HTMLLinkElement;
          
          if (faviconLink) {
            console.log('Found existing favicon link by ID, updating href');
            faviconLink.href = siteSettings.favicon_url || siteSettings.logo_url;
          } else {
            // Fall back to querySelector if the ID-based approach fails
            faviconLink = document.querySelector('link[rel="icon"]') as HTMLLinkElement;
            
            if (faviconLink) {
              console.log('Found existing favicon link by selector, updating href');
              faviconLink.href = siteSettings.favicon_url || siteSettings.logo_url;
            } else {
              // Create new favicon link if none exists
              console.log('No existing favicon found, creating new favicon link');
              faviconLink = document.createElement('link');
              faviconLink.rel = 'icon';
              faviconLink.id = 'dynamic-favicon'; // Add ID for easier future updates
              faviconLink.href = siteSettings.favicon_url || siteSettings.logo_url;
              faviconLink.type = 'image/png';
              document.head.appendChild(faviconLink);
            }
          }
          
          // Force browser to reload favicon by creating a temporary link and removing it
          // This helps with browser caching issues
          const tempLink = document.createElement('link');
          tempLink.rel = 'shortcut icon';
          tempLink.href = 'data:image/x-icon;,';
          document.head.appendChild(tempLink);
          setTimeout(() => {
            document.head.removeChild(tempLink);
            console.log('Favicon cache refresh attempt completed');
          }, 100);
        } else {
          console.warn('No logo URL found in site settings for favicon');
        }
      } catch (error) {
        console.error('Error fetching site settings for layout and favicon:', error);
      }
    })();
  }, []);

  return (
    <div className="flex flex-col min-h-screen w-full">
      {/* Announcement Bar */}
      {settings?.announcement_bar_enabled && settings?.announcement_bar_text && (
        <div
          className="w-full text-center text-xs font-medium tracking-wide py-2 z-[60] relative"
          style={{ backgroundColor: settings.announcement_bar_bg_color || 'hsl(var(--foreground))', color: '#ffffff' }}
        >
          {settings.announcement_bar_text}
        </div>
      )}
      <Navbar />
      <main className="flex-grow w-full">
        <AppErrorBoundary>
          <Outlet />
        </AppErrorBoundary>
      </main>
      <Footer />
      <WhatsAppWidget />
    </div>
  );
};

export default Layout;
