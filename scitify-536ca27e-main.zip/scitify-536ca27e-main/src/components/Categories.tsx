
import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/lib/supabase';
import CategoryCard from '@/components/CategoryCard';

const Categories = () => {
  const { data: categories = [], isLoading } = useQuery({
    queryKey: ['homepage-categories'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('categories')
        .select('*')
        .eq('is_visible', true)
        .order('position', { ascending: true });
        
      if (error) throw error;
      return data;
    }
  });

  if (isLoading) {
    return (
      <section className="py-16 md:py-24 bg-background">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4">
            {[1,2,3,4].map(i => (
              <div key={i} className="aspect-[4/5] bg-muted rounded-lg animate-pulse" />
            ))}
          </div>
        </div>
      </section>
    );
  }

  if (categories.length === 0) return null;

  return (
    <section className="py-2 md:py-4 bg-background">
      <div className="container mx-auto px-2 md:px-4">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2 md:gap-3">
          {categories.map((category) => (
            <CategoryCard
              key={category.id}
              slug={category.id}
              label={category.name}
              imageUrl={category.image_url ?? undefined}
              backgroundColor={category.background_color ?? undefined}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Categories;
