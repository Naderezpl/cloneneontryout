import React from 'react';
import { Link } from 'react-router-dom';
import { AspectRatio } from '@/components/ui/aspect-ratio';
import { cn } from '@/lib/utils';

interface CategoryCardProps {
  slug: string;
  label: string;
  imageUrl?: string;
  backgroundColor?: string;
  className?: string;
}

const CategoryCard: React.FC<CategoryCardProps> = ({
  slug,
  label,
  imageUrl,
  backgroundColor,
  className,
}) => {
  return (
    <Link
      to={`/shop?categories=${slug}`}
      className={cn(
        'group relative block overflow-hidden rounded-lg transition-shadow duration-300 hover:shadow-md active:scale-[0.98]',
        className
      )}
      style={{ backgroundColor: backgroundColor || undefined }}
    >
      <AspectRatio ratio={4 / 5}>
        {imageUrl ? (
          <img
            src={imageUrl}
            alt={label}
            className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
          />
        ) : (
          <div className="h-full w-full bg-muted" />
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-foreground/40 to-transparent" />
        <div className="absolute bottom-0 left-0 right-0 p-4 md:p-6">
          <h3 className="text-sm md:text-base font-semibold text-background tracking-wide uppercase">
            {label}
          </h3>
        </div>
      </AspectRatio>
    </Link>
  );
};

export default CategoryCard;
