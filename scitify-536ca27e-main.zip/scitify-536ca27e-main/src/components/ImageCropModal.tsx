
import React, { useState, useCallback, useRef, useEffect } from 'react';
import ReactCrop, { type Crop, type PixelCrop, centerCrop } from 'react-image-crop';
import 'react-image-crop/dist/ReactCrop.css';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';

interface ImageCropModalProps {
  open: boolean;
  imageSrc: string;
  onClose: () => void;
  onCropComplete: (croppedBlob: Blob) => void;
  /** @deprecated aspect ratio is ignored – crop is always free-form */
  aspectRatio?: number;
  maxWidth?: number;
  maxHeight?: number;
}

function getCroppedCanvas(
  image: HTMLImageElement,
  crop: PixelCrop,
  maxWidth = 4096,
  maxHeight = 4096,
): HTMLCanvasElement {
  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('No 2d context');

  const scaleX = image.naturalWidth / image.width;
  const scaleY = image.naturalHeight / image.height;

  let outputWidth = crop.width * scaleX;
  let outputHeight = crop.height * scaleY;

  if (outputWidth > maxWidth || outputHeight > maxHeight) {
    const scale = Math.min(maxWidth / outputWidth, maxHeight / outputHeight);
    outputWidth = Math.round(outputWidth * scale);
    outputHeight = Math.round(outputHeight * scale);
  }

  canvas.width = outputWidth;
  canvas.height = outputHeight;

  ctx.drawImage(
    image,
    crop.x * scaleX,
    crop.y * scaleY,
    crop.width * scaleX,
    crop.height * scaleY,
    0,
    0,
    outputWidth,
    outputHeight,
  );

  return canvas;
}

// centerAspectCrop removed – crop is always free-form

const ImageCropModal: React.FC<ImageCropModalProps> = ({
  open,
  imageSrc,
  onClose,
  onCropComplete,
  maxWidth = 4096,
  maxHeight = 4096,
}) => {
  const [crop, setCrop] = useState<Crop>();
  const [completedCrop, setCompletedCrop] = useState<PixelCrop>();
  const [isSaving, setIsSaving] = useState(false);
  const imgRef = useRef<HTMLImageElement>(null);

  // Reset crop when image changes
  useEffect(() => {
    setCrop(undefined);
    setCompletedCrop(undefined);
  }, [imageSrc]);

  const onImageLoad = useCallback(
    (e: React.SyntheticEvent<HTMLImageElement>) => {
      const { width, height } = e.currentTarget;
      // Always free-form: select 90% of the image
      setCrop(centerCrop({ unit: '%', width: 90, height: 90 }, width, height));
    },
    [],
  );

  const handleSave = async () => {
    if (!completedCrop || !imgRef.current) return;
    setIsSaving(true);
    try {
      const canvas = getCroppedCanvas(imgRef.current, completedCrop, maxWidth, maxHeight);
      canvas.toBlob(
        (blob) => {
          if (!blob) {
            console.error('Canvas is empty');
            setIsSaving(false);
            return;
          }
          onCropComplete(blob);
          setIsSaving(false);
        },
        'image/webp',
        0.88,
      );
    } catch (e) {
      console.error('Crop failed', e);
      setIsSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] flex flex-col">
        <DialogHeader>
          <DialogTitle>Crop Image</DialogTitle>
        </DialogHeader>

        <div className="flex items-center justify-center w-full max-h-[400px] overflow-auto bg-muted rounded-md">
          <ReactCrop
            crop={crop}
            onChange={(c) => setCrop(c)}
            onComplete={(c) => setCompletedCrop(c)}
            className="max-h-[400px]"
          >
            <img
              ref={imgRef}
              src={imageSrc}
              alt="Crop source"
              onLoad={onImageLoad}
              className="max-h-[400px] w-auto"
              style={{ display: 'block' }}
            />
          </ReactCrop>
        </div>

        <DialogFooter className="pt-2">
          <Button variant="outline" onClick={onClose} disabled={isSaving}>
            Cancel
          </Button>
          <Button onClick={handleSave} disabled={isSaving || !completedCrop}>
            {isSaving ? 'Processing…' : 'Apply Crop'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default ImageCropModal;
