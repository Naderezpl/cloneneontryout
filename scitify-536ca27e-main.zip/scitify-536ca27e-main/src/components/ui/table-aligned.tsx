
import React from 'react';
import { 
  Table as ShadcnTable, 
  TableBody as ShadcnTableBody, 
  TableCaption as ShadcnTableCaption, 
  TableCell as ShadcnTableCell, 
  TableFooter as ShadcnTableFooter, 
  TableHead as ShadcnTableHead, 
  TableHeader as ShadcnTableHeader, 
  TableRow as ShadcnTableRow 
} from '@/components/ui/table';
import { cn } from '@/lib/utils';

// These components add vertical alignment options to the default shadcn UI tables

export const TableHead = React.forwardRef<
  React.ElementRef<typeof ShadcnTableHead>,
  React.ComponentPropsWithoutRef<typeof ShadcnTableHead> & {
    verticalAlign?: 'top' | 'middle' | 'bottom'
  }
>(({ className, verticalAlign = 'middle', ...props }, ref) => {
  const alignClass = {
    'top': 'align-top',
    'middle': 'align-middle',
    'bottom': 'align-bottom',
  }[verticalAlign];
  
  return (
    <ShadcnTableHead
      ref={ref}
      className={cn(alignClass, className)}
      {...props}
    />
  );
});
TableHead.displayName = 'TableHead';

export const TableHeader = React.forwardRef<
  React.ElementRef<typeof ShadcnTableHeader>,
  React.ComponentPropsWithoutRef<typeof ShadcnTableHeader> & {
    verticalAlign?: 'top' | 'middle' | 'bottom'
  }
>(({ className, verticalAlign = 'middle', ...props }, ref) => {
  const alignClass = {
    'top': 'align-top',
    'middle': 'align-middle',
    'bottom': 'align-bottom',
  }[verticalAlign];
  
  return (
    <ShadcnTableHeader
      ref={ref}
      className={cn(alignClass, className)}
      {...props}
    />
  );
});
TableHeader.displayName = 'TableHeader';

export const TableCell = React.forwardRef<
  React.ElementRef<typeof ShadcnTableCell>,
  React.ComponentPropsWithoutRef<typeof ShadcnTableCell> & {
    verticalAlign?: 'top' | 'middle' | 'bottom'
  }
>(({ className, verticalAlign = 'middle', ...props }, ref) => {
  const alignClass = {
    'top': 'align-top',
    'middle': 'align-middle',
    'bottom': 'align-bottom',
  }[verticalAlign];
  
  return (
    <ShadcnTableCell
      ref={ref}
      className={cn(alignClass, className)}
      {...props}
    />
  );
});
TableCell.displayName = 'TableCell';

// Re-export other table components for convenience
export const Table = ShadcnTable;
export const TableBody = ShadcnTableBody;
export const TableCaption = ShadcnTableCaption;
export const TableFooter = ShadcnTableFooter;
export const TableRow = ShadcnTableRow;
