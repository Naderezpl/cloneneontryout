
import React, { useState, useEffect, useRef } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { 
  ShoppingCart, Menu, X, Heart, User, Search, LogOut, Shield
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { useCart } from '@/contexts/cart';
import { useFavorites } from '@/contexts/FavoritesContext';
import { useAuth } from '@/contexts/AuthContext';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/lib/supabase';
import { fetchSiteSettings } from '@/api/settings';
import { SiteSettings } from '@/types/settings';
import { useQuery as useQuery2 } from '@tanstack/react-query';
import { listPages, CmsPage } from '@/api/pages';

type NavItem = {
  id: string;
  title: string;
  url: string;
  order: number;
  is_enabled?: boolean;
  created_at?: string;
  _pageEnabled?: boolean;
};

const Navbar = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [navVisible, setNavVisible] = useState(true);
  const lastScrollY = useRef(0);
  
  const { cart, getItemCount } = useCart();
  const { favorites } = useFavorites();
  const { isAuthenticated, user, logout, isAdmin, hasDbAdminRole } = useAuth();
  
  const location = useLocation();
  const [navItemsLoaded, setNavItemsLoaded] = useState(false);
  
  const cartCount = getItemCount();
  const favoritesCount = favorites.length;

  useEffect(() => {
    const handleScroll = () => {
      const currentScrollY = window.scrollY;
      if (currentScrollY > lastScrollY.current && currentScrollY > 80) {
        setNavVisible(false);
      } else {
        setNavVisible(true);
      }
      lastScrollY.current = currentScrollY;
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const { data: navItems = [], isLoading } = useQuery({
    queryKey: ['navigation-items'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('nav_items')
        .select('*')
        .eq('is_enabled', true)
        .order('order');
      
      if (error) {
        console.error('Error fetching navigation items:', error);
        return [];
      }
      setNavItemsLoaded(true);
      return (data || []).map(item => ({
        ...item,
        position: item.order
      })) as NavItem[];
    }
  });
  
  const { data: siteSettings, isLoading: isLoadingSiteSettings } = useQuery<SiteSettings>({
    queryKey: ['site-settings'],
    queryFn: fetchSiteSettings,
  });

  const hasAnnouncementBar = siteSettings?.announcement_bar_enabled && !!siteSettings?.announcement_bar_text;
  const navTopOffset = hasAnnouncementBar ? '36px' : '8px';

  const { data: pages = [] } = useQuery2({
    queryKey: ['pages'],
    queryFn: listPages,
  });

  useEffect(() => {
    console.log('Navbar: isAdmin =', isAdmin, 'user email =', user?.email);
  }, [isAdmin, user]);
  
  const toggleMenu = () => setIsMenuOpen(!isMenuOpen);
  
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    window.location.href = `/shop?search=${encodeURIComponent(searchQuery)}`;
    setIsSearchOpen(false);
  };
  
  const defaultNavItems: NavItem[] = [
    { id: '1', title: 'Home', url: '/', order: 0 },
    { id: '2', title: 'Shop', url: '/shop', order: 1 },
    { id: '5', title: 'About Us', url: '/about', order: 4 }
  ];
  
  const pageBySlug = (slug: string): CmsPage | undefined => pages.find(p => p.slug === slug);
  const urlToSlug = (url: string) => {
    const clean = (url || '').replace(/^\//, '').trim();
    if (clean === '' || clean === undefined) return 'home';
    return clean;
  };
  const rawNav = (navItemsLoaded && navItems.length > 0 ? navItems : defaultNavItems)
    .filter(item =>
      !['/custom','/inspiration','/contact'].includes(item.url) &&
      !['Custom Neon','Inspiration','Contact Us','Contact'].includes(item.title)
    );
  const displayNavItems = rawNav
    .map(item => {
      const slug = urlToSlug(item.url);
      const page = pageBySlug(slug);
      return page ? { ...item, title: page.title, _pageEnabled: page.enabled } : { ...item, _pageEnabled: true };
    })
    .filter(item => item._pageEnabled !== false);
  
  const uniqueDisplayNavItems = displayNavItems.reduce((acc, item) => {
    const already = acc.some(i => i.url === item.url);
    if (already) return acc;
    return [...acc, item];
  }, [] as NavItem[]);
  
  return (
    <nav
      className={`fixed left-6 right-6 z-50 transition-transform duration-300 ease-in-out rounded-2xl bg-white shadow-lg ${
        navVisible ? 'translate-y-0' : '-translate-y-[calc(100%+2rem)]'
      }`}
      style={{ top: navTopOffset }}
    >
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-14">
          {/* Left: Logo */}
          <Link to="/" className="flex items-center shrink-0 min-h-[3rem]">
            {siteSettings?.logo_url ? (
              <img 
                src={siteSettings.logo_url} 
                alt={siteSettings?.company_name || ''} 
                className="h-12 w-auto object-contain max-h-[calc(3.5rem-8px)]"
              />
            ) : isLoadingSiteSettings ? (
              <span className="h-8 w-24" />
            ) : siteSettings?.company_name ? (
              <span className="text-lg font-semibold tracking-tight text-foreground">
                {siteSettings.company_name}
              </span>
            ) : null}
          </Link>

          {/* Center: Navigation Links */}
          <div className="hidden md:flex items-center gap-8">
            {uniqueDisplayNavItems.map(item => (
              <Link 
                key={item.id} 
                to={item.url} 
                className={`text-sm font-medium tracking-wide uppercase transition-colors hover:text-foreground/60 ${
                  location.pathname === item.url ? 'text-foreground' : 'text-foreground/80'
                }`}
              >
                {item.title}
              </Link>
            ))}
          </div>

          {/* Right: Actions */}
          <div className="hidden md:flex items-center gap-1">
            {isAuthenticated && (isAdmin || hasDbAdminRole) && (
              <Link 
                to="/admin" 
                className="p-2 text-foreground/70 hover:text-foreground transition-colors"
                title="Admin Panel"
              >
                <Shield size={18} strokeWidth={1.5} />
              </Link>
            )}

            <Dialog open={isSearchOpen} onOpenChange={setIsSearchOpen}>
              <DialogTrigger asChild>
                <button className="p-2 text-foreground/70 hover:text-foreground transition-colors">
                  <Search size={18} strokeWidth={1.5} />
                </button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-md">
                <DialogHeader>
                  <DialogTitle>Search Products</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleSearch} className="relative mt-4">
                  <Input 
                    placeholder="Search products..." 
                    value={searchQuery} 
                    onChange={e => setSearchQuery(e.target.value)} 
                    className="pl-10" 
                    autoFocus 
                  />
                  <Button type="submit" className="mt-4 w-full">Search</Button>
                </form>
              </DialogContent>
            </Dialog>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="p-2 text-foreground/70 hover:text-foreground transition-colors">
                  <User size={18} strokeWidth={1.5} />
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                {isAuthenticated ? (
                  <>
                    <DropdownMenuLabel className="text-xs font-normal text-muted-foreground">
                      {user?.user_metadata?.name || user?.email}
                    </DropdownMenuLabel>
                    <DropdownMenuSeparator />
                    {(isAdmin || hasDbAdminRole) && (
                      <DropdownMenuItem asChild>
                        <Link to="/admin" className="flex items-center">
                          <Shield className="mr-2 h-4 w-4" />
                          Admin Panel
                        </Link>
                      </DropdownMenuItem>
                    )}
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={logout} className="text-destructive focus:text-destructive">
                      <LogOut className="mr-2 h-4 w-4" />
                      Logout
                    </DropdownMenuItem>
                  </>
                ) : (
                  <>
                    <DropdownMenuItem asChild>
                      <Link to="/signin" className="flex items-center">Sign In</Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem asChild>
                      <Link to="/signup" className="flex items-center">Create Account</Link>
                    </DropdownMenuItem>
                  </>
                )}
              </DropdownMenuContent>
            </DropdownMenu>

            <Link to="/favorites" className="p-2 text-foreground/70 hover:text-foreground transition-colors relative">
              <Heart size={18} strokeWidth={1.5} />
              {favoritesCount > 0 && (
                <span className="absolute -top-0.5 -right-0.5 h-4 w-4 flex items-center justify-center rounded-full bg-foreground text-background text-[10px] font-medium">
                  {favoritesCount}
                </span>
              )}
            </Link>

            <Link to="/cart" className="p-2 text-foreground/70 hover:text-foreground transition-colors relative">
              <ShoppingCart size={18} strokeWidth={1.5} />
              {cartCount > 0 && (
                <span className="absolute -top-0.5 -right-0.5 h-4 w-4 flex items-center justify-center rounded-full bg-foreground text-background text-[10px] font-medium">
                  {cartCount}
                </span>
              )}
            </Link>
          </div>

          {/* Mobile: hamburger + cart */}
          <div className="md:hidden flex items-center gap-2">
            <Link to="/cart" className="p-2 text-foreground/70 hover:text-foreground transition-colors relative">
              <ShoppingCart size={18} strokeWidth={1.5} />
              {cartCount > 0 && (
                <span className="absolute -top-0.5 -right-0.5 h-4 w-4 flex items-center justify-center rounded-full bg-foreground text-background text-[10px] font-medium">
                  {cartCount}
                </span>
              )}
            </Link>
            <button onClick={toggleMenu} className="p-2 text-foreground">
              {isMenuOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-background rounded-b-2xl border-t border-border">
          <div className="container mx-auto px-4 py-4 flex flex-col gap-1">
            {uniqueDisplayNavItems.map(item => (
              <Link 
                key={item.id}
                to={item.url}
                className="text-sm font-medium tracking-wide uppercase py-3 px-2 text-foreground/80 hover:text-foreground transition-colors"
                onClick={toggleMenu}
              >
                {item.title}
              </Link>
            ))}
            
            <div className="border-t border-border my-2" />
            
            <div className="py-2 px-2">
              <form onSubmit={(e) => { handleSearch(e); toggleMenu(); }} className="flex gap-2">
                <Input 
                  placeholder="Search products..." 
                  value={searchQuery} 
                  onChange={e => setSearchQuery(e.target.value)} 
                  className="flex-1 h-9 text-sm"
                />
                <Button type="submit" size="sm">Search</Button>
              </form>
            </div>

            <div className="border-t border-border my-2" />
            
            <div className="flex flex-col gap-1">
              <Link to="/favorites" className="flex items-center gap-3 py-3 px-2 text-sm text-foreground/80 hover:text-foreground" onClick={toggleMenu}>
                <Heart size={16} strokeWidth={1.5} />
                Favorites
                {favoritesCount > 0 && <Badge variant="secondary" className="ml-auto text-xs">{favoritesCount}</Badge>}
              </Link>
              
              {isAuthenticated && (
                <>
                  <Link to="/orders" className="flex items-center gap-3 py-3 px-2 text-sm text-foreground/80 hover:text-foreground" onClick={toggleMenu}>
                    My Orders
                  </Link>
                  {(isAdmin || hasDbAdminRole) && (
                    <Link to="/admin" className="flex items-center gap-3 py-3 px-2 text-sm text-foreground/80 hover:text-foreground" onClick={toggleMenu}>
                      <Shield size={16} strokeWidth={1.5} />
                      Admin Panel
                    </Link>
                  )}
                </>
              )}
            </div>

            <div className="border-t border-border my-2" />

            {isAuthenticated ? (
              <button 
                className="flex items-center gap-3 py-3 px-2 text-sm text-destructive" 
                onClick={() => { logout(); toggleMenu(); }}
              >
                <LogOut size={16} strokeWidth={1.5} />
                Logout
              </button>
            ) : (
              <div className="flex gap-3 py-2 px-2">
                <Link to="/signin" className="flex-1" onClick={toggleMenu}>
                  <Button variant="outline" size="sm" className="w-full">Sign In</Button>
                </Link>
                <Link to="/signup" className="flex-1" onClick={toggleMenu}>
                  <Button size="sm" className="w-full">Sign Up</Button>
                </Link>
              </div>
            )}
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
