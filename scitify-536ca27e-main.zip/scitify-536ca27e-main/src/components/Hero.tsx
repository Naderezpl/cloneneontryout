import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Shield } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import NotificationBadge from '@/components/admin/NotificationBadge';
import { useQuery } from '@tanstack/react-query';
import { fetchSiteSettings } from '@/api/settings';
import { supabase } from '@/lib/supabase';
import { useIsMobile } from '@/hooks/use-mobile';

const Hero = () => {
  const { isAdmin } = useAuth();
  const isMobile = useIsMobile();
  const { data: settings } = useQuery({
    queryKey: ['site-settings'],
    queryFn: fetchSiteSettings,
    refetchOnMount: true,
    staleTime: 0,
    refetchOnWindowFocus: false,
  });

  const mediaMode = (settings as any)?.hero_media_mode || 'image';
  const videoUrl = (settings as any)?.hero_video_url || null;
  const slideDuration = (settings as any)?.hero_slide_duration_ms || 5000;
  const videoMobileCrop = (settings as any)?.hero_video_mobile_crop as { x: number; y: number } | null;

  const hasVideo = mediaMode === 'video' && !!videoUrl;

  const { data: slides = [] } = useQuery({
    queryKey: ['homepage-slides-public'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('homepage_slides')
        .select('*')
        .eq('is_active', true)
        .order('display_order');
      if (error) throw error;
      return data || [];
    },
    enabled: mediaMode === 'image',
    refetchOnWindowFocus: false,
  });

  const [currentSlide, setCurrentSlide] = useState(0);

  useEffect(() => {
    if (mediaMode !== 'image' || slides.length <= 1) return;
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, slideDuration);
    return () => clearInterval(timer);
  }, [mediaMode, slides.length, slideDuration]);

  /** Convert crop center % to object-position for mobile */
  const getMobileObjectPosition = (cropData: { x: number; y: number } | null | undefined): string => {
    if (!cropData) return '50% 50%';
    return `${cropData.x}% ${cropData.y}%`;
  };

  const overlay = (
    <div className="absolute bottom-8 md:bottom-16 right-4 md:right-16 z-20 text-right">
      <p className="text-[10px] md:text-xs font-semibold tracking-[0.25em] uppercase text-white/70 mb-2">
        {(settings as any)?.meta_title || 'NEW COLLECTION'}
      </p>
      <h1 className="text-xl sm:text-2xl md:text-3xl lg:text-4xl font-semibold text-white mb-5 leading-tight max-w-sm ml-auto">
        {settings?.site_title || 'Discover Something New'}
      </h1>
      <div className="flex items-center gap-3 justify-end">
        <Link
          to="/shop"
          className="inline-flex items-center justify-center px-6 py-2.5 rounded-full border border-white text-white text-xs font-medium tracking-wider uppercase hover:bg-white hover:text-black transition-all duration-300"
        >
          Shop Now
        </Link>
        {isAdmin && (
          <Link
            to="/admin"
            className="relative inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-full border border-white/30 text-white/70 text-xs font-medium tracking-wider uppercase hover:bg-white hover:text-black transition-all duration-300"
          >
            <Shield size={14} />
            Admin
            <NotificationBadge />
          </Link>
        )}
      </div>
    </div>
  );

  return (
    <div className="md:px-2 md:pt-2 md:pb-2">
      <div className="relative w-full overflow-hidden md:rounded-2xl h-[635px] md:h-[90vh]">
        {hasVideo ? (
          <video
            autoPlay
            loop
            muted
            playsInline
            className="absolute inset-0 w-full h-full object-cover"
            style={isMobile ? { objectPosition: getMobileObjectPosition(videoMobileCrop) } : undefined}
            src={videoUrl!}
          />
        ) : slides.length > 0 ? (
          <>
            {slides.map((slide: any, idx: number) => {
              const mobileCrop = slide.mobile_crop_data as { x: number; y: number } | null;
              return (
                <img
                  key={slide.id}
                  src={slide.image_url}
                  alt={slide.title || `Slide ${idx + 1}`}
                  className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-700 ${
                    idx === currentSlide ? 'opacity-100' : 'opacity-0'
                  }`}
                  style={isMobile && mobileCrop ? { objectPosition: `${mobileCrop.x}% ${mobileCrop.y}%` } : undefined}
                />
              );
            })}
            {slides.length > 1 && (
              <div className="absolute bottom-4 left-1/2 -translate-x-1/2 z-20 flex gap-2">
                {slides.map((_: any, idx: number) => (
                  <button
                    key={idx}
                    onClick={() => setCurrentSlide(idx)}
                    className={`w-2 h-2 rounded-full transition-all ${
                      idx === currentSlide ? 'bg-white w-6' : 'bg-white/50'
                    }`}
                  />
                ))}
              </div>
            )}
          </>
        ) : (
          <div className="absolute inset-0 bg-gradient-to-br from-foreground/90 to-foreground/70 flex flex-col items-center justify-center text-center px-6">
            <p className="text-xs font-semibold tracking-[0.25em] uppercase text-white/60 mb-3">
              {(settings as any)?.meta_title || ''}
            </p>
            <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold text-white max-w-2xl leading-tight">
              {settings?.site_title || 'Welcome'}
            </h1>
            <div className="flex items-center gap-3 mt-8">
              <Link
                to="/shop"
                className="inline-flex items-center justify-center px-8 py-3 rounded-full border border-white text-white text-sm font-medium tracking-wider uppercase hover:bg-white hover:text-black transition-all duration-300"
              >
                Shop Now
              </Link>
              {isAdmin && (
                <Link
                  to="/admin"
                  className="relative inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-full border border-white/30 text-white/70 text-xs font-medium tracking-wider uppercase hover:bg-white hover:text-black transition-all duration-300"
                >
                  <Shield size={14} />
                  Admin
                  <NotificationBadge />
                </Link>
              )}
            </div>
          </div>
        )}

        {(hasVideo || slides.length > 0) && overlay}
      </div>
    </div>
  );
};

export default Hero;
