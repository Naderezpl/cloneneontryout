
import React from 'react';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { Trash2 } from 'lucide-react';
import { CartItem as CartItemType } from '@/contexts/cart';
import CartItem from './CartItem';

interface CartItemsListProps {
  cart: CartItemType[];
  clearCart: () => Promise<void>;
  removeFromCart: (productId: string) => Promise<void>;
  updateQuantity: (productId: string, quantity: number) => Promise<void>;
}

const CartItemsList = ({ 
  cart, 
  clearCart, 
  removeFromCart, 
  updateQuantity 
}: CartItemsListProps) => {
  const [isClearingCart, setIsClearingCart] = React.useState(false);

  const handleClearCart = async () => {
    setIsClearingCart(true);
    try {
      await clearCart();
    } catch (error) {
      console.error('Failed to clear cart:', error);
    } finally {
      setIsClearingCart(false);
    }
  };

  return (
    <div className="md:col-span-2 space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-medium">{cart.length} {cart.length === 1 ? 'Item' : 'Items'}</h2>
        <Button 
          variant="outline" 
          size="sm" 
          onClick={handleClearCart}
          disabled={isClearingCart || cart.length === 0}
          className="text-muted-foreground transition-opacity duration-200"
        >
          <Trash2 className="w-4 h-4 mr-2" />
          Clear Cart
        </Button>
      </div>

      <Separator />

      <div className="space-y-6">
        {cart.map(item => (
          <div 
            key={item.id} 
            className="transition-all duration-300 animate-fade-in"
          >
            <CartItem 
              item={item} 
              updateQuantity={updateQuantity} 
              removeFromCart={removeFromCart}
            />
          </div>
        ))}
      </div>
    </div>
  );
};

export default CartItemsList;
