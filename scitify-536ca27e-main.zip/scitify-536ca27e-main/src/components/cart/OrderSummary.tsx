
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Separator } from '@/components/ui/separator';
import { ArrowRight, X, Tag } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/supabase';

interface OrderSummaryProps {
  subtotal: number;
  hasItems: boolean;
}

interface AppliedCoupon {
  coupon_id: string;
  code: string;
  discount: number;
  discount_type: string;
  discount_value: number;
}

const OrderSummary = ({ subtotal, hasItems }: OrderSummaryProps) => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [promoCode, setPromoCode] = useState('');
  const [applying, setApplying] = useState(false);
  const [appliedCoupon, setAppliedCoupon] = useState<AppliedCoupon | null>(null);

  const discount = appliedCoupon?.discount ?? 0;
  const total = Math.max(0, subtotal - discount);

  const handleApplyCoupon = async () => {
    if (!promoCode.trim()) return;
    setApplying(true);
    try {
      const { data, error } = await supabase.rpc('validate_coupon', {
        p_code: promoCode.trim(),
        p_subtotal: subtotal,
        p_customer_email: '', // Will be fully validated at checkout with email
      });
      if (error) throw error;
      
      const result = data as any;
      if (!result?.valid) {
        toast({ variant: 'destructive', title: 'Invalid coupon', description: result?.error || 'Could not apply coupon.' });
        return;
      }

      setAppliedCoupon({
        coupon_id: result.coupon_id,
        code: result.code,
        discount: result.discount,
        discount_type: result.discount_type,
        discount_value: result.discount_value,
      });
      toast({ title: 'Coupon applied!', description: `${result.discount_type === 'percentage' ? result.discount_value + '%' : '$' + result.discount_value} discount applied.` });
    } catch (err) {
      toast({ variant: 'destructive', title: 'Error', description: 'Could not validate coupon.' });
    } finally {
      setApplying(false);
    }
  };

  const removeCoupon = () => {
    setAppliedCoupon(null);
    setPromoCode('');
  };

  const handleCheckout = () => {
    if (!hasItems) {
      toast({
        variant: "destructive",
        title: "Cart is empty",
        description: "Please add some items to your cart before checkout",
      });
      return;
    }
    
    // Pass coupon data via navigation state
    navigate('/checkout', { state: { coupon: appliedCoupon } });
  };

  return (
    <div className="bg-muted rounded-lg p-6">
      <h2 className="text-xl font-medium mb-4">Order Summary</h2>
      
      <div className="space-y-4">
        <div className="flex justify-between">
          <span className="text-muted-foreground">Subtotal</span>
          <span>${subtotal.toFixed(2)}</span>
        </div>

        {appliedCoupon && (
          <div className="flex justify-between items-center text-green-600">
            <span className="flex items-center gap-1">
              <Tag className="h-3 w-3" />
              Discount ({appliedCoupon.code})
              <button onClick={removeCoupon} className="ml-1 hover:text-destructive">
                <X className="h-3 w-3" />
              </button>
            </span>
            <span>-${discount.toFixed(2)}</span>
          </div>
        )}
        
        <Separator />
        
        <div className="flex justify-between text-lg font-medium">
          <span>Total</span>
          <span>${total.toFixed(2)}</span>
        </div>
        
        {/* Promo Code */}
        {!appliedCoupon && (
          <div className="pt-4">
            <label htmlFor="promo" className="block text-sm font-medium mb-2">
              Promo Code
            </label>
            <div className="flex space-x-2">
              <Input
                id="promo"
                placeholder="Enter code"
                className="flex-grow font-mono uppercase"
                value={promoCode}
                onChange={(e) => setPromoCode(e.target.value.toUpperCase())}
                onKeyDown={(e) => e.key === 'Enter' && handleApplyCoupon()}
              />
              <Button variant="outline" onClick={handleApplyCoupon} disabled={applying}>
                {applying ? '...' : 'Apply'}
              </Button>
            </div>
          </div>
        )}
        
        {/* Checkout Button */}
        <Button 
          className="w-full mt-6" 
          size="lg"
          onClick={handleCheckout}
        >
          Checkout
          <ArrowRight className="ml-2 h-4 w-4" />
        </Button>
        
        <p className="text-center text-sm text-muted-foreground mt-4">
          Secure checkout powered by Stripe
        </p>
      </div>
    </div>
  );
};

export default OrderSummary;
