
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Trash2, Minus, Plus } from 'lucide-react';
import { CartItem as CartItemType } from '@/contexts/cart';
import { cn } from '@/lib/utils';

interface CartItemProps {
  item: CartItemType;
  updateQuantity: (productId: string, quantity: number) => Promise<void>;
  removeFromCart: (productId: string) => Promise<void>;
}

const CartItem = ({ item, updateQuantity, removeFromCart }: CartItemProps) => {
  const [isUpdating, setIsUpdating] = useState(false);
  const [isRemoving, setIsRemoving] = useState(false);
  const [optimisticQuantity, setOptimisticQuantity] = useState(item.quantity);
  
  const itemImage = item.product.images && item.product.images.length > 0 
    ? item.product.images[0].image_url 
    : 'https://placehold.co/300x300?text=No+Image';
  
  const handleQuantityChange = async (newQuantity: number) => {
    if (isUpdating || newQuantity < 1) return;
    
    // Optimistic update
    setIsUpdating(true);
    const previousQuantity = optimisticQuantity;
    setOptimisticQuantity(newQuantity);
    
    try {
      await updateQuantity(item.id, newQuantity);
    } catch (error) {
      // Rollback on failure
      console.error('Failed to update quantity:', error);
      setOptimisticQuantity(previousQuantity);
    } finally {
      setIsUpdating(false);
    }
  };
  
  const handleRemove = async () => {
    if (isRemoving) return;
    
    setIsRemoving(true);
    try {
      await removeFromCart(item.id);
    } catch (error) {
      console.error('Failed to remove item:', error);
      setIsRemoving(false);
    }
  };
    
  return (
    <div className={cn(
      "flex flex-col sm:flex-row gap-4 py-4 transition-opacity duration-300",
      isRemoving ? "opacity-50" : "opacity-100"
    )}>
      <div className="flex-shrink-0 w-full sm:w-32 h-32 bg-muted rounded-md overflow-hidden">
        <img 
          src={itemImage} 
          alt={item.product.name} 
          className="w-full h-full object-cover"
        />
      </div>
      
      <div className="flex-grow flex flex-col justify-between">
        <div>
          <h3 className="font-medium">
            {item.product.name}{item.variant.variant_name && item.variant.variant_name !== 'Default' ? ` - ${item.variant.variant_name}` : ''}
          </h3>
          <p className="text-sm text-muted-foreground line-clamp-2">{item.product.description}</p>
        </div>
        
        <div className="flex flex-wrap justify-between items-center mt-4 gap-4">
          <div className="flex items-center space-x-2">
            <Button 
              variant="outline" 
              size="icon" 
              className={cn(
                "h-8 w-8 rounded-full transition-all duration-200",
                isUpdating && "opacity-50"
              )}
              onClick={() => handleQuantityChange(optimisticQuantity - 1)}
              disabled={isUpdating || optimisticQuantity <= 1}
            >
              <Minus className="h-3 w-3" />
            </Button>
            
            <span className="w-8 text-center transition-all duration-200">
              {optimisticQuantity}
            </span>
            
            <Button 
              variant="outline" 
              size="icon" 
              className={cn(
                "h-8 w-8 rounded-full transition-all duration-200",
                isUpdating && "opacity-50"
              )}
              onClick={() => handleQuantityChange(optimisticQuantity + 1)}
              disabled={isUpdating}
            >
              <Plus className="h-3 w-3" />
            </Button>
          </div>
          
          <div className="flex items-center space-x-4">
            <span className="font-medium transition-all duration-200">
              ${(item.variant.price * optimisticQuantity).toFixed(2)}
            </span>
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={handleRemove}
              disabled={isRemoving || isUpdating}
              className={cn(
                "transition-all duration-200",
                (isRemoving || isUpdating) && "opacity-50"
              )}
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CartItem;
