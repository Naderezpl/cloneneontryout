
import React from 'react';
import { Link } from 'react-router-dom';
import { LogOut, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/AuthContext';

const AdminNavbar = () => {
  const { logout, user } = useAuth();

  return (
    <nav className="bg-background border-b border-muted py-2 sm:py-4 sticky top-0 z-50">
      <div className="container mx-auto px-2 sm:px-4 flex justify-between items-center gap-2">
        <div className="flex items-center gap-2 sm:gap-4 min-w-0">
          <Link to="/" className="flex items-center text-foreground hover:text-primary shrink-0">
            <ArrowLeft size={18} className="mr-1" />
            <span className="hidden sm:inline">Back to Store</span>
          </Link>
          <span className="text-lg sm:text-2xl font-bold text-primary truncate">
            Admin
          </span>
        </div>

        <div className="flex items-center gap-2 sm:gap-4 min-w-0">
          {user && (
            <span className="text-xs sm:text-sm text-muted-foreground hidden md:inline truncate">
              {user.email}
            </span>
          )}
          <Button variant="outline" size="sm" onClick={logout} className="flex items-center gap-1 shrink-0">
            <LogOut size={16} />
            <span className="hidden sm:inline">Logout</span>
          </Button>
        </div>
      </div>
    </nav>
  );
};

export default AdminNavbar;
