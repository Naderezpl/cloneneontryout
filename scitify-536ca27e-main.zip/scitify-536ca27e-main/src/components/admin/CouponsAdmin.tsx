import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/lib/supabase';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Card, CardContent } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/components/ui/use-toast';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Plus, Trash2, Edit2, CalendarIcon, Copy, RefreshCw } from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';

interface Coupon {
  id: string;
  code: string;
  discount_type: 'percentage' | 'fixed';
  discount_value: number;
  min_subtotal: number | null;
  max_uses: number | null;
  max_uses_per_customer: number | null;
  starts_at: string | null;
  expires_at: string | null;
  is_active: boolean;
  usage_count: number;
  created_at: string;
}

const generateCode = () => {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code = '';
  for (let i = 0; i < 8; i++) code += chars[Math.floor(Math.random() * chars.length)];
  return code;
};

const emptyForm = {
  code: '',
  discount_type: 'percentage' as 'percentage' | 'fixed',
  discount_value: 10,
  min_subtotal: 0,
  max_uses: null as number | null,
  max_uses_per_customer: 1,
  starts_at: null as Date | null,
  expires_at: null as Date | null,
  is_active: true,
};

const CouponsAdmin = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState({ ...emptyForm });

  const { data: coupons = [], isLoading } = useQuery({
    queryKey: ['admin-coupons'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('coupons')
        .select('*')
        .order('created_at', { ascending: false });
      if (error) throw error;
      return data as Coupon[];
    },
  });

  const saveMutation = useMutation({
    mutationFn: async () => {
      const payload = {
        code: form.code.trim(),
        discount_type: form.discount_type,
        discount_value: form.discount_value,
        min_subtotal: form.min_subtotal || 0,
        max_uses: form.max_uses || null,
        max_uses_per_customer: form.max_uses_per_customer || null,
        starts_at: form.starts_at ? form.starts_at.toISOString() : new Date().toISOString(),
        expires_at: form.expires_at ? form.expires_at.toISOString() : null,
        is_active: form.is_active,
      };
      if (!payload.code) throw new Error('Code is required');
      if (payload.discount_value <= 0) throw new Error('Discount value must be positive');

      if (editingId) {
        const { error } = await supabase.from('coupons').update(payload).eq('id', editingId);
        if (error) throw error;
      } else {
        const { error } = await supabase.from('coupons').insert(payload);
        if (error) throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-coupons'] });
      toast({ title: editingId ? 'Coupon updated' : 'Coupon created' });
      setDialogOpen(false);
      resetForm();
    },
    onError: (err: Error) => {
      toast({ variant: 'destructive', title: 'Error', description: err.message });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from('coupons').delete().eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-coupons'] });
      toast({ title: 'Coupon deleted' });
    },
  });

  const toggleMutation = useMutation({
    mutationFn: async ({ id, is_active }: { id: string; is_active: boolean }) => {
      const { error } = await supabase.from('coupons').update({ is_active }).eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['admin-coupons'] }),
  });

  const resetForm = () => {
    setForm({ ...emptyForm });
    setEditingId(null);
  };

  const openEdit = (c: Coupon) => {
    setEditingId(c.id);
    setForm({
      code: c.code,
      discount_type: c.discount_type,
      discount_value: c.discount_value,
      min_subtotal: c.min_subtotal || 0,
      max_uses: c.max_uses,
      max_uses_per_customer: c.max_uses_per_customer,
      starts_at: c.starts_at ? new Date(c.starts_at) : null,
      expires_at: c.expires_at ? new Date(c.expires_at) : null,
      is_active: c.is_active,
    });
    setDialogOpen(true);
  };

  const isExpired = (c: Coupon) => c.expires_at && new Date(c.expires_at) < new Date();
  const isMaxedOut = (c: Coupon) => c.max_uses !== null && c.usage_count >= c.max_uses;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-semibold">Coupon Codes</h2>
        <Dialog open={dialogOpen} onOpenChange={(o) => { setDialogOpen(o); if (!o) resetForm(); }}>
          <DialogTrigger asChild>
            <Button><Plus className="mr-2 h-4 w-4" />Create Coupon</Button>
          </DialogTrigger>
          <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{editingId ? 'Edit Coupon' : 'Create Coupon'}</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 pt-2">
              {/* Code */}
              <div>
                <Label>Coupon Code</Label>
                <div className="flex gap-2 mt-1">
                  <Input
                    value={form.code}
                    onChange={(e) => setForm({ ...form, code: e.target.value.toUpperCase() })}
                    placeholder="e.g. SUMMER20"
                    className="font-mono"
                  />
                  <Button type="button" variant="outline" size="icon" onClick={() => setForm({ ...form, code: generateCode() })} title="Auto-generate">
                    <RefreshCw className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              {/* Discount */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Discount Type</Label>
                  <Select value={form.discount_type} onValueChange={(v) => setForm({ ...form, discount_type: v as any })}>
                    <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="percentage">Percentage (%)</SelectItem>
                      <SelectItem value="fixed">Fixed Amount ($)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Value</Label>
                  <Input
                    type="number"
                    min={0}
                    value={form.discount_value}
                    onChange={(e) => setForm({ ...form, discount_value: Number(e.target.value) })}
                    className="mt-1"
                  />
                </div>
              </div>

              {/* Min subtotal */}
              <div>
                <Label>Minimum Subtotal ($)</Label>
                <Input
                  type="number"
                  min={0}
                  value={form.min_subtotal ?? 0}
                  onChange={(e) => setForm({ ...form, min_subtotal: Number(e.target.value) })}
                  className="mt-1"
                />
              </div>

              {/* Usage limits */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Total Usage Limit</Label>
                  <Input
                    type="number"
                    min={0}
                    placeholder="Unlimited"
                    value={form.max_uses ?? ''}
                    onChange={(e) => setForm({ ...form, max_uses: e.target.value ? Number(e.target.value) : null })}
                    className="mt-1"
                  />
                </div>
                <div>
                  <Label>Per Customer Limit</Label>
                  <Input
                    type="number"
                    min={0}
                    placeholder="Unlimited"
                    value={form.max_uses_per_customer ?? ''}
                    onChange={(e) => setForm({ ...form, max_uses_per_customer: e.target.value ? Number(e.target.value) : null })}
                    className="mt-1"
                  />
                </div>
              </div>

              {/* Dates */}
              <div className="grid grid-cols-2 gap-4">
                <DateField label="Start Date" value={form.starts_at} onChange={(d) => setForm({ ...form, starts_at: d })} />
                <DateField label="End Date" value={form.expires_at} onChange={(d) => setForm({ ...form, expires_at: d })} />
              </div>

              {/* Active */}
              <div className="flex items-center gap-3">
                <Switch checked={form.is_active} onCheckedChange={(v) => setForm({ ...form, is_active: v })} />
                <Label>Active</Label>
              </div>

              <Button className="w-full" onClick={() => saveMutation.mutate()} disabled={saveMutation.isPending}>
                {saveMutation.isPending ? 'Saving...' : editingId ? 'Update Coupon' : 'Create Coupon'}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {isLoading ? (
        <p className="text-muted-foreground">Loading...</p>
      ) : coupons.length === 0 ? (
        <p className="text-muted-foreground text-center py-8">No coupons yet. Create your first one!</p>
      ) : (
        <div className="space-y-3">
          {coupons.map((c) => (
            <Card key={c.id}>
              <CardContent className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 py-4">
                <div className="flex-1 space-y-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-mono font-bold text-lg">{c.code}</span>
                    <Badge variant={c.is_active && !isExpired(c) && !isMaxedOut(c) ? 'default' : 'secondary'}>
                      {!c.is_active ? 'Inactive' : isExpired(c) ? 'Expired' : isMaxedOut(c) ? 'Maxed Out' : 'Active'}
                    </Badge>
                    <Badge variant="outline">
                      {c.discount_type === 'percentage' ? `${c.discount_value}% off` : `$${c.discount_value} off`}
                    </Badge>
                  </div>
                  <div className="text-sm text-muted-foreground flex flex-wrap gap-x-4 gap-y-1">
                    <span>Used: {c.usage_count}{c.max_uses ? `/${c.max_uses}` : ''}</span>
                    {c.min_subtotal ? <span>Min: ${c.min_subtotal}</span> : null}
                    {c.expires_at && <span>Expires: {format(new Date(c.expires_at), 'MMM d, yyyy')}</span>}
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Switch
                    checked={c.is_active}
                    onCheckedChange={(v) => toggleMutation.mutate({ id: c.id, is_active: v })}
                  />
                  <Button variant="ghost" size="icon" onClick={() => openEdit(c)}><Edit2 className="h-4 w-4" /></Button>
                  <Button variant="ghost" size="icon" onClick={() => { if (confirm('Delete this coupon?')) deleteMutation.mutate(c.id); }}>
                    <Trash2 className="h-4 w-4 text-destructive" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};

const DateField = ({ label, value, onChange }: { label: string; value: Date | null; onChange: (d: Date | null) => void }) => (
  <div>
    <Label>{label}</Label>
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="outline" className={cn("w-full mt-1 justify-start text-left font-normal", !value && "text-muted-foreground")}>
          <CalendarIcon className="mr-2 h-4 w-4" />
          {value ? format(value, 'PPP') : 'Pick a date'}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-auto p-0" align="start">
        <Calendar mode="single" selected={value ?? undefined} onSelect={(d) => onChange(d ?? null)} className="p-3 pointer-events-auto" />
      </PopoverContent>
    </Popover>
    {value && (
      <Button variant="link" size="sm" className="p-0 h-auto text-xs" onClick={() => onChange(null)}>Clear</Button>
    )}
  </div>
);

export default CouponsAdmin;
