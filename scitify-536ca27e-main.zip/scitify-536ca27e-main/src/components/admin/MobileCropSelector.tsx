import React, { useRef, useState, useCallback, useEffect } from 'react';
import { Smartphone } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';

export interface MobileCropData {
  /** Percentage from left (0-100) representing the center of the frame */
  x: number;
  /** Percentage from top (0-100) representing the center of the frame */
  y: number;
  /** Width of the frame as percentage of container width */
  widthPct?: number;
}

interface MobileCropSelectorProps {
  src: string;
  isVideo?: boolean;
  cropData: MobileCropData | null;
  onChange: (data: MobileCropData) => void;
}

/**
 * Mobile hero: full-width × 70vh on a 9:16 phone.
 * With object-cover on a 16:9 source, height fills 100% and
 * visible width = mobileAR / sourceAR = (9/(0.7*16)) / (16/9) ≈ 45.2%
 * Y is always fully visible so only X panning matters.
 */
const SOURCE_ASPECT = 16 / 9;
const MOBILE_ASPECT = 9 / (0.7 * 16); // ≈ 0.804
const FRAME_WIDTH_PCT = (MOBILE_ASPECT / SOURCE_ASPECT) * 100; // ≈ 45.2%
const FRAME_HEIGHT_PCT = 100;

const MobileCropSelector: React.FC<MobileCropSelectorProps> = ({
  src,
  isVideo = false,
  cropData,
  onChange,
}) => {
  const [open, setOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const [dragging, setDragging] = useState(false);
  const [posX, setPosX] = useState(cropData?.x ?? 50);
  const dragStartRef = useRef({ startClientX: 0, startPosX: 50 });

  useEffect(() => {
    if (cropData) setPosX(cropData.x);
  }, [cropData]);

  const clampX = (x: number) => {
    const half = FRAME_WIDTH_PCT / 2;
    return Math.max(half, Math.min(100 - half, x));
  };

  const handlePointerDown = useCallback((e: React.PointerEvent) => {
    e.preventDefault();
    e.stopPropagation();
    dragStartRef.current = { startClientX: e.clientX, startPosX: posX };
    setDragging(true);
  }, [posX]);

  const handlePointerMove = useCallback((e: React.PointerEvent) => {
    if (!dragging) return;
    const rect = containerRef.current?.getBoundingClientRect();
    if (!rect) return;
    const deltaPct = ((e.clientX - dragStartRef.current.startClientX) / rect.width) * 100;
    setPosX(clampX(dragStartRef.current.startPosX + deltaPct));
  }, [dragging]);

  const handlePointerUp = useCallback(() => setDragging(false), []);

  const handleSave = () => {
    // Y is always centered since object-cover shows full height
    onChange({ x: posX, y: 50, widthPct: FRAME_WIDTH_PCT });
    setOpen(false);
  };

  const frameLeft = posX - FRAME_WIDTH_PCT / 2;

  return (
    <>
      <Button
        type="button"
        variant="outline"
        size="sm"
        onClick={() => setOpen(true)}
        className="flex items-center gap-1.5"
      >
        <Smartphone size={14} />
        Mobile Crop
      </Button>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Select Mobile View (70vh Portrait)</DialogTitle>
          </DialogHeader>
          <p className="text-sm text-muted-foreground mb-3">
            Drag the frame left or right to choose which part of the image is visible on mobile.
          </p>

          <div
            ref={containerRef}
            className="relative w-full aspect-video bg-black rounded-lg overflow-hidden select-none touch-none"
            onPointerMove={handlePointerMove}
            onPointerUp={handlePointerUp}
            onPointerLeave={handlePointerUp}
          >
            {isVideo ? (
              <video src={src} className="w-full h-full object-cover" muted autoPlay loop playsInline />
            ) : (
              <img src={src} alt="Preview" className="w-full h-full object-cover" />
            )}

            {/* Dark overlay with cut-out for the visible frame */}
            <div className="absolute inset-0 pointer-events-none">
              {/* Left dark region */}
              <div
                className="absolute top-0 bottom-0 left-0 bg-black/55"
                style={{ width: `${frameLeft}%` }}
              />
              {/* Right dark region */}
              <div
                className="absolute top-0 bottom-0 right-0 bg-black/55"
                style={{ width: `${100 - frameLeft - FRAME_WIDTH_PCT}%` }}
              />
            </div>

            {/* Draggable frame */}
            <div
              className="absolute border-2 border-white rounded-sm"
              style={{
                left: `${frameLeft}%`,
                top: '0%',
                width: `${FRAME_WIDTH_PCT}%`,
                height: `${FRAME_HEIGHT_PCT}%`,
                cursor: 'grab',
              }}
              onPointerDown={handlePointerDown}
            >
              {/* Left handle */}
              <div
                className="absolute top-1/2 -translate-y-1/2 -left-1 w-2 h-12 bg-white rounded shadow-md"
                style={{ cursor: 'ew-resize' }}
              />
              {/* Right handle */}
              <div
                className="absolute top-1/2 -translate-y-1/2 -right-1 w-2 h-12 bg-white rounded shadow-md"
                style={{ cursor: 'ew-resize' }}
              />

              <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                <span className="text-white text-xs font-medium bg-black/50 px-2 py-0.5 rounded">
                  Mobile View
                </span>
              </div>
            </div>
          </div>

          <div className="flex justify-end gap-2 mt-2">
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button onClick={handleSave}>Apply</Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default MobileCropSelector;
