import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/lib/supabase';
import { 
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow 
} from '@/components/ui/table-aligned';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { 
  Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle 
} from '@/components/ui/dialog';
import { 
  Form, FormControl, FormField, FormItem, FormLabel, FormMessage 
} from '@/components/ui/form';
import { useToast } from '@/components/ui/use-toast';
import { Edit, Trash2, Plus, ArrowUp, ArrowDown, Eye, EyeOff } from 'lucide-react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Switch } from '@/components/ui/switch';
import NavigationSeeder from './NavigationSeeder';

const formSchema = z.object({
  id: z.string().optional(),
  title: z.string().min(2, { message: "Title must be at least 2 characters" }),
  url: z.string().min(1, { message: "URL is required" }),
  order: z.number().int().nonnegative(),
  is_enabled: z.boolean().default(true),
});

type NavItem = {
  id: string;
  title: string;
  url: string;
  order: number;
  is_enabled: boolean;
  created_at?: string;
  updated_at?: string;
};

const NavigationAdmin = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isOpen, setIsOpen] = useState(false);
  const [isDeleteOpen, setIsDeleteOpen] = useState(false);
  const [currentNavItem, setCurrentNavItem] = useState<NavItem | null>(null);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      title: '',
      url: '',
      order: 0,
      is_enabled: true,
    }
  });

  const { data: navItems = [], isLoading } = useQuery({
    queryKey: ['nav-items'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('nav_items')
        .select('*')
        .order('order');
        
      if (error) throw error;
      return data as NavItem[];
    }
  });

  const saveMutation = useMutation({
    mutationFn: async (values: z.infer<typeof formSchema>) => {
      const now = new Date().toISOString();
      const isNew = !values.id;
      
      if (isNew) {
        const { data, error } = await supabase
          .from('nav_items')
          .insert({
            title: values.title,
            url: values.url,
            order: values.order,
            is_enabled: values.is_enabled,
            created_at: now,
            updated_at: now
          })
          .select();
        
        if (error) throw error;
        return data[0];
      } else {
        const { data, error } = await supabase
          .from('nav_items')
          .update({
            title: values.title,
            url: values.url,
            order: values.order,
            is_enabled: values.is_enabled,
            updated_at: now
          })
          .eq('id', values.id)
          .select();
        
        if (error) throw error;
        return data[0];
      }
    },
    onSuccess: (data, variables) => {
      queryClient.invalidateQueries({ queryKey: ['nav-items'] });
      queryClient.invalidateQueries({ queryKey: ['navigation-items'] });
      setIsOpen(false);
      toast({
        title: variables.id ? "Navigation Item Updated" : "Navigation Item Created",
        description: `${data.title} has been ${variables.id ? "updated" : "created"} successfully.`,
      });
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Error",
        description: `Failed to save navigation item: ${error.message}`,
      });
    }
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const { data, error } = await supabase
        .from('nav_items')
        .delete()
        .eq('id', id)
        .select('id')
        .maybeSingle();
      
      if (error) throw error;
      if (!data) {
        throw new Error('Delete was blocked by permissions (no rows deleted).');
      }
      return id;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['nav-items'] });
      queryClient.invalidateQueries({ queryKey: ['navigation-items'] });
      queryClient.refetchQueries({ queryKey: ['nav-items'], type: 'active' });
      queryClient.refetchQueries({ queryKey: ['navigation-items'], type: 'active' });
      setIsDeleteOpen(false);
      toast({
        title: "Navigation Item Deleted",
        description: "The navigation item has been deleted successfully.",
      });
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Error",
        description: `Failed to delete navigation item: ${error.message}`,
      });
    }
  });

  const toggleVisibilityMutation = useMutation({
    mutationFn: async ({ id, isEnabled }: { id: string, isEnabled: boolean }) => {
      const { data, error } = await supabase
        .from('nav_items')
        .update({ 
          is_enabled: isEnabled,
          updated_at: new Date().toISOString() 
        })
        .eq('id', id)
        .select()
        .maybeSingle();
      
      if (error) throw error;
      if (!data) {
        throw new Error('Update was blocked by permissions (no rows updated).');
      }
      return data as NavItem;
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['nav-items'] });
      queryClient.invalidateQueries({ queryKey: ['navigation-items'] });
      toast({
        title: `Navigation Item ${data.is_enabled ? 'Enabled' : 'Disabled'}`,
        description: `"${data.title}" is now ${data.is_enabled ? 'visible' : 'hidden'} in the navigation menu.`,
      });
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Error",
        description: `Failed to update visibility: ${error.message}`,
      });
    }
  });

  const reorderMutation = useMutation({
    mutationFn: async ({ id, newOrder }: { id: string, newOrder: number }) => {
      const { data, error } = await supabase
        .from('nav_items')
        .update({ 
          order: newOrder, 
          updated_at: new Date().toISOString() 
        })
        .eq('id', id)
        .select('id')
        .maybeSingle();
      
      if (error) throw error;
      if (!data) {
        throw new Error('Update was blocked by permissions (no rows updated).');
      }
      return { id, newOrder };
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['nav-items'] });
      queryClient.invalidateQueries({ queryKey: ['navigation-items'] });
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Error",
        description: `Failed to reorder navigation: ${error.message}`,
      });
    }
  });

  const handleEdit = (navItem: NavItem) => {
    setCurrentNavItem(navItem);
    form.reset({
      id: navItem.id,
      title: navItem.title,
      url: navItem.url,
      order: navItem.order,
      is_enabled: navItem.is_enabled ?? true
    });
    setIsOpen(true);
  };

  const handleNew = () => {
    setCurrentNavItem(null);
    form.reset({
      title: '',
      url: '',
      order: navItems.length,
      is_enabled: true
    });
    setIsOpen(true);
  };

  const handleDelete = (navItem: NavItem) => {
    setCurrentNavItem(navItem);
    setIsDeleteOpen(true);
  };

  const toggleVisibility = (navItem: NavItem) => {
    toggleVisibilityMutation.mutate({ 
      id: navItem.id, 
      isEnabled: !navItem.is_enabled 
    });
  };

  const confirmDelete = () => {
    if (currentNavItem) {
      deleteMutation.mutate(currentNavItem.id);
    }
  };

  const moveUp = (index: number) => {
    if (index === 0) return;
    
    const itemToMove = navItems[index];
    const itemAbove = navItems[index - 1];
    
    reorderMutation.mutate({ id: itemToMove.id, newOrder: itemAbove.order });
    reorderMutation.mutate({ id: itemAbove.id, newOrder: itemToMove.order });
  };

  const moveDown = (index: number) => {
    if (index === navItems.length - 1) return;
    
    const itemToMove = navItems[index];
    const itemBelow = navItems[index + 1];
    
    reorderMutation.mutate({ id: itemToMove.id, newOrder: itemBelow.order });
    reorderMutation.mutate({ id: itemBelow.id, newOrder: itemToMove.order });
  };

  const onSubmit = (values: z.infer<typeof formSchema>) => {
    saveMutation.mutate(values);
  };

  if (isLoading) {
    return <div className="text-center py-8">Loading navigation items...</div>;
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">Manage Navigation</h2>
        <Button onClick={handleNew}>
          <Plus className="mr-2 h-4 w-4" /> Add Navigation Item
        </Button>
      </div>

      <NavigationSeeder />

      <Table>
        <TableHeader>
          <TableRow>
            <TableHead verticalAlign="middle">Order</TableHead>
            <TableHead verticalAlign="middle">Title</TableHead>
            <TableHead verticalAlign="middle">URL</TableHead>
            <TableHead verticalAlign="middle">Visibility</TableHead>
            <TableHead verticalAlign="middle">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {navItems.map((navItem, index) => (
            <TableRow key={navItem.id} className={!navItem.is_enabled ? "opacity-60" : ""}>
              <TableCell verticalAlign="middle">{navItem.order}</TableCell>
              <TableCell verticalAlign="middle">{navItem.title}</TableCell>
              <TableCell verticalAlign="middle">{navItem.url}</TableCell>
              <TableCell verticalAlign="middle">
                <Switch 
                  checked={navItem.is_enabled ?? true} 
                  onCheckedChange={() => toggleVisibility(navItem)}
                  aria-label={`Toggle ${navItem.title} visibility`}
                />
              </TableCell>
              <TableCell verticalAlign="middle">
                <div className="flex space-x-2">
                  <Button variant="outline" size="sm" onClick={() => moveUp(index)} disabled={index === 0}>
                    <ArrowUp className="h-4 w-4" />
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => moveDown(index)} disabled={index === navItems.length - 1}>
                    <ArrowDown className="h-4 w-4" />
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => handleEdit(navItem)}>
                    <Edit className="h-4 w-4" />
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => toggleVisibility(navItem)}>
                    {navItem.is_enabled ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </Button>
                  <Button variant="destructive" size="sm" onClick={() => handleDelete(navItem)}>
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {currentNavItem ? `Edit Navigation: ${currentNavItem.title}` : 'Add New Navigation Item'}
            </DialogTitle>
          </DialogHeader>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="title"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Title</FormLabel>
                    <FormControl>
                      <Input {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="url"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>URL</FormLabel>
                    <FormControl>
                      <Input {...field} placeholder="/shop" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="order"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Order</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        {...field} 
                        onChange={(e) => field.onChange(parseInt(e.target.value))}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="is_enabled"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3 shadow-sm">
                    <div className="space-y-0.5">
                      <FormLabel>Visible in Navigation</FormLabel>
                    </div>
                    <FormControl>
                      <Switch checked={field.value} onCheckedChange={field.onChange} />
                    </FormControl>
                  </FormItem>
                )}
              />
              
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" disabled={saveMutation.isPending}>
                  {saveMutation.isPending ? 'Saving...' : 'Save Item'}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      <Dialog open={isDeleteOpen} onOpenChange={setIsDeleteOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirm Deletion</DialogTitle>
          </DialogHeader>
          <p>
            Are you sure you want to delete the navigation item "{currentNavItem?.title}"? 
            This action cannot be undone.
          </p>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDeleteOpen(false)}>
              Cancel
            </Button>
            <Button 
              variant="destructive" 
              onClick={confirmDelete}
              disabled={deleteMutation.isPending}
            >
              {deleteMutation.isPending ? 'Deleting...' : 'Delete Item'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default NavigationAdmin;
