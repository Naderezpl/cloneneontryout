import React, { useMemo, useRef, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { supabase } from '@/lib/supabase';
import { fetchSiteSettings, updateSingleSetting } from '@/api/settings';
import { CheckCircle2, XCircle, RefreshCcw, Eye, ShieldCheck } from 'lucide-react';
import Footer from '@/components/Footer';
import Index from '@/pages/Index';

type CheckResult = { id: string; label: string; status: 'pass'|'fail'; detail?: string };

async function tryUpdateAndVerify(field: string, value: any): Promise<boolean> {
  try {
    await updateSingleSetting(field, value);
    const s = await fetchSiteSettings();
    // @ts-ignore
    return String((s as any)[field]) === String(value);
  } catch {
    return false;
  }
}

async function checkColumnExists(table: string, column: string): Promise<boolean> {
  try {
    const { data, error } = await supabase
      .from(table as any)
      .select(column)
      .limit(1);
    return !error;
  } catch {
    return false;
  }
}

function sleep(ms: number) {
  return new Promise(res => setTimeout(res, ms));
}

const AdminDiagnostics: React.FC = () => {
  const [running, setRunning] = useState(false);
  const [results, setResults] = useState<CheckResult[]>([]);
  const [previewKey, setPreviewKey] = useState(0);
  const [homeKey, setHomeKey] = useState(0);
  const homeRef = useRef<HTMLDivElement>(null);

  const checks: Array<{ id: string; label: string; run: () => Promise<CheckResult> }> = useMemo(() => [
    {
      id: 'db-conn',
      label: 'Database connectivity',
      run: async () => {
        const ok = await checkColumnExists('site_settings', 'id');
        return { id: 'db-conn', label: 'Database connectivity', status: ok ? 'pass' : 'fail', detail: ok ? 'OK' : 'site_settings not accessible' };
      }
    },
    {
      id: 'settings-toggle',
      label: 'Toggle: show_testimonials_section',
      run: async () => {
        const val = Math.random() > 0.5;
        const ok = await tryUpdateAndVerify('show_testimonials_section', val);
        return { id: 'settings-toggle', label: 'Toggle: show_testimonials_section', status: ok ? 'pass' : 'fail', detail: ok ? `Saved=${val}` : 'Update failed' };
      }
    },
    {
      id: 'review-moderation-columns',
      label: 'Review moderation settings columns',
      run: async () => {
        const cols = ['moderation_enabled','ai_moderation_enabled','auto_publish_min_stars','send_below_stars_to_moderation','block_spam_reviews'];
        const oks = await Promise.all(cols.map(c => checkColumnExists('site_settings', c)));
        const ok = oks.every(Boolean);
        return { id: 'review-moderation-columns', label: 'Review moderation settings columns', status: ok ? 'pass' : 'fail', detail: ok ? 'All columns present' : 'Missing column(s)' };
      }
    },
    {
      id: 'video-feed-columns',
      label: 'Video feed settings columns',
      run: async () => {
        const cols = ['video_feed_enabled','video_feed_count','video_feed_refresh_minutes','video_feed_autoplay_enabled'];
        const oks = await Promise.all(cols.map(c => checkColumnExists('site_settings', c)));
        const ok = oks.every(Boolean);
        return { id: 'video-feed-columns', label: 'Video feed settings columns', status: ok ? 'pass' : 'fail', detail: ok ? 'All columns present' : 'Missing column(s)' };
      }
    },
    {
      id: 'video-feed-table',
      label: 'Video feed items table exists',
      run: async () => {
        const ok = await checkColumnExists('video_feed', 'row_type');
        return { id: 'video-feed-table', label: 'Video feed items table exists', status: ok ? 'pass' : 'fail', detail: ok ? 'OK' : 'video_feed missing' };
      }
    },
    {
      id: 'whatsapp-preview',
      label: 'WhatsApp numbers render in Footer',
      run: async () => {
        const n1 = `+1555${Math.floor(Math.random()*9000)+1000}`;
        const n2 = `+1666${Math.floor(Math.random()*9000)+1000}`;
        const ok1 = await tryUpdateAndVerify('whatsapp_enabled', true);
        const ok2 = await tryUpdateAndVerify('whatsapp_number1', n1);
        const ok3 = await tryUpdateAndVerify('whatsapp_number2', n2);
        setPreviewKey(k => k + 1);
        return { id: 'whatsapp-preview', label: 'WhatsApp numbers render in Footer', status: (ok1 && ok2 && ok3) ? 'pass' : 'fail', detail: (ok1 && ok2 && ok3) ? 'Numbers set' : 'Failed to save numbers' };
      }
    },
  ], []);

  const runAll = async () => {
    setRunning(true);
    const out: CheckResult[] = [];
    for (const c of checks) {
      try { out.push(await c.run()); }
      catch { out.push({ id: c.id, label: c.label, status: 'fail', detail: 'Exception' }); }
    }
    setResults(out);
    setRunning(false);
  };

  const passCount = results.filter(r => r.status === 'pass').length;

  async function runFrontendToggles() {
    setRunning(true);
    const subResults: CheckResult[] = [];
    const original = await fetchSiteSettings();
    // Helper to detect text presence in home preview
    const hasText = (text: string) => {
      const root = homeRef.current;
      if (!root) return false;
      const nodes = root.querySelectorAll('h2, h3, p, span, div');
      for (const n of Array.from(nodes)) {
        if ((n.textContent || '').toLowerCase().includes(text.toLowerCase())) return true;
      }
      return false;
    };

    // Featured products
    await tryUpdateAndVerify('show_featured_products', true);
    setHomeKey(k => k + 1); await sleep(800);
    subResults.push({ id:'feat-on', label:'Featured ON shows section', status: hasText('Featured Neon Signs') ? 'pass' : 'fail' });
    await tryUpdateAndVerify('show_featured_products', false);
    setHomeKey(k => k + 1); await sleep(800);
    subResults.push({ id:'feat-off', label:'Featured OFF hides section', status: hasText('Featured Neon Signs') ? 'fail' : 'pass' });

    // On Sale
    await tryUpdateAndVerify('show_on_sale_products', true);
    setHomeKey(k => k + 1); await sleep(800);
    subResults.push({ id:'sale-on', label:'On Sale ON shows section', status: hasText('Limited Time Offers') ? 'pass' : 'fail' });
    await tryUpdateAndVerify('show_on_sale_products', false);
    setHomeKey(k => k + 1); await sleep(800);
    subResults.push({ id:'sale-off', label:'On Sale OFF hides section', status: hasText('Limited Time Offers') ? 'fail' : 'pass' });

    // Testimonials
    await tryUpdateAndVerify('show_testimonials_section', true);
    setHomeKey(k => k + 1); await sleep(800);
    subResults.push({ id:'test-on', label:'Testimonials ON shows heading', status: hasText('What Our Customers Are Saying') ? 'pass' : 'fail' });
    await tryUpdateAndVerify('show_testimonials_section', false);
    setHomeKey(k => k + 1); await sleep(800);
    subResults.push({ id:'test-off', label:'Testimonials OFF hides heading', status: hasText('What Our Customers Are Saying') ? 'fail' : 'pass' });

    // Video Feed
    await tryUpdateAndVerify('video_feed_enabled', true);
    setHomeKey(k => k + 1); await sleep(1200); // allow query to run
    subResults.push({ id:'vid-on', label:'Video Feed ON shows heading', status: hasText('Latest Videos') ? 'pass' : 'fail' });
    await tryUpdateAndVerify('video_feed_enabled', false);
    setHomeKey(k => k + 1); await sleep(800);
    subResults.push({ id:'vid-off', label:'Video Feed OFF hides heading', status: hasText('Latest Videos') ? 'fail' : 'pass' });

    // Restore original values
    await tryUpdateAndVerify('show_featured_products', (original as any).show_featured_products !== false);
    await tryUpdateAndVerify('show_on_sale_products', (original as any).show_on_sale_products !== false);
    await tryUpdateAndVerify('show_testimonials_section', (original as any).show_testimonials_section !== false);
    await tryUpdateAndVerify('video_feed_enabled', !!(original as any).video_feed_enabled);
    setHomeKey(k => k + 1);

    setResults(prev => [
      ...prev.filter(r => !r.id.startsWith('feat-') && !r.id.startsWith('sale-') && !r.id.startsWith('test-') && !r.id.startsWith('vid-')),
      ...subResults
    ]);
    setRunning(false);
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Admin Diagnostics</CardTitle>
          <div className="flex gap-2">
            <Button onClick={runAll} disabled={running}>
              <RefreshCcw className="h-4 w-4 mr-2" /> Run All
            </Button>
            <Button variant="outline" onClick={runFrontendToggles} disabled={running}>
              <Eye className="h-4 w-4 mr-2" /> Run Frontend Toggles
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="text-sm mb-4">Passed {passCount}/{checks.length} checks</div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {results.map(r => (
              <div key={r.id} className={`rounded-md border p-3 flex items-center justify-between ${r.status === 'pass' ? 'border-green-600/40' : 'border-red-600/40'}`}>
                <div>
                  <div className="text-sm font-medium">{r.label}</div>
                  <div className="text-xs text-muted-foreground">{r.detail || ''}</div>
                </div>
                {r.status === 'pass' ? <CheckCircle2 className="text-green-600" /> : <XCircle className="text-red-600" />}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Live Preview: Home</CardTitle>
          <Eye className="h-4 w-4" />
        </CardHeader>
        <CardContent>
          <div ref={homeRef} key={homeKey} className="border rounded-md">
            <Index />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Live Preview: Footer</CardTitle>
          <Eye className="h-4 w-4" />
        </CardHeader>
        <CardContent>
          <div key={previewKey} className="border rounded-md">
            <Footer />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex items-center justify-between">
          <CardTitle>Security Snapshot</CardTitle>
          <ShieldCheck className="h-4 w-4" />
        </CardHeader>
        <CardContent className="text-sm text-muted-foreground">
          Admin route requires isAdmin or DB admin role via AuthContext; ensure Supabase RLS protects backing tables.
        </CardContent>
      </Card>
    </div>
  );
};

export default AdminDiagnostics;
