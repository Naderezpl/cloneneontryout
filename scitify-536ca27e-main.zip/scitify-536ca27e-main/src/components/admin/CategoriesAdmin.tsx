
import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/lib/supabase';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { useToast } from '@/components/ui/use-toast';
import { Edit2, Trash2, Plus, Eye, EyeOff } from 'lucide-react';
import CategoryForm, { CategoryFormData } from './CategoryForm';

const CategoriesAdmin = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [isDeleteOpen, setIsDeleteOpen] = useState(false);
  const [currentCategory, setCurrentCategory] = useState<CategoryFormData | null>(null);

  // Fetch categories
  const { data: categories = [], isLoading } = useQuery({
    queryKey: ['admin-categories'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('categories')
        .select('*')
        .order('position', { ascending: true });
        
      if (error) throw error;
      return data;
    }
  });

  // Save category mutation
  const saveMutation = useMutation({
    mutationFn: async (values: CategoryFormData) => {
      const isNew = !values.id;
      
      // Generate slug if not provided
      if (!values.slug) {
        values.slug = values.name.toLowerCase().replace(/\s+/g, '-');
      }
      
      if (isNew) {
        // For inserting a new category - remove id for new entries
        const { id, ...insertValues } = values;
        const { data, error } = await supabase
          .from('categories')
          .insert({
            name: insertValues.name,
            description: insertValues.description,
            slug: insertValues.slug,
            is_visible: insertValues.is_visible,
            position: insertValues.position,
            background_color: insertValues.background_color,
            text_color: insertValues.text_color,
            image_url: insertValues.image_url,
            created_at: new Date().toISOString()
          })
          .select()
          .maybeSingle();
        
        if (error) throw error;
        return data || values; // Return the input values if no data returned
      } else {
        // For updating an existing category
        const { data, error } = await supabase
          .from('categories')
          .update(values)
          .eq('id', values.id)
          .select()
          .maybeSingle();
        
        if (error) throw error;
        return data || values; // Return the input values if no data returned
      }
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['admin-categories'] });
      setIsFormOpen(false);
      toast({
        title: currentCategory?.id ? "Category Updated" : "Category Created",
        description: `${data.name} has been ${currentCategory?.id ? "updated" : "created"} successfully.`,
      });
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Error",
        description: `Failed to save category: ${error.message}`,
      });
    }
  });

  // Delete category mutation
  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const { data, error } = await supabase
        .from('categories')
        .delete()
        .eq('id', id)
        .select('id')
        .maybeSingle();
      
      if (error) throw error;
      if (!data) {
        throw new Error('Delete was blocked by permissions (no rows deleted).');
      }
      return id;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-categories'] });
      queryClient.refetchQueries({ queryKey: ['admin-categories'], type: 'active' });
      setIsDeleteOpen(false);
      toast({
        title: "Category Deleted",
        description: "The category has been deleted successfully.",
      });
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Error",
        description: `Failed to delete category: ${error.message}`,
      });
    }
  });

  const handleEdit = (category: CategoryFormData) => {
    setCurrentCategory(category);
    setIsFormOpen(true);
  };

  const handleNew = () => {
    setCurrentCategory(null);
    setIsFormOpen(true);
  };

  const handleDelete = (category: CategoryFormData) => {
    setCurrentCategory(category);
    setIsDeleteOpen(true);
  };

  const handleFormSubmit = (values: CategoryFormData) => {
    saveMutation.mutate(values);
  };

  if (isLoading) {
    return <div className="text-center py-8">Loading categories...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Manage Categories</h2>
        <Button onClick={handleNew}>
          <Plus className="mr-2 h-4 w-4" /> Add Category
        </Button>
      </div>

      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Image</TableHead>
            <TableHead>Name</TableHead>
            <TableHead>Position</TableHead>
            <TableHead>Visibility</TableHead>
            <TableHead>Slug</TableHead>
            <TableHead>Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {categories.map((category) => (
            <TableRow key={category.id}>
              <TableCell>
                {category.image_url && (
                  <img
                    src={category.image_url}
                    alt={category.name}
                    className="w-12 h-12 object-cover rounded"
                  />
                )}
              </TableCell>
              <TableCell>{category.name}</TableCell>
              <TableCell>{category.position}</TableCell>
              <TableCell>
                {category.is_visible ? (
                  <Eye className="h-4 w-4 text-green-500" />
                ) : (
                  <EyeOff className="h-4 w-4 text-red-500" />
                )}
              </TableCell>
              <TableCell className="font-mono text-sm">{category.slug}</TableCell>
              <TableCell>
                <div className="flex space-x-2">
                  <Button variant="outline" size="sm" onClick={() => handleEdit(category)}>
                    <Edit2 className="h-4 w-4" />
                  </Button>
                  <Button variant="destructive" size="sm" onClick={() => handleDelete(category)}>
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>

      <Dialog open={isFormOpen} onOpenChange={setIsFormOpen}>
        <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {currentCategory ? `Edit Category: ${currentCategory.name}` : 'Add New Category'}
            </DialogTitle>
          </DialogHeader>
          <CategoryForm
            initialData={currentCategory || undefined}
            onSubmit={handleFormSubmit}
            onCancel={() => setIsFormOpen(false)}
            isSubmitting={saveMutation.isPending}
          />
        </DialogContent>
      </Dialog>

      <AlertDialog open={isDeleteOpen} onOpenChange={setIsDeleteOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirm Deletion</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete the category "{currentCategory?.name}"?
              This action cannot be undone and may affect products using this category.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => currentCategory?.id && deleteMutation.mutate(currentCategory.id)}
              className="bg-red-600 hover:bg-red-700"
            >
              {deleteMutation.isPending ? 'Deleting...' : 'Delete Category'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default CategoriesAdmin;
