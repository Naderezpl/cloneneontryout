import React, { useState } from 'react';
import { Checkbox } from '@/components/ui/checkbox';
import { Button } from '@/components/ui/button';
import { Star, Trash2 } from 'lucide-react';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/components/ui/use-toast';
import { useQueryClient } from '@tanstack/react-query';
import ImageUploader from '@/components/ImageUploader';

interface ImageItem {
  id?: string;
  image_url: string;
  title?: string | null;
  position?: number | null;
  variant_id?: string | null;
}

interface ProductImageGalleryProps {
  images: ImageItem[];
  onImagesChange: (images: ImageItem[]) => void;
  onImageUploaded: (url: string) => void;
  thumbnailIndex: number;
  onThumbnailChange: (index: number) => void;
}

const ProductImageGallery: React.FC<ProductImageGalleryProps> = ({
  images,
  onImagesChange,
  onImageUploaded,
  thumbnailIndex,
  onThumbnailChange,
}) => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedIndices, setSelectedIndices] = useState<Set<number>>(new Set());
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);

  const allSelected = images.length > 0 && selectedIndices.size === images.length;

  const toggleSelect = (index: number) => {
    setSelectedIndices(prev => {
      const next = new Set(prev);
      if (next.has(index)) next.delete(index);
      else next.add(index);
      return next;
    });
  };

  const toggleSelectAll = () => {
    if (allSelected) {
      setSelectedIndices(new Set());
    } else {
      setSelectedIndices(new Set(images.map((_, i) => i)));
    }
  };

  const handleBulkDelete = async () => {
    setIsDeleting(true);
    try {
      const toDelete = Array.from(selectedIndices).sort((a, b) => b - a);
      const idsToDelete = toDelete
        .map(i => images[i]?.id)
        .filter(Boolean) as string[];

      if (idsToDelete.length > 0) {
        const { error } = await supabase
          .from('product_images')
          .delete()
          .in('id', idsToDelete);
        if (error) throw error;
      }

      const remaining = images.filter((_, i) => !selectedIndices.has(i));
      // Recalculate positions
      const updated = remaining.map((img, i) => ({ ...img, position: i }));
      onImagesChange(updated);

      // Adjust thumbnail
      if (selectedIndices.has(thumbnailIndex)) {
        onThumbnailChange(0);
      } else {
        const newIdx = updated.findIndex(img => img.id === images[thumbnailIndex]?.id);
        onThumbnailChange(newIdx >= 0 ? newIdx : 0);
      }

      setSelectedIndices(new Set());
      queryClient.invalidateQueries({ queryKey: ['admin-products'] });
      toast({ title: 'Images Deleted', description: `${toDelete.length} image(s) removed.` });
    } catch (err: any) {
      toast({ variant: 'destructive', title: 'Delete Failed', description: err.message });
    } finally {
      setIsDeleting(false);
      setShowDeleteConfirm(false);
    }
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <span className="text-sm font-medium">Product Images</span>
        {images.length > 0 && (
          <label className="flex items-center gap-2 text-sm cursor-pointer">
            <Checkbox
              checked={allSelected}
              onCheckedChange={toggleSelectAll}
            />
            Select All
          </label>
        )}
      </div>

      {selectedIndices.size > 0 && (
        <Button
          type="button"
          variant="destructive"
          size="sm"
          onClick={() => setShowDeleteConfirm(true)}
        >
          <Trash2 className="h-4 w-4 mr-1" />
          Delete Selected ({selectedIndices.size})
        </Button>
      )}

      <div className="grid grid-cols-4 gap-3">
        {images.map((img, idx) => {
          const isThumbnail = idx === thumbnailIndex;
          const isSelected = selectedIndices.has(idx);

          return (
            <div
              key={img.id || idx}
              className={`relative group rounded-lg overflow-hidden border-2 transition-all ${
                isThumbnail
                  ? 'border-amber-500 shadow-md shadow-amber-500/20'
                  : isSelected
                  ? 'border-primary'
                  : 'border-transparent hover:border-muted-foreground/30'
              }`}
            >
              <img
                src={img.image_url}
                alt={`Product ${idx}`}
                className="w-full aspect-square object-cover"
              />

              {/* Checkbox overlay */}
              <div className="absolute top-1.5 left-1.5 z-10">
                <Checkbox
                  checked={isSelected}
                  onCheckedChange={() => toggleSelect(idx)}
                  className="bg-background/80 backdrop-blur-sm"
                />
              </div>

              {/* Thumbnail star button */}
              <button
                type="button"
                onClick={() => onThumbnailChange(idx)}
                className={`absolute bottom-1.5 right-1.5 z-10 p-1 rounded-full transition-all ${
                  isThumbnail
                    ? 'bg-amber-500 text-white'
                    : 'bg-background/80 backdrop-blur-sm text-muted-foreground hover:text-amber-500'
                }`}
                title={isThumbnail ? 'Primary thumbnail' : 'Set as thumbnail'}
              >
                <Star className={`h-4 w-4 ${isThumbnail ? 'fill-current' : ''}`} />
              </button>

              {isThumbnail && (
                <div className="absolute top-1.5 right-1.5 bg-amber-500 text-white text-[10px] font-bold px-1.5 py-0.5 rounded">
                  THUMB
                </div>
              )}
            </div>
          );
        })}
      </div>

      <ImageUploader
        onImageUploaded={onImageUploaded}
        bucketName="imageassets"
        folderPath="products"
        aspectRatio={1}
        uploadId="product-image-upload"
        recommendedSize="1000 × 1000 px"
      />

      <AlertDialog open={showDeleteConfirm} onOpenChange={setShowDeleteConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete {selectedIndices.size} Image(s)?</AlertDialogTitle>
            <AlertDialogDescription className="text-center">
              This will permanently remove the selected images from the product. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isDeleting}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleBulkDelete}
              disabled={isDeleting}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {isDeleting ? 'Deleting...' : 'Delete'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default ProductImageGallery;
