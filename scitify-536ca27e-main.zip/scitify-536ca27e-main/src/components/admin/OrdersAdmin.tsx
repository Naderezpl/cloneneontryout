
import React, { useState, useEffect } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/lib/supabase';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle 
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Eye, Mail, Save, Download, Printer } from 'lucide-react';
import { formatVariant, downloadOrderPdf, printOrderPdf } from '@/utils/orderPdf';

import { useToast } from '@/components/ui/use-toast';
import { Input } from '@/components/ui/input';
import { 
  Form, 
  FormControl, 
  FormField, 
  FormItem, 
  FormLabel,
  FormDescription 
} from '@/components/ui/form';
import { Switch } from '@/components/ui/switch';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useAuth } from '@/contexts/AuthContext';
import { updateSiteSettings } from '@/api/settings';

// Define schemas and types
const emailFormSchema = z.object({
  orderNotificationEmail: z.string().email({ message: "Please enter a valid email address" }),
  storeEmail: z.string().email({ message: "Please enter a valid store email" }),
  orderEmailEnabled: z.boolean().default(true),
});

type Order = {
  id: string;
  user_id: string;
  total_price: number;
  status: string;
  created_at: string;
  user_email?: string;
  user_name?: string;
  customer_name?: string | null;
  customer_email?: string | null;
  customer_phone?: string | null;
  shipping_address?: string | null;
  notes?: string | null;
  delivery_fee?: number | null;
  payment_method?: string | null;
  is_paid?: boolean | null;
  paid_at?: string | null;
};

const PAYMENT_LABELS: Record<string, string> = {
  'whish-money': 'Whish Money',
  omt: 'OMT',
  cod: 'Cash On Delivery (COD)',
  'crypto-usdt': 'Crypto (USDT)',
};

type OrderItem = {
  id: string;
  order_id: string;
  product_id: string;
  quantity: number;
  price: number;
  variant_data?: any;
  product_name?: string;
  product_image?: string;
};

type EmailLog = {
  id: string;
  type: 'order_email_error' | 'order_email_sent';
  message: string;
  order_id: string | null;
  created_at: string;
};

const OrdersAdmin = () => {
  const [isDetailsOpen, setIsDetailsOpen] = useState(false);
  const [isEmailSettingsOpen, setIsEmailSettingsOpen] = useState(false);
  const [currentOrder, setCurrentOrder] = useState<Order | null>(null);
  const [orderItems, setOrderItems] = useState<OrderItem[]>([]);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { isAdmin, hasDbAdminRole } = useAuth();
  const canEdit = isAdmin || hasDbAdminRole;
  const envUrl = (import.meta as any)?.env?.VITE_SUPABASE_URL as string | undefined;
  const envKey = (import.meta as any)?.env?.VITE_SUPABASE_PUBLISHABLE_KEY as string | undefined;
  const envProject = (import.meta as any)?.env?.VITE_SUPABASE_PROJECT_ID as string | undefined;
  const computedUrl = envUrl || (envProject ? `https://${envProject}.supabase.co` : '');
  const [urlOverride, setUrlOverride] = useState<string>(() => {
    try { return localStorage.getItem('supabaseUrlOverride') || ''; } catch { return ''; }
  });
  const [keyOverride, setKeyOverride] = useState<string>(() => {
    try { return localStorage.getItem('supabaseAnonKeyOverride') || ''; } catch { return ''; }
  });
  const saveOverrides = () => {
    try { localStorage.setItem('supabaseUrlOverride', urlOverride); } catch {}
    try { localStorage.setItem('supabaseAnonKeyOverride', keyOverride); } catch {}
    toast({ title: 'Connection Overrides Saved', description: 'Overrides will be used for connectivity and test calls' });
  };

  // Initialize form for email settings
  const form = useForm<z.infer<typeof emailFormSchema>>({
    resolver: zodResolver(emailFormSchema),
    defaultValues: {
      orderNotificationEmail: '',
      storeEmail: '',
      orderEmailEnabled: true,
    },
  });

  // Fetch notification email on component mount
  useEffect(() => {
    const fetchEmailSetting = async () => {
      const { data, error } = await supabase
        .from('site_settings')
        .select('order_notification_email, order_email_enabled, store_email, contact_email')
        .order('id', { ascending: false })
        .limit(1)
        .maybeSingle();
      
      if (!error && data) {
        form.setValue('orderNotificationEmail', (data as any)?.order_notification_email || '');
        form.setValue('orderEmailEnabled', Boolean((data as any)?.order_email_enabled ?? true));
        form.setValue('storeEmail', (data as any)?.store_email || (data as any)?.contact_email || '');
      } else {
        try {
          const ls = localStorage.getItem('orderNotificationEmail');
          if (ls) form.setValue('orderNotificationEmail', ls);
          const lsStore = localStorage.getItem('storeEmail');
          if (lsStore) form.setValue('storeEmail', lsStore);
        } catch {}
      }
    };
    
    fetchEmailSetting();
  }, [form]);

  // Fetch orders query
  const { data: orders = [], isLoading, refetch } = useQuery({
    queryKey: ['admin-orders'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('orders')
        .select('*')
        .order('created_at', { ascending: false });
        
      if (error) throw error;
      
      return data.map(order => ({
        ...order,
        user_email: order.customer_email || 'Unknown'
      })) as Order[];
    }
  });

  // Fetch recent email logs
  const { data: emailLogs = [], refetch: refetchEmailLogs } = useQuery({
    queryKey: ['email-logs'],
    queryFn: async (): Promise<EmailLog[]> => {
      const { data, error } = await supabase
        .from('notifications')
        .select('id, type, message, order_id, created_at')
        .in('type', ['order_email_error', 'order_email_sent'])
        .order('created_at', { ascending: false })
        .limit(10);
      if (error) throw error;
      return (data || []) as EmailLog[];
    }
  });

  // Fetch order items for a specific order
  const fetchOrderItems = async (orderId: string) => {
    const { data: orderItems, error } = await supabase
      .from('order_items')
      .select('*')
      .eq('order_id', orderId);
    
    if (error) throw error;
    
    // Fetch product details separately
    const productIds = orderItems?.map(item => item.product_id).filter(Boolean) || [];
    const { data: products } = await supabase
      .from('products')
      .select('id, name')
      .in('id', productIds);
    
    const { data: productImages } = await supabase
      .from('product_images')
      .select('product_id, image_url')
      .in('product_id', productIds);
    
    return (orderItems || []).map(item => {
      const product = products?.find(p => p.id === item.product_id);
      const image = productImages?.find(img => img.product_id === item.product_id);
      return {
        ...item,
        product_name: product?.name,
        product_image: image?.image_url
      };
    }) as OrderItem[];
  };

  // Company info for PDF receipts
  const { data: companyInfo } = useQuery({
    queryKey: ['pdf-company-info'],
    queryFn: async () => {
      const { data } = await supabase
        .from('site_settings')
        .select('company_name, logo_url, contact_email, contact_phone, contact_address, currency')
        .order('id', { ascending: false })
        .limit(1)
        .maybeSingle();
      return {
        name: (data as any)?.company_name,
        logoUrl: (data as any)?.logo_url,
        email: (data as any)?.contact_email,
        phone: (data as any)?.contact_phone,
        address: (data as any)?.contact_address,
        currency: (data as any)?.currency || '$',
      };
    }
  });

  const handleDownloadPdf = async () => {
    if (!currentOrder) return;
    try {
      await downloadOrderPdf(currentOrder as any, orderItems as any, companyInfo || {});
    } catch (e) {
      console.error('PDF download failed:', e);
      toast({ variant: 'destructive', title: 'PDF Error', description: 'Could not generate the PDF.' });
    }
  };

  const handlePrintPdf = async () => {
    if (!currentOrder) return;
    try {
      await printOrderPdf(currentOrder as any, orderItems as any, companyInfo || {});
    } catch (e) {
      console.error('PDF print failed:', e);
      toast({ variant: 'destructive', title: 'PDF Error', description: 'Could not open the print preview.' });
    }
  };

  // View order details
  const handleViewDetails = async (order: Order) => {

    setCurrentOrder(order);
    try {
      const items = await fetchOrderItems(order.id);
      setOrderItems(items);
      setIsDetailsOpen(true);
    } catch (error) {
      console.error('Error fetching order items:', error);
      toast({
        variant: 'destructive',
        title: 'Error',
        description: 'Failed to fetch order details'
      });
    }
  };

  // Toggle payment status
  const handlePaidChange = async (order: Order, paid: boolean) => {
    if (!canEdit) {
      toast({
        variant: 'destructive',
        title: 'Insufficient Permissions',
        description: 'Updating orders requires admin privileges.'
      });
      return;
    }
    try {
      const paidAt = paid ? new Date().toISOString() : null;
      const { error } = await supabase
        .from('orders')
        .update({ is_paid: paid, paid_at: paidAt })
        .eq('id', order.id);
      if (error) throw error;

      setCurrentOrder(prev => (prev && prev.id === order.id ? { ...prev, is_paid: paid, paid_at: paidAt } : prev));
      queryClient.invalidateQueries({ queryKey: ['admin-orders'] });
      queryClient.refetchQueries({ queryKey: ['admin-orders'], type: 'active' });
      toast({ title: paid ? 'Marked as paid' : 'Marked as unpaid' });
    } catch (e) {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: e instanceof Error ? e.message : 'Failed to update payment status'
      });
    }
  };

  // Update order status
  const handleStatusChange = async (status: string) => {
    if (!currentOrder) return;
    if (!canEdit) {
      toast({
        variant: 'destructive',
        title: 'Insufficient Permissions',
        description: 'Updating orders requires admin privileges.'
      });
      return;
    }
    
    try {
      const { data: updatedOrder, error } = await supabase
        .from('orders')
        .update({ 
          status
        })
        .eq('id', currentOrder.id)
        .select('id, status')
        .maybeSingle();
      
      if (error) throw error;
      if (!updatedOrder) {
        throw new Error('Update was blocked by permissions (no rows updated).');
      }
      
      // Update local state and refetch
      setCurrentOrder(prev => prev ? { ...prev, status } : null);
      queryClient.invalidateQueries({ queryKey: ['admin-orders'] });
      queryClient.refetchQueries({ queryKey: ['admin-orders'], type: 'active' });
      
      toast({
        title: 'Order Updated',
        description: `Order status changed to ${status}`
      });
      
      // Trigger email notification for status change
      if (status === 'shipped' || status === 'delivered') {
        try {
          const { error: fnError } = await supabase.functions.invoke('send-order-notification', {
            body: {
              orderId: currentOrder.id,
              statusUpdate: true,
              newStatus: status,
            }
          });
          if (fnError) throw fnError;
        } catch (emailError) {
          console.error('Error sending status update email:', emailError);
          // Don't show an error toast since the status update succeeded
        }
      }
    } catch (error) {
      console.error('Error updating order status:', error);
      toast({
        variant: 'destructive',
        title: 'Update Failed',
        description: `Could not update order status${error instanceof Error ? `: ${error.message}` : ''}`
      });
    }
  };

  // Save email notification settings
  const handleSaveEmail = async (values: z.infer<typeof emailFormSchema>) => {
    try {
      await updateSiteSettings({
        order_notification_email: values.orderNotificationEmail,
        store_email: values.storeEmail,
        order_email_enabled: values.orderEmailEnabled,
      });
      queryClient.invalidateQueries({ queryKey: ['site-settings'] });
      try { localStorage.setItem('orderNotificationEmail', values.orderNotificationEmail); } catch {}
      try { localStorage.setItem('storeEmail', values.storeEmail); } catch {}
      
      toast({
        title: 'Email Updated',
        description: 'Order notification email has been saved'
      });
      
      setIsEmailSettingsOpen(false);
      refetchEmailLogs();
    } catch (error) {
      try {
        const { error: fnError } = await supabase.functions.invoke('update-site-settings', {
          body: {
            order_notification_email: values.orderNotificationEmail,
            store_email: values.storeEmail,
            order_email_enabled: values.orderEmailEnabled
          }
        });
        if (fnError) throw fnError;
        queryClient.invalidateQueries({ queryKey: ['site-settings'] });
        try { localStorage.setItem('orderNotificationEmail', values.orderNotificationEmail); } catch {}
        try { localStorage.setItem('storeEmail', values.storeEmail); } catch {}
        toast({
          title: 'Email Updated',
          description: 'Order notification email has been saved'
        });
        setIsEmailSettingsOpen(false);
        refetchEmailLogs();
      } catch (e) {
        console.error('Error saving email:', e);
        try { localStorage.setItem('orderNotificationEmail', values.orderNotificationEmail); } catch {}
        toast({
          title: 'Saved Locally',
          description: 'Using your email for notifications until server settings are available'
        });
        setIsEmailSettingsOpen(false);
      }
    }
  };

  // Test sending an email notification
  const handleTestEmail = async () => {
    if (!form.getValues().orderNotificationEmail) {
      toast({
        variant: 'destructive',
        title: 'No Email Configured',
        description: 'Please save an email address first'
      });
      return;
    }

    try {
      const { data, error } = await supabase.functions.invoke('send-order-notification', {
        body: {
          testEmail: true,
          emailAddress: form.getValues().orderNotificationEmail
        }
      });
      if (error || (data && (data as any)?.error)) {
        const msg = (data as any)?.error || (error as any)?.message || 'Unknown error';
        const detail = (data as any)?.details ? ` (${String((data as any).details)})` : '';
        if (String(msg).includes('CONFIG_MISSING')) {
          throw new Error('Email provider not configured on server' + detail);
        }
        throw new Error(String(msg) + detail);
      }

      toast({
        title: 'Test Email Sent',
        description: 'A test notification email has been sent to the configured address'
      });
      refetchEmailLogs();
    } catch (error) {
      try {
        let url = urlOverride || ((import.meta as any)?.env?.VITE_SUPABASE_URL as string | undefined);
        const key = keyOverride || ((import.meta as any)?.env?.VITE_SUPABASE_PUBLISHABLE_KEY as string | undefined);
        const projectId = (import.meta as any)?.env?.VITE_SUPABASE_PROJECT_ID as string | undefined;
        if (!url && projectId) {
          url = `https://${projectId}.supabase.co`;
        }
        if (url && /supabase\.com\/dashboard/i.test(url)) {
          if (projectId) {
            url = `https://${projectId}.supabase.co`;
          } else {
            throw new Error('Supabase URL points to dashboard. Set VITE_SUPABASE_URL=https://<project>.supabase.co');
          }
        }
        if (!url || !key) {
          throw new Error('Missing VITE_SUPABASE_URL or VITE_SUPABASE_PUBLISHABLE_KEY');
        }
        const resp = await fetch(`${url.replace(/\/+$/, '')}/functions/v1/send-order-notification`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${key}`,
            'apikey': key,
          },
          body: JSON.stringify({ testEmail: true, emailAddress: form.getValues().orderNotificationEmail }),
        });
        const json = await resp.json().catch(() => ({}));
        if (!resp.ok || (json && (json as any)?.error)) {
          const msg = (json as any)?.error || `HTTP ${resp.status}`;
          const details = (json as any)?.details ? ` (${String((json as any).details)})` : '';
          throw new Error(String(msg) + details);
        }
        toast({
          title: 'Test Email Sent',
          description: 'A test notification email has been sent to the configured address'
        });
      } catch (fallbackErr) {
        console.error('Direct function request failed:', fallbackErr);
        toast({
          variant: 'destructive',
          title: 'Edge Function Unreachable',
          description: fallbackErr instanceof Error ? fallbackErr.message : 'Failed to request edge function'
        });
      } finally {
        refetchEmailLogs();
      }
    }
  };

  const handleCheckConnectivity = async () => {
    try {
      let url = urlOverride || ((import.meta as any)?.env?.VITE_SUPABASE_URL as string | undefined);
      const projectId = (import.meta as any)?.env?.VITE_SUPABASE_PROJECT_ID as string | undefined;
      if (!url && projectId) {
        url = `https://${projectId}.supabase.co`;
      }
      if (url && /supabase\.com\/dashboard/i.test(url)) {
        if (projectId) {
          url = `https://${projectId}.supabase.co`;
        } else {
          throw new Error('Supabase URL points to dashboard. Set VITE_SUPABASE_URL=https://<project>.supabase.co');
        }
      }
      if (!url) {
        throw new Error('Missing VITE_SUPABASE_URL (or VITE_SUPABASE_PROJECT_ID)');
      }
      const resp = await fetch(`${url.replace(/\/+$/, '')}/functions/v1/send-order-notification?diag=1`, {
        method: 'GET',
        headers: { 'Content-Type': 'application/json' },
      });
      const json: any = await resp.json().catch(() => ({}));
      if (!resp.ok) {
        throw new Error(`HTTP ${resp.status}`);
      }
      const parts = [
        `Endpoint: ${json?.endpoint || 'unknown'}`,
        `Supabase URL: ${json?.env?.supabaseUrl ? 'OK' : 'Missing'}`,
        `Service Role: ${json?.env?.serviceRole ? 'OK' : 'Missing'}`,
        `Resend Key: ${json?.env?.resendKey ? 'OK' : 'Missing'}`,
        `Resend From: ${json?.env?.resendFrom ? 'OK' : 'Missing'}`,
        `DB: ${json?.db?.ok ? 'OK' : `Error: ${json?.db?.error || 'unknown'}`}`,
      ].join(' • ');
      toast({ title: 'Function Reachable', description: parts });
    } catch (e) {
      console.error('Connectivity check failed:', e);
      toast({
        variant: 'destructive',
        title: 'Connectivity Failed',
        description: e instanceof Error ? e.message : 'Could not reach edge function'
      });
    }
  };

  // Render methods
  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case 'pending': return 'default';
      case 'processing': return 'secondary';
      case 'shipped': return 'outline';
      case 'delivered': return 'secondary';
      case 'cancelled': return 'destructive';
      default: return 'default';
    }
  };

  if (isLoading) return <div className="text-center py-8">Loading orders...</div>;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Order Management</h2>
        <Button 
          variant="outline" 
          onClick={() => setIsEmailSettingsOpen(true)}
          className="flex items-center gap-2"
        >
          <Mail className="h-4 w-4" />
          Notification Settings
        </Button>
      </div>

      {/* Orders Table */}
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Order ID</TableHead>
            <TableHead>Customer</TableHead>
            <TableHead>Date</TableHead>
            <TableHead>Total</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Payment</TableHead>
            <TableHead>Paid</TableHead>
            <TableHead>Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {orders.map((order) => (
            <TableRow key={order.id}>
              <TableCell>#{order.id.slice(-6)}</TableCell>
              <TableCell>{order.user_email || 'Unknown'}</TableCell>
              <TableCell>{new Date(order.created_at).toLocaleDateString()}</TableCell>
              <TableCell>${order.total_price?.toFixed(2)}</TableCell>
              <TableCell>
                <Badge variant={getStatusBadgeVariant(order.status)}>
                  {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                </Badge>
              </TableCell>
              <TableCell className="text-sm text-muted-foreground">
                {PAYMENT_LABELS[order.payment_method || ''] || order.payment_method || '—'}
              </TableCell>
              <TableCell>
                <div className="flex items-center gap-2">
                  <Switch
                    checked={!!order.is_paid}
                    disabled={!canEdit}
                    onCheckedChange={(checked) => handlePaidChange(order, checked)}
                  />
                  <Badge variant={order.is_paid ? 'default' : 'destructive'}>
                    {order.is_paid ? 'Paid' : 'Unpaid'}
                  </Badge>
                </div>
              </TableCell>
              <TableCell>
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={() => handleViewDetails(order)}
                >
                  <Eye className="h-4 w-4 mr-2" /> Details
                </Button>
              </TableCell>

            </TableRow>
          ))}
          {orders.length === 0 && (
            <TableRow>
              <TableCell colSpan={8} className="text-center py-4">
                No orders found
              </TableCell>
            </TableRow>
          )}
        </TableBody>
      </Table>

      {/* Order Details Dialog */}
      <Dialog open={isDetailsOpen} onOpenChange={setIsDetailsOpen}>
        <DialogContent className="sm:max-w-[800px] max-h-[90vh] overflow-y-auto">
          {currentOrder && (
            <div className="space-y-6">
              <DialogHeader>
                <DialogTitle>Order #{currentOrder.id.slice(-6).toUpperCase()}</DialogTitle>
              </DialogHeader>

              <div className="flex flex-wrap gap-2">
                <Button variant="outline" size="sm" onClick={handleDownloadPdf}>
                  <Download className="h-4 w-4 mr-2" /> Download PDF
                </Button>
                <Button variant="outline" size="sm" onClick={handlePrintPdf}>
                  <Printer className="h-4 w-4 mr-2" /> Print PDF
                </Button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-1">
                  <h3 className="font-semibold">Customer Information</h3>
                  <p className="text-sm">{currentOrder.customer_name || currentOrder.user_name || 'N/A'}</p>
                  <p className="text-sm text-muted-foreground">
                    {currentOrder.customer_email || currentOrder.user_email || 'N/A'}
                  </p>
                  <p className="text-sm text-muted-foreground">{currentOrder.customer_phone || 'No phone'}</p>
                </div>
                <div className="space-y-1">
                  <h3 className="font-semibold">Delivery Details</h3>
                  <p className="text-sm whitespace-pre-line">
                    {currentOrder.shipping_address || 'No shipping address provided'}
                  </p>
                </div>
                <div className="space-y-1">
                  <h3 className="font-semibold">Payment Information</h3>
                  <p className="text-sm text-muted-foreground">
                    Method: {PAYMENT_LABELS[currentOrder.payment_method || ''] || currentOrder.payment_method || '—'}
                  </p>
                  <div className="flex items-center gap-2 py-1">
                    <Switch
                      checked={!!currentOrder.is_paid}
                      disabled={!canEdit}
                      onCheckedChange={(checked) => handlePaidChange(currentOrder, checked)}
                    />
                    <Badge variant={currentOrder.is_paid ? 'default' : 'destructive'}>
                      {currentOrder.is_paid ? 'Paid' : 'Unpaid'}
                    </Badge>
                  </div>
                  {currentOrder.is_paid && currentOrder.paid_at && (
                    <p className="text-xs text-muted-foreground">
                      Paid on {new Date(currentOrder.paid_at).toLocaleString()}
                    </p>
                  )}
                  {!currentOrder.is_paid && (currentOrder.payment_method || 'cod') !== 'cod' && (
                    <p className="text-xs text-destructive">
                      Unpaid orders are deleted automatically 7 days after the order date.
                    </p>
                  )}
                  <p className="text-sm text-muted-foreground">
                    Grand total: ${Number(currentOrder.total_price || 0).toFixed(2)}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    Delivery fee: ${Number(currentOrder.delivery_fee || 0).toFixed(2)}
                  </p>
                </div>

                <div className="space-y-1">
                  <h3 className="font-semibold">Date &amp; Time</h3>
                  <p className="text-sm text-muted-foreground">
                    {new Date(currentOrder.created_at).toLocaleString()}
                  </p>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <p className="text-sm font-semibold">Order Status</p>
                <Select 
                  value={currentOrder.status} 
                  onValueChange={handleStatusChange}
                >
                  <SelectTrigger className="w-[180px]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="processing">Processing</SelectItem>
                    <SelectItem value="shipped">Shipped</SelectItem>
                    <SelectItem value="delivered">Delivered</SelectItem>
                    <SelectItem value="cancelled">Cancelled</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <h3 className="text-lg font-semibold mb-2">Purchased Products</h3>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Product</TableHead>
                      <TableHead>Options</TableHead>
                      <TableHead>Qty</TableHead>
                      <TableHead>Unit Price</TableHead>
                      <TableHead>Total</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {orderItems.map((item) => (
                      <TableRow key={item.id}>
                        <TableCell>
                          <div className="flex items-center">
                            {item.product_image && (
                              <img 
                                src={item.product_image} 
                                alt={item.product_name || 'Product'} 
                                className="w-10 h-10 object-cover rounded mr-2"
                              />
                            )}
                            {item.product_name || 'Unknown Product'}
                          </div>
                        </TableCell>
                        <TableCell className="text-sm text-muted-foreground">
                          {formatVariant(item.variant_data) || '—'}
                        </TableCell>
                        <TableCell>{item.quantity}</TableCell>
                        <TableCell>${item.price.toFixed(2)}</TableCell>
                        <TableCell>${(item.price * item.quantity).toFixed(2)}</TableCell>
                      </TableRow>
                    ))}
                    {orderItems.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={5} className="text-center py-4">No items found</TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>

              {currentOrder.notes && (
                <div>
                  <h3 className="font-semibold mb-1">Order Notes</h3>
                  <p className="text-sm whitespace-pre-line text-muted-foreground">{currentOrder.notes}</p>
                </div>
              )}
              
              <div className="text-right space-y-1">
                <p className="text-sm text-muted-foreground">
                  Subtotal: ${orderItems.reduce((s, i) => s + i.price * i.quantity, 0).toFixed(2)}
                </p>
                <p className="text-sm text-muted-foreground">
                  Delivery Fee: ${Number(currentOrder.delivery_fee || 0).toFixed(2)}
                </p>
                <p className="text-xl font-bold">
                  Grand Total: ${Number(currentOrder.total_price || 0).toFixed(2)}
                </p>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Email Notification Settings Dialog */}
      <Dialog open={isEmailSettingsOpen} onOpenChange={setIsEmailSettingsOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Order Notification Settings</DialogTitle>
          </DialogHeader>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(handleSaveEmail)} className="space-y-6">
              <FormField
                control={form.control}
                name="orderEmailEnabled"
                render={({ field }) => (
                  <FormItem className="flex items-center justify-between rounded border p-3">
                    <div>
                      <FormLabel>Enable Order Email Notifications</FormLabel>
                      <FormDescription>Automatically email order details to the store owner</FormDescription>
                    </div>
                    <FormControl>
                      <Switch checked={field.value} onCheckedChange={field.onChange} />
                    </FormControl>
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="storeEmail"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Store Email (Sender)</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter store email (sender)" {...field} />
                    </FormControl>
                    <FormDescription>
                      Emails will be sent FROM this address to your notification email
                    </FormDescription>
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="orderNotificationEmail"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Notification Email</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter email for order notifications" {...field} />
                    </FormControl>
                    <FormDescription>
                      All order details will be sent to this email address
                    </FormDescription>
                  </FormItem>
                )}
              />
              
              <div className="flex gap-2">
                <Button type="submit" className="flex-1">
                  <Save className="h-4 w-4 mr-2" /> Save Settings
                </Button>
                <Button type="button" variant="outline" onClick={handleTestEmail}>
                  Test Email
                </Button>
                <Button type="button" variant="outline" onClick={handleCheckConnectivity}>
                  Check Connectivity
                </Button>
              </div>

              <div className="pt-4 border-t space-y-2">
                <h4 className="font-semibold">Environment Diagnostics</h4>
                <p className="text-sm text-muted-foreground">
                  Supabase URL: {computedUrl || 'Missing'}
                </p>
                <p className="text-sm text-muted-foreground">
                  Publishable Key: {envKey ? 'Present' : 'Missing'}
                </p>
                <p className="text-sm text-muted-foreground">
                  Project ID: {envProject || 'Missing'}
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2 pt-2">
                  <div>
                    <Input
                      placeholder="Override Supabase URL (optional)"
                      value={urlOverride}
                      onChange={(e) => setUrlOverride(e.target.value)}
                    />
                  </div>
                  <div>
                    <Input
                      placeholder="Override Publishable Key (optional)"
                      value={keyOverride}
                      onChange={(e) => setKeyOverride(e.target.value)}
                    />
                  </div>
                  <div className="md:col-span-2">
                    <Button type="button" variant="secondary" onClick={saveOverrides}>
                      Save Connection Overrides
                    </Button>
                  </div>
                </div>
              </div>

              <div className="pt-4 border-t">
                <h4 className="font-semibold mb-2">Recent Email Activity</h4>
                <div className="space-y-1 max-h-48 overflow-auto">
                  {emailLogs.length === 0 && (
                    <p className="text-sm text-muted-foreground">No recent email activity</p>
                  )}
                  {emailLogs.map((log) => (
                    <div key={log.id} className="text-sm">
                      <span className={log.type === 'order_email_error' ? 'text-red-600' : 'text-green-600'}>
                        {log.type === 'order_email_error' ? 'Error' : 'Sent'}
                      </span>
                      {' · '}
                      <span>Order {log.order_id ? `#${log.order_id.slice(-6)}` : '-'}</span>
                      {' · '}
                      <span>{new Date(log.created_at).toLocaleString()}</span>
                      {' · '}
                      <span className="text-muted-foreground">{log.message}</span>
                    </div>
                  ))}
                </div>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default OrdersAdmin;
