import React, { useState, useRef, useCallback, useMemo } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/lib/supabase';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/components/ui/use-toast';
import { Save, GripVertical, Loader2, RotateCcw, ChevronUp, ChevronDown } from 'lucide-react';
import { fetchSiteSettings } from '@/api/settings';

interface SectionItem {
  key: string;
  label: string;
}

const SECTION_DEFAULTS: Record<string, string> = {
  hero: 'Hero Slider',
  categories: 'Collections',
  highlights: 'Store Highlights',
  featured: 'Best Sellers',
  onsale: 'Limited Time Offers',
  about: 'About Us',
  testimonials: 'Testimonials',
  reviews: 'Reviews',
  promotions: 'Promotions',
  newsletter: 'Email Subscription',
};

const DEFAULT_ORDER = ['hero', 'categories', 'highlights', 'featured', 'onsale', 'about', 'testimonials', 'reviews', 'promotions', 'newsletter'];

const HomepageLayoutAdmin = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [dragIndex, setDragIndex] = useState<number | null>(null);
  const [overIndex, setOverIndex] = useState<number | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const dragNode = useRef<HTMLDivElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  // Touch drag state
  const touchStartY = useRef<number>(0);
  const touchCurrentIdx = useRef<number | null>(null);
  const itemRects = useRef<DOMRect[]>([]);

  const { data: settings } = useQuery({
    queryKey: ['site-settings'],
    queryFn: fetchSiteSettings,
    staleTime: 0,
  });

  // Build dynamic label map from site settings
  const sectionMap = useMemo(() => {
    const map: Record<string, SectionItem> = {};
    for (const key of Object.keys(SECTION_DEFAULTS)) {
      let label = SECTION_DEFAULTS[key];
      if (settings) {
        if (key === 'featured' && settings.featured_products_title) label = settings.featured_products_title;
        else if (key === 'onsale' && settings.on_sale_products_title) label = settings.on_sale_products_title;
        else if (key === 'about' && settings.about_section_title) label = settings.about_section_title;
        else if (key === 'hero' && settings.site_title) label = `Hero — ${settings.site_title}`;
      }
      map[key] = { key, label };
    }
    return map;
  }, [settings]);

  const { data: order = DEFAULT_ORDER, isLoading } = useQuery({
    queryKey: ['homepage-section-order'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('site_settings')
        .select('homepage_section_order')
        .order('id', { ascending: false })
        .limit(1)
        .maybeSingle();
      if (error) throw error;
      const saved = data?.homepage_section_order as string[] | null;
      if (!saved || !Array.isArray(saved)) return DEFAULT_ORDER;
      const missing = DEFAULT_ORDER.filter(k => !saved.includes(k));
      return [...saved, ...missing];
    },
  });

  const [localOrder, setLocalOrder] = useState<string[] | null>(null);
  const currentOrder = localOrder ?? order;

  React.useEffect(() => {
    if (order) setLocalOrder(order);
  }, [order]);

  const saveMutation = useMutation({
    mutationFn: async (newOrder: string[]) => {
      const { data: existing } = await supabase
        .from('site_settings')
        .select('id')
        .order('id', { ascending: false })
        .limit(1)
        .maybeSingle();
      if (!existing) throw new Error('No settings row');
      const { error } = await supabase
        .from('site_settings')
        .update({ homepage_section_order: newOrder, updated_at: new Date().toISOString() })
        .eq('id', existing.id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['homepage-section-order'] });
      queryClient.invalidateQueries({ queryKey: ['site-settings'] });
      toast({ title: 'Layout saved', description: 'Homepage section order updated.' });
    },
    onError: () => {
      toast({ variant: 'destructive', title: 'Error', description: 'Failed to save layout order.' });
    },
  });

  const moveItem = useCallback((from: number, to: number) => {
    if (from === to) return;
    setLocalOrder(prev => {
      const items = [...(prev ?? currentOrder)];
      const [moved] = items.splice(from, 1);
      items.splice(to, 0, moved);
      return items;
    });
  }, [currentOrder]);

  // --- Native drag handlers ---
  const handleDragStart = useCallback((e: React.DragEvent<HTMLDivElement>, idx: number) => {
    setDragIndex(idx);
    setIsDragging(true);
    dragNode.current = e.currentTarget as HTMLDivElement;
    e.dataTransfer.effectAllowed = 'move';
    // Use a transparent drag image so we control visuals via CSS
    const img = new Image();
    img.src = 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7';
    e.dataTransfer.setDragImage(img, 0, 0);
  }, []);

  const handleDragOver = useCallback((e: React.DragEvent<HTMLDivElement>, idx: number) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    setOverIndex(idx);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent<HTMLDivElement>, dropIdx: number) => {
    e.preventDefault();
    if (dragIndex !== null) moveItem(dragIndex, dropIdx);
  }, [dragIndex, moveItem]);

  const handleDragEnd = useCallback(() => {
    setDragIndex(null);
    setOverIndex(null);
    setIsDragging(false);
    dragNode.current = null;
  }, []);

  // --- Touch handlers ---
  const handleTouchStart = useCallback((e: React.TouchEvent<HTMLDivElement>, idx: number) => {
    touchStartY.current = e.touches[0].clientY;
    touchCurrentIdx.current = idx;
    setDragIndex(idx);
    setIsDragging(true);

    // Snapshot all item rects
    if (containerRef.current) {
      const children = containerRef.current.querySelectorAll('[data-drag-item]');
      itemRects.current = Array.from(children).map(c => c.getBoundingClientRect());
    }
  }, []);

  const handleTouchMove = useCallback((e: React.TouchEvent<HTMLDivElement>) => {
    e.preventDefault();
    const y = e.touches[0].clientY;
    // Determine which index the finger is over
    const target = itemRects.current.findIndex(
      rect => y >= rect.top && y <= rect.bottom
    );
    if (target !== -1) setOverIndex(target);
  }, []);

  const handleTouchEnd = useCallback(() => {
    if (dragIndex !== null && overIndex !== null && dragIndex !== overIndex) {
      moveItem(dragIndex, overIndex);
    }
    setDragIndex(null);
    setOverIndex(null);
    setIsDragging(false);
    touchCurrentIdx.current = null;
  }, [dragIndex, overIndex, moveItem]);

  // --- Arrow handlers ---
  const moveUp = useCallback((idx: number) => {
    if (idx > 0) moveItem(idx, idx - 1);
  }, [moveItem]);

  const moveDown = useCallback((idx: number) => {
    if (idx < currentOrder.length - 1) moveItem(idx, idx + 1);
  }, [moveItem, currentOrder.length]);

  // sectionMap is already built dynamically above from settings

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between gap-4 flex-wrap">
        <CardTitle className="text-lg">Homepage Section Order</CardTitle>
        <div className="flex gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setLocalOrder(DEFAULT_ORDER)}
          >
            <RotateCcw className="h-4 w-4 mr-1.5" />
            Reset
          </Button>
          <Button
            size="sm"
            disabled={saveMutation.isPending}
            onClick={() => localOrder && saveMutation.mutate(localOrder)}
          >
            {saveMutation.isPending ? <Loader2 className="h-4 w-4 animate-spin mr-1.5" /> : <Save className="h-4 w-4 mr-1.5" />}
            Save Order
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <p className="text-sm text-muted-foreground mb-6">
          Drag sections or use the arrows to change the order they appear on the homepage.
        </p>
        <div ref={containerRef} className="space-y-1.5 max-w-lg">
          {currentOrder.map((key, idx) => {
            const section = sectionMap[key];
            if (!section) return null;

            const isActive = dragIndex === idx;
            const isOver = overIndex === idx && dragIndex !== null && dragIndex !== idx;
            const dimmed = isDragging && !isActive;

            return (
              <div key={key} className="relative">
                {/* Drop indicator line — above this item */}
                {isOver && dragIndex !== null && dragIndex > idx && (
                  <div className="absolute -top-1 left-4 right-4 h-0.5 rounded-full bg-primary z-10" />
                )}

                <div
                  data-drag-item
                  draggable
                  onDragStart={(e) => handleDragStart(e, idx)}
                  onDragOver={(e) => handleDragOver(e, idx)}
                  onDrop={(e) => handleDrop(e, idx)}
                  onDragEnd={handleDragEnd}
                  onTouchStart={(e) => handleTouchStart(e, idx)}
                  onTouchMove={(e) => handleTouchMove(e)}
                  onTouchEnd={handleTouchEnd}
                  className={`
                    flex items-center gap-2 sm:gap-3 pl-2 pr-2 sm:pr-3 py-3 rounded-xl border bg-card
                    select-none
                    transition-all duration-200 ease-out
                    ${isActive
                      ? 'scale-[1.03] shadow-lg shadow-foreground/10 border-primary z-20 relative'
                      : 'border-border'}
                    ${dimmed ? 'opacity-50' : 'opacity-100'}
                    ${!isDragging ? 'hover:shadow-sm hover:border-muted-foreground/30' : ''}
                  `}
                  style={{ touchAction: 'none' }}
                >
                  {/* 6-dot drag handle — large hit area */}
                  <div className="flex items-center justify-center w-10 h-10 rounded-lg cursor-grab active:cursor-grabbing hover:bg-muted transition-colors shrink-0">
                    <GripVertical className="h-5 w-5 text-muted-foreground" />
                  </div>

                  <span className="text-xs font-medium tabular-nums w-5 text-muted-foreground text-right shrink-0">
                    {idx + 1}
                  </span>

                  <span className="text-sm font-medium text-foreground flex-1 min-w-0 truncate">
                    {section.label}
                  </span>

                  {/* Arrow controls */}
                  <div className="flex items-center gap-0.5 shrink-0">
                    <button
                      type="button"
                      disabled={idx === 0}
                      onClick={(e) => { e.stopPropagation(); moveUp(idx); }}
                      className="p-1.5 rounded-md hover:bg-muted disabled:opacity-30 disabled:pointer-events-none transition-colors"
                      aria-label="Move up"
                    >
                      <ChevronUp className="h-4 w-4 text-muted-foreground" />
                    </button>
                    <button
                      type="button"
                      disabled={idx === currentOrder.length - 1}
                      onClick={(e) => { e.stopPropagation(); moveDown(idx); }}
                      className="p-1.5 rounded-md hover:bg-muted disabled:opacity-30 disabled:pointer-events-none transition-colors"
                      aria-label="Move down"
                    >
                      <ChevronDown className="h-4 w-4 text-muted-foreground" />
                    </button>
                  </div>
                </div>

                {/* Drop indicator line — below this item */}
                {isOver && dragIndex !== null && dragIndex < idx && (
                  <div className="absolute -bottom-1 left-4 right-4 h-0.5 rounded-full bg-primary z-10" />
                )}
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
};

export default HomepageLayoutAdmin;
