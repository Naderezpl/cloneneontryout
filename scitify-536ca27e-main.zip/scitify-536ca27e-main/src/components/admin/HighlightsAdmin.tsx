import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/lib/supabase';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/components/ui/use-toast';
import { Save, Plus, Trash, Loader2, GripVertical } from 'lucide-react';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogClose } from '@/components/ui/dialog';

const ICON_OPTIONS = [
  'Truck', 'Package', 'Plane', 'Rocket', 'Clock', 'Shield', 'BadgeCheck',
  'Award', 'Star', 'Wrench', 'Headphones', 'MessageCircle', 'Phone',
  'LifeBuoy', 'Bot', 'Sparkles', 'Heart', 'Zap', 'Globe', 'Lock',
  'CheckCircle', 'Gift', 'Leaf', 'Crown',
];

interface Highlight {
  id: string;
  title: string;
  description: string;
  icon: string;
  is_enabled: boolean;
  position: number;
}

const HighlightsAdmin = ({ canEdit }: { canEdit: boolean }) => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [deleteId, setDeleteId] = useState<string | null>(null);

  const { data: highlights = [], isLoading } = useQuery({
    queryKey: ['store-highlights'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('store_highlights')
        .select('*')
        .order('position');
      if (error) throw error;
      return data as Highlight[];
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, field, value }: { id: string; field: string; value: any }) => {
      const { error } = await supabase
        .from('store_highlights')
        .update({ [field]: value, updated_at: new Date().toISOString() })
        .eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['store-highlights'] });
      toast({ title: 'Highlight updated' });
    },
    onError: (e) => toast({ variant: 'destructive', title: 'Error', description: e.message }),
  });

  const addMutation = useMutation({
    mutationFn: async () => {
      if (highlights.length >= 6) throw new Error('Maximum 6 highlights allowed');
      const { error } = await supabase.from('store_highlights').insert({
        title: 'New Highlight',
        description: '',
        icon: 'Sparkles',
        is_enabled: true,
        position: highlights.length,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['store-highlights'] });
      toast({ title: 'Highlight added' });
    },
    onError: (e) => toast({ variant: 'destructive', title: 'Error', description: e.message }),
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from('store_highlights').delete().eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['store-highlights'] });
      setDeleteId(null);
      toast({ title: 'Highlight deleted' });
    },
    onError: (e) => toast({ variant: 'destructive', title: 'Error', description: e.message }),
  });

  if (isLoading) return <div className="py-4 text-sm text-muted-foreground">Loading highlights...</div>;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <Label className="text-base font-semibold">Store Highlights ({highlights.length}/6)</Label>
        <Button
          type="button"
          size="sm"
          variant="outline"
          onClick={() => addMutation.mutate()}
          disabled={!canEdit || highlights.length >= 6 || addMutation.isPending}
        >
          {addMutation.isPending ? <Loader2 className="h-4 w-4 animate-spin mr-1" /> : <Plus className="h-4 w-4 mr-1" />}
          Add Highlight
        </Button>
      </div>

      {highlights.map((h, idx) => (
        <div key={h.id} className="rounded-lg border border-border p-4 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <GripVertical className="h-4 w-4 text-muted-foreground" />
              <span className="font-medium text-sm">Card {idx + 1}</span>
            </div>
            <div className="flex items-center gap-3">
              <Switch
                checked={h.is_enabled}
                onCheckedChange={(c) => updateMutation.mutate({ id: h.id, field: 'is_enabled', value: c })}
                disabled={!canEdit}
              />
              <Button
                type="button"
                size="icon"
                variant="ghost"
                className="text-destructive hover:text-destructive"
                onClick={() => setDeleteId(h.id)}
                disabled={!canEdit}
              >
                <Trash className="h-4 w-4" />
              </Button>
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div>
              <Label className="text-xs">Icon</Label>
              <Select
                value={h.icon}
                onValueChange={(v) => updateMutation.mutate({ id: h.id, field: 'icon', value: v })}
                disabled={!canEdit}
              >
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {ICON_OPTIONS.map((i) => (
                    <SelectItem key={i} value={i}>{i}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs">Title</Label>
              <div className="flex gap-1">
                <Input
                  defaultValue={h.title}
                  onBlur={(e) => {
                    if (e.target.value !== h.title) {
                      updateMutation.mutate({ id: h.id, field: 'title', value: e.target.value });
                    }
                  }}
                  disabled={!canEdit}
                />
              </div>
            </div>
            <div>
              <Label className="text-xs">Description</Label>
              <div className="flex gap-1">
                <Input
                  defaultValue={h.description}
                  placeholder="Optional description"
                  onBlur={(e) => {
                    if (e.target.value !== h.description) {
                      updateMutation.mutate({ id: h.id, field: 'description', value: e.target.value });
                    }
                  }}
                  disabled={!canEdit}
                />
              </div>
            </div>
          </div>
        </div>
      ))}

      {highlights.length === 0 && (
        <p className="text-sm text-muted-foreground text-center py-6">
          No highlights yet. Click "Add Highlight" to create your first card.
        </p>
      )}

      <Dialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Highlight</DialogTitle>
          </DialogHeader>
          <p>Are you sure? This action cannot be undone.</p>
          <DialogFooter className="flex justify-end gap-2 mt-4">
            <DialogClose asChild>
              <Button variant="outline">Cancel</Button>
            </DialogClose>
            <Button
              variant="destructive"
              onClick={() => deleteId && deleteMutation.mutate(deleteId)}
              disabled={deleteMutation.isPending}
            >
              {deleteMutation.isPending && <Loader2 className="h-4 w-4 animate-spin mr-1" />}
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default HighlightsAdmin;
