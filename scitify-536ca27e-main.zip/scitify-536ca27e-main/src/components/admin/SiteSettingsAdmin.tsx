import React from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/lib/supabase';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/components/ui/use-toast';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Switch } from '@/components/ui/switch';
import { updateSingleSetting, updateSiteSettings } from '@/api/settings';
import { SiteSettings } from '@/types/settings';
import ImageUploader from '@/components/ImageUploader';
import { Save, Trash, Loader2, ChevronDown } from 'lucide-react';
import HighlightsAdmin from './HighlightsAdmin';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter, DialogClose } from '@/components/ui/dialog';
import { useAuth } from '@/contexts/AuthContext';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';

const formSchema = z.object({
  id: z.number().optional(),
  site_title: z.string().nullable().optional(),
  site_description: z.string().nullable().optional(),
  logo_url: z.string().nullable().optional(),
  favicon_url: z.string().nullable().optional(),
  meta_title: z.string().nullable().optional(),
  meta_description: z.string().nullable().optional(),
  company_name: z.string().nullable().optional(),
  contact_email: z.string().nullable().optional(),
  contact_phone: z.string().nullable().optional(),
  contact_address: z.string().nullable().optional(),
  whatsapp_enabled: z.boolean().optional(),
  whatsapp_number1: z.string().nullable().optional(),
  whatsapp_number2: z.string().nullable().optional(),
  show_featured_products: z.boolean().optional(),
  show_on_sale_products: z.boolean().optional(),
  featured_products_title: z.string().nullable().optional(),
  on_sale_products_title: z.string().nullable().optional(),
  featured_products_description: z.string().nullable().optional(),
  on_sale_products_description: z.string().nullable().optional(),
  show_about_section: z.boolean().optional(),
  about_section_title: z.string().nullable().optional(),
  about_section_html: z.string().nullable().optional(),
  about_section_image_url: z.string().nullable().optional(),
  hero_slider_enabled: z.boolean().optional(),
  hero_slider_autoplay: z.boolean().optional(),
  hero_slider_interval_ms: z.number().optional(),
  hero_slider_pause_on_hover: z.boolean().optional(),
  concept_final_slider_enabled: z.boolean().optional(),
  concept_image_url: z.string().nullable().optional(),
  final_image_url: z.string().nullable().optional(),
  show_testimonials_section: z.boolean().optional(),
  show_social_section: z.boolean().optional(),
  show_promotions_section: z.boolean().optional(),
  promotions_html: z.string().nullable().optional(),
  free_shipping_enabled: z.boolean().optional(),
  free_shipping_text: z.string().nullable().optional(),
  secure_payments_enabled: z.boolean().optional(),
  secure_payments_text: z.string().nullable().optional(),
  payment_visa_enabled: z.boolean().optional(),
  payment_mastercard_enabled: z.boolean().optional(),
  payment_apple_pay_enabled: z.boolean().optional(),
  payment_google_pay_enabled: z.boolean().optional(),
  payment_paypal_enabled: z.boolean().optional(),
  payment_cod_enabled: z.boolean().optional(),
  whish_number: z.string().nullable().optional(),
  whish_owner_name: z.string().nullable().optional(),
  omt_number: z.string().nullable().optional(),
  omt_owner_name: z.string().nullable().optional(),
  payment_instructions: z.string().nullable().optional(),
  footer_copyright: z.string().nullable().optional(),
  social_instagram_enabled: z.boolean().optional(),
  social_instagram_url: z.string().nullable().optional(),
  social_facebook_enabled: z.boolean().optional(),
  social_facebook_url: z.string().nullable().optional(),
  social_tiktok_enabled: z.boolean().optional(),
  social_tiktok_url: z.string().nullable().optional(),
  social_youtube_enabled: z.boolean().optional(),
  social_youtube_url: z.string().nullable().optional(),
  social_whatsapp_enabled: z.boolean().optional(),
  social_whatsapp_url: z.string().nullable().optional(),
  social_twitter_enabled: z.boolean().optional(),
  social_twitter_url: z.string().nullable().optional(),
  shipping_enabled: z.boolean().optional(),
  shipping_title: z.string().nullable().optional(),
  shipping_description: z.string().nullable().optional(),
  shipping_icon: z.string().nullable().optional(),
  quality_enabled: z.boolean().optional(),
  quality_title: z.string().nullable().optional(),
  quality_description: z.string().nullable().optional(),
  quality_icon: z.string().nullable().optional(),
  support_enabled: z.boolean().optional(),
  support_title: z.string().nullable().optional(),
  support_description: z.string().nullable().optional(),
  support_icon: z.string().nullable().optional(),
  moderation_enabled: z.boolean().optional(),
  ai_moderation_enabled: z.boolean().optional(),
  auto_publish_min_stars: z.number().optional(),
  send_below_stars_to_moderation: z.number().optional(),
  block_spam_reviews: z.boolean().optional(),
  video_feed_enabled: z.boolean().optional(),
  video_feed_count: z.number().optional(),
  video_feed_refresh_minutes: z.number().optional(),
  video_feed_autoplay_enabled: z.boolean().optional(),
  announcement_bar_enabled: z.boolean().optional(),
  announcement_bar_text: z.string().nullable().optional(),
  announcement_bar_bg_color: z.string().nullable().optional(),
  returns_text: z.string().nullable().optional(),
  highlights_section_title: z.string().nullable().optional(),
});

const SiteSettingsAdmin = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { hasDbAdminRole, isAdmin } = useAuth();
  const canEdit = isAdmin || hasDbAdminRole;

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      logo_url: '',
      company_name: '',
      contact_email: '',
      contact_phone: '',
      contact_address: '',
      whatsapp_enabled: false,
      whatsapp_number1: '',
      whatsapp_number2: '',
      show_featured_products: true,
      show_on_sale_products: true,
      featured_products_title: '',
      on_sale_products_title: '',
      featured_products_description: '',
      on_sale_products_description: '',
    },
    mode: 'onBlur'
  });

  const { data: settings, isLoading } = useQuery({
    queryKey: ['site-settings'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('site_settings')
        .select('*')
        .order('id', { ascending: false })
        .limit(1)
        .maybeSingle();

      if (error) {
        if (error.code === 'PGRST116' || error.message.includes('No rows')) {
          return {
            id: null,
            logo_url: '/logo.png',
            company_name: 'LINKORA',
            contact_email: 'info@linkora.com',
            contact_phone: '(555) 123-4567',
            contact_address: '123 Example Street, City, Country',
            whatsapp_enabled: false,
            whatsapp_number1: null,
            whatsapp_number2: null,
            show_featured_products: true,
            show_on_sale_products: true,
            featured_products_title: '',
            on_sale_products_title: '',
            featured_products_description: '',
            on_sale_products_description: '',
          };
        }
        console.error('Error fetching site settings:', error);
        throw new Error(error.message);
      }

      return data as SiteSettings & { id: number };
    }
  });

  React.useEffect(() => {
    if (settings) {
      form.reset(settings);
    }
  }, [settings, form]);

  const updateFieldMutation = useMutation({
    mutationFn: async ({ field, value }: { field: string, value: any }) => {
      if (!canEdit) {
        throw new Error("Insufficient permissions. Admin DB role required.");
      }
      const result = await updateSingleSetting(field, value);
      return { field, value, result };
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['site-settings'] });
      toast({
        title: "Setting Updated",
        description: `The ${data.field.replace('_', ' ')} has been updated successfully.`,
      });
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Error",
        description: `Failed to update setting: ${error.message}`,
      });
    }
  });

  const updateAllSettingsMutation = useMutation({
    mutationFn: async (values: z.infer<typeof formSchema>) => {
      if (!canEdit) {
        throw new Error("Insufficient permissions. Admin DB role required.");
      }
      const { id, ...settingsToUpdate } = values;
      return updateSiteSettings(settingsToUpdate);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['site-settings'] });
      toast({
        title: "Settings Saved",
        description: "All site settings have been updated successfully.",
      });
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Error",
        description: `Failed to update settings: ${error.message}`,
      });
    }
  });

  const handleFieldUpdate = (field: string, value: any) => {
    if (!canEdit) {
      toast({
        variant: "destructive",
        title: "Insufficient Permissions",
        description: "Updating site settings requires a DB admin role.",
      });
      return;
    }
    updateFieldMutation.mutate({ field, value });
  };

  const handleLogoUpload = (url: string) => {
    handleFieldUpdate('logo_url', url);
  };

  const handleLogoDelete = async () => {
    try {
      if (!canEdit) {
        toast({
          variant: "destructive",
          title: "Insufficient Permissions",
          description: "Deleting the logo requires a DB admin role.",
        });
        return;
      }
      await updateSingleSetting('logo_url', null);
      form.setValue('logo_url', '');
      queryClient.invalidateQueries({ queryKey: ['site-settings'] });
      queryClient.refetchQueries({ queryKey: ['site-settings'], type: 'active' });
      toast({
        title: "Logo Deleted",
        description: "The store logo has been removed successfully.",
      });
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: `Failed to delete logo: ${error instanceof Error ? error.message : 'Unknown error'}`,
      });
    }
  };

  if (isLoading) {
    return <div className="text-center py-8">Loading site settings...</div>;
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle>Site Settings</CardTitle>
        <Button
          onClick={form.handleSubmit(
            (values) => updateAllSettingsMutation.mutate(values),
            (errors) => {
              console.error('Form validation errors:', errors);
              const firstError = Object.values(errors)[0];
              toast({
                variant: "destructive",
                title: "Validation Error",
                description: firstError?.message?.toString() || "Please check your input fields.",
              });
            }
          )}
          disabled={!canEdit || updateAllSettingsMutation.isPending}
        >
          {updateAllSettingsMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
          Save All Changes
        </Button>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <Accordion type="multiple" className="w-full space-y-3">

            {/* ── Store Identity ── */}
            <AccordionItem value="store-identity" className="border rounded-lg px-4">
              <AccordionTrigger className="justify-center gap-2 text-base font-semibold hover:no-underline">
                Store Identity
              </AccordionTrigger>
              <AccordionContent>
                <div className="space-y-6 pt-2">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="logo_url"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Store Logo</FormLabel>
                          <FormControl>
                            <div className="space-y-4">
                              {field.value && (
                                <div className="flex items-center gap-4">
                                  <div className="max-w-[200px] overflow-hidden">
                                    <img src={field.value} alt="Current logo" className="w-full h-auto object-contain" />
                                  </div>
                                  <Dialog>
                                    <DialogTrigger asChild>
                                      <Button variant="destructive" size="sm" className="flex items-center gap-2" disabled={!canEdit}>
                                        <Trash className="h-4 w-4" /> Delete Logo
                                      </Button>
                                    </DialogTrigger>
                                    <DialogContent>
                                      <DialogHeader><DialogTitle>Delete Logo</DialogTitle></DialogHeader>
                                      <p>Are you sure you want to delete the current logo? This action cannot be undone.</p>
                                      <DialogFooter className="flex justify-end gap-2 mt-4">
                                        <DialogClose asChild><Button variant="outline">Cancel</Button></DialogClose>
                                        <DialogClose asChild><Button variant="destructive" onClick={handleLogoDelete}>Delete</Button></DialogClose>
                                      </DialogFooter>
                                    </DialogContent>
                                  </Dialog>
                                </div>
                              )}
                              <ImageUploader
                                onImageUploaded={(url) => handleFieldUpdate('logo_url', url)}
                                defaultImageUrl={field.value}
                                bucketName="imageassets"
                                folderPath="sitesettings"
                                uploadId="site-logo-upload"
                                disabled={!canEdit}
                                aspectRatio={1}
                                recommendedSize="1000 × 1000 px"
                              />
                            </div>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="company_name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Store Name</FormLabel>
                          <div className="flex space-x-2">
                            <FormControl>
                              <Input {...field} placeholder="Enter store name" disabled={!canEdit} />
                            </FormControl>
                            <Button type="button" onClick={() => handleFieldUpdate('company_name', field.value)} disabled={!canEdit || (updateFieldMutation.isPending && updateFieldMutation.variables?.field === 'company_name')} size="icon">
                              <Save className="h-4 w-4" />
                            </Button>
                          </div>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="favicon_url"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Favicon</FormLabel>
                        <FormControl>
                          <div className="space-y-4">
                            {field.value && (
                              <div className="max-w-[48px]">
                                <img src={field.value} alt="Current favicon" className="w-12 h-12 object-contain" />
                              </div>
                            )}
                            <ImageUploader
                              onImageUploaded={(url) => handleFieldUpdate('favicon_url', url)}
                              defaultImageUrl={field.value as string}
                              bucketName="imageassets"
                              folderPath="sitesettings"
                              disabled={!canEdit}
                              aspectRatio={1}
                              uploadId="site-favicon-upload"
                              recommendedSize="512 × 512 px"
                            />
                          </div>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </AccordionContent>
            </AccordionItem>

            {/* ── SEO & Meta ── */}
            <AccordionItem value="seo-meta" className="border rounded-lg px-4">
              <AccordionTrigger className="justify-center gap-2 text-base font-semibold hover:no-underline">
                SEO & Meta
              </AccordionTrigger>
              <AccordionContent>
                <div className="space-y-6 pt-2">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField control={form.control} name="site_title" render={({ field }) => (
                      <FormItem>
                        <FormLabel>Site Title</FormLabel>
                        <div className="flex space-x-2">
                          <FormControl><Input {...field} placeholder="Enter site title" disabled={!canEdit} /></FormControl>
                          <Button type="button" onClick={() => handleFieldUpdate('site_title', field.value)} disabled={!canEdit || (updateFieldMutation.isPending && updateFieldMutation.variables?.field === 'site_title')} size="icon"><Save className="h-4 w-4" /></Button>
                        </div>
                        <FormMessage />
                      </FormItem>
                    )} />
                    <FormField control={form.control} name="meta_title" render={({ field }) => (
                      <FormItem>
                        <FormLabel>Meta Title</FormLabel>
                        <div className="flex space-x-2">
                          <FormControl><Input {...field} placeholder="Enter meta title" disabled={!canEdit} /></FormControl>
                          <Button type="button" onClick={() => handleFieldUpdate('meta_title', field.value)} disabled={!canEdit || (updateFieldMutation.isPending && updateFieldMutation.variables?.field === 'meta_title')} size="icon"><Save className="h-4 w-4" /></Button>
                        </div>
                        <FormMessage />
                      </FormItem>
                    )} />
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField control={form.control} name="site_description" render={({ field }) => (
                      <FormItem>
                        <FormLabel>Site Description</FormLabel>
                        <div className="flex space-x-2">
                          <FormControl><Textarea {...field} placeholder="Enter site description" disabled={!canEdit} /></FormControl>
                          <Button type="button" onClick={() => handleFieldUpdate('site_description', field.value)} disabled={!canEdit || (updateFieldMutation.isPending && updateFieldMutation.variables?.field === 'site_description')} size="icon"><Save className="h-4 w-4" /></Button>
                        </div>
                        <FormMessage />
                      </FormItem>
                    )} />
                    <FormField control={form.control} name="meta_description" render={({ field }) => (
                      <FormItem>
                        <FormLabel>Meta Description</FormLabel>
                        <div className="flex space-x-2">
                          <FormControl><Textarea {...field} placeholder="Enter meta description" disabled={!canEdit} /></FormControl>
                          <Button type="button" onClick={() => handleFieldUpdate('meta_description', field.value)} disabled={!canEdit || (updateFieldMutation.isPending && updateFieldMutation.variables?.field === 'meta_description')} size="icon"><Save className="h-4 w-4" /></Button>
                        </div>
                        <FormMessage />
                      </FormItem>
                    )} />
                  </div>
                </div>
              </AccordionContent>
            </AccordionItem>

            {/* ── Announcement Bar ── */}
            <AccordionItem value="announcement-bar" className="border rounded-lg px-4">
              <AccordionTrigger className="justify-center gap-2 text-base font-semibold hover:no-underline">
                Announcement Bar
              </AccordionTrigger>
              <AccordionContent>
                <div className="space-y-4 pt-2">
                  <FormField control={form.control} name="announcement_bar_enabled" render={({ field }) => (
                    <FormItem className="flex items-center justify-between">
                      <FormLabel>Enable Announcement Bar</FormLabel>
                      <FormControl>
                        <Switch checked={field.value} onCheckedChange={(val) => { field.onChange(val); handleFieldUpdate('announcement_bar_enabled', val); }} disabled={!canEdit} />
                      </FormControl>
                    </FormItem>
                  )} />
                  <FormField control={form.control} name="announcement_bar_text" render={({ field }) => (
                    <FormItem>
                      <FormLabel>Announcement Text</FormLabel>
                      <div className="flex space-x-2">
                        <FormControl><Input {...field} placeholder="e.g. Free shipping on orders over $50 🚚" disabled={!canEdit} /></FormControl>
                        <Button type="button" onClick={() => handleFieldUpdate('announcement_bar_text', field.value)} disabled={!canEdit || (updateFieldMutation.isPending && updateFieldMutation.variables?.field === 'announcement_bar_text')} size="icon"><Save className="h-4 w-4" /></Button>
                      </div>
                      <p className="text-xs text-muted-foreground">Leave empty to hide the bar even when enabled.</p>
                    </FormItem>
                  )} />
                  <FormField control={form.control} name="announcement_bar_bg_color" render={({ field }) => (
                    <FormItem>
                      <FormLabel>Background Color</FormLabel>
                      <div className="flex items-center space-x-3">
                        <input type="color" value={field.value || '#1a1a1a'} onChange={(e) => field.onChange(e.target.value)} className="w-10 h-10 rounded border border-input cursor-pointer" disabled={!canEdit} />
                        <FormControl><Input {...field} placeholder="#1a1a1a" disabled={!canEdit} className="max-w-[140px] font-mono text-sm" /></FormControl>
                        <Button type="button" onClick={() => handleFieldUpdate('announcement_bar_bg_color', field.value)} disabled={!canEdit || (updateFieldMutation.isPending && updateFieldMutation.variables?.field === 'announcement_bar_bg_color')} size="icon"><Save className="h-4 w-4" /></Button>
                      </div>
                    </FormItem>
                  )} />
                </div>
              </AccordionContent>
            </AccordionItem>

            {/* ── Store Highlights ── */}
            <AccordionItem value="store-highlights" className="border rounded-lg px-4">
              <AccordionTrigger className="justify-center gap-2 text-base font-semibold hover:no-underline">
                Store Highlights
              </AccordionTrigger>
              <AccordionContent>
                <div className="space-y-4 pt-2">
                  <FormField control={form.control} name="highlights_section_title" render={({ field }) => (
                    <FormItem>
                      <FormLabel>Section Title</FormLabel>
                      <div className="flex space-x-2">
                        <FormControl><Input {...field} value={field.value ?? ''} placeholder="e.g. Why Choose Us" disabled={!canEdit} /></FormControl>
                        <Button type="button" onClick={() => handleFieldUpdate('highlights_section_title', field.value)} disabled={!canEdit || (updateFieldMutation.isPending && updateFieldMutation.variables?.field === 'highlights_section_title')} size="icon"><Save className="h-4 w-4" /></Button>
                      </div>
                      <p className="text-xs text-muted-foreground">Displayed above the highlight cards. Leave empty to hide.</p>
                      <FormMessage />
                    </FormItem>
                  )} />
                  <HighlightsAdmin canEdit={canEdit} />
                </div>
              </AccordionContent>
            </AccordionItem>

            {/* ── Contact Information ── */}
            <AccordionItem value="contact-info" className="border rounded-lg px-4">
              <AccordionTrigger className="justify-center gap-2 text-base font-semibold hover:no-underline">
                Contact Information
              </AccordionTrigger>
              <AccordionContent>
                <div className="space-y-6 pt-2">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <FormField control={form.control} name="contact_email" render={({ field }) => (
                      <FormItem>
                        <FormLabel>Contact Email</FormLabel>
                        <div className="flex space-x-2">
                          <FormControl><Input type="email" {...field} placeholder="Enter contact email" disabled={!canEdit} /></FormControl>
                          <Button type="button" onClick={() => handleFieldUpdate('contact_email', field.value)} disabled={!canEdit || (updateFieldMutation.isPending && updateFieldMutation.variables?.field === 'contact_email')} size="icon"><Save className="h-4 w-4" /></Button>
                        </div>
                        <FormMessage />
                      </FormItem>
                    )} />
                    <FormField control={form.control} name="contact_phone" render={({ field }) => (
                      <FormItem>
                        <FormLabel>Contact Phone</FormLabel>
                        <div className="flex space-x-2">
                          <FormControl><Input {...field} placeholder="Enter contact phone" disabled={!canEdit} /></FormControl>
                          <Button type="button" onClick={() => handleFieldUpdate('contact_phone', field.value)} disabled={!canEdit || (updateFieldMutation.isPending && updateFieldMutation.variables?.field === 'contact_phone')} size="icon"><Save className="h-4 w-4" /></Button>
                        </div>
                        <FormMessage />
                      </FormItem>
                    )} />
                    <FormField control={form.control} name="contact_address" render={({ field }) => (
                      <FormItem>
                        <FormLabel>Contact Address</FormLabel>
                        <div className="flex space-x-2">
                          <FormControl><Input {...field} placeholder="Enter contact address" disabled={!canEdit} /></FormControl>
                          <Button type="button" onClick={() => handleFieldUpdate('contact_address', field.value)} disabled={!canEdit || (updateFieldMutation.isPending && updateFieldMutation.variables?.field === 'contact_address')} size="icon"><Save className="h-4 w-4" /></Button>
                        </div>
                        <FormMessage />
                      </FormItem>
                    )} />
                  </div>
                </div>
              </AccordionContent>
            </AccordionItem>

            {/* ── WhatsApp Settings ── */}
            <AccordionItem value="whatsapp" className="border rounded-lg px-4">
              <AccordionTrigger className="justify-center gap-2 text-base font-semibold hover:no-underline">
                WhatsApp Settings
              </AccordionTrigger>
              <AccordionContent>
                <div className="space-y-6 pt-2">
                  <FormField control={form.control} name="whatsapp_enabled" render={({ field }) => (
                    <FormItem>
                      <div className="flex items-center justify-between rounded-md border p-4 bg-muted">
                        <div>
                          <FormLabel>Enable WhatsApp Contact</FormLabel>
                          <div className="text-muted-foreground text-xs mt-1">Show WhatsApp icons and links on the site.</div>
                        </div>
                        <FormControl>
                          <Switch checked={!!field.value} onCheckedChange={(checked) => { field.onChange(checked); handleFieldUpdate('whatsapp_enabled', checked); }} disabled={!canEdit} />
                        </FormControl>
                      </div>
                    </FormItem>
                  )} />
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField control={form.control} name="whatsapp_number1" render={({ field }) => (
                      <FormItem>
                        <FormLabel>Number 1 (WhatsApp)</FormLabel>
                        <div className="flex space-x-2">
                          <FormControl><Input {...field} placeholder="e.g., 96181193419" disabled={!canEdit} /></FormControl>
                          <Button type="button" onClick={() => handleFieldUpdate('whatsapp_number1', field.value)} disabled={!canEdit || (updateFieldMutation.isPending && updateFieldMutation.variables?.field === 'whatsapp_number1')} size="icon"><Save className="h-4 w-4" /></Button>
                        </div>
                        <FormMessage />
                      </FormItem>
                    )} />
                  </div>
                </div>
              </AccordionContent>
            </AccordionItem>

            {/* ── Homepage Sections ── */}
            <AccordionItem value="homepage-sections" className="border rounded-lg px-4">
              <AccordionTrigger className="justify-center gap-2 text-base font-semibold hover:no-underline">
                Homepage Sections
              </AccordionTrigger>
              <AccordionContent>
                <div className="space-y-6 pt-2">
                  {/* Featured Products */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField control={form.control} name="show_featured_products" render={({ field }) => (
                      <FormItem>
                        <div className="flex items-center justify-between rounded-md border p-4 bg-muted">
                          <div>
                            <FormLabel>Show Featured Products</FormLabel>
                            <div className="text-muted-foreground text-xs mt-1">Toggle to show or hide the Featured Products section on the homepage.</div>
                          </div>
                          <FormControl>
                            <Switch checked={field.value} onCheckedChange={(checked) => { field.onChange(checked); handleFieldUpdate('show_featured_products', checked); }} disabled={!canEdit} />
                          </FormControl>
                        </div>
                      </FormItem>
                    )} />
                    <FormField control={form.control} name="show_on_sale_products" render={({ field }) => (
                      <FormItem>
                        <div className="flex items-center justify-between rounded-md border p-4 bg-muted">
                          <div>
                            <FormLabel>Show Limited Time Offers</FormLabel>
                            <div className="text-muted-foreground text-xs mt-1">Toggle to show or hide the Limited Time Offers section on the homepage.</div>
                          </div>
                          <FormControl>
                            <Switch checked={field.value} onCheckedChange={(checked) => { field.onChange(checked); handleFieldUpdate('show_on_sale_products', checked); }} disabled={!canEdit} />
                          </FormControl>
                        </div>
                      </FormItem>
                    )} />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField control={form.control} name="featured_products_title" render={({ field }) => (
                      <FormItem>
                        <FormLabel>Featured Products Title</FormLabel>
                        <div className="flex space-x-2">
                          <FormControl><Input {...field} placeholder="Enter section title" disabled={!canEdit} /></FormControl>
                          <Button type="button" onClick={() => handleFieldUpdate('featured_products_title', field.value)} disabled={!canEdit || (updateFieldMutation.isPending && updateFieldMutation.variables?.field === 'featured_products_title')} size="icon"><Save className="h-4 w-4" /></Button>
                        </div>
                        <FormMessage />
                      </FormItem>
                    )} />
                    <FormField control={form.control} name="featured_products_description" render={({ field }) => (
                      <FormItem>
                        <FormLabel>Featured Products Description</FormLabel>
                        <div className="flex space-x-2">
                          <FormControl><Textarea {...field} placeholder="Enter description for Featured Products" disabled={!canEdit} /></FormControl>
                          <Button type="button" onClick={() => handleFieldUpdate('featured_products_description', field.value)} disabled={!canEdit || (updateFieldMutation.isPending && updateFieldMutation.variables?.field === 'featured_products_description')} size="icon"><Save className="h-4 w-4" /></Button>
                        </div>
                        <FormMessage />
                      </FormItem>
                    )} />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField control={form.control} name="on_sale_products_title" render={({ field }) => (
                      <FormItem>
                        <FormLabel>Limited Time Offers Title</FormLabel>
                        <div className="flex space-x-2">
                          <FormControl><Input {...field} placeholder="Enter section title" disabled={!canEdit} /></FormControl>
                          <Button type="button" onClick={() => handleFieldUpdate('on_sale_products_title', field.value)} disabled={!canEdit || (updateFieldMutation.isPending && updateFieldMutation.variables?.field === 'on_sale_products_title')} size="icon"><Save className="h-4 w-4" /></Button>
                        </div>
                        <FormMessage />
                      </FormItem>
                    )} />
                    <FormField control={form.control} name="on_sale_products_description" render={({ field }) => (
                      <FormItem>
                        <FormLabel>Description of Limited Time Offers Title</FormLabel>
                        <div className="flex space-x-2">
                          <FormControl><Textarea {...field} placeholder="Enter description for Limited Time Offers" disabled={!canEdit} /></FormControl>
                          <Button type="button" onClick={() => handleFieldUpdate('on_sale_products_description', field.value)} disabled={!canEdit || (updateFieldMutation.isPending && updateFieldMutation.variables?.field === 'on_sale_products_description')} size="icon"><Save className="h-4 w-4" /></Button>
                        </div>
                        <FormMessage />
                      </FormItem>
                    )} />
                  </div>

                  {/* About Section */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField control={form.control} name="show_about_section" render={({ field }) => (
                      <FormItem>
                        <div className="flex items-center justify-between rounded-md border p-4 bg-muted">
                          <div>
                            <FormLabel>Show About Section (Home)</FormLabel>
                            <div className="text-muted-foreground text-xs mt-1">Toggle About section on homepage.</div>
                          </div>
                          <FormControl>
                            <Switch checked={!!field.value} onCheckedChange={(checked) => { field.onChange(checked); handleFieldUpdate('show_about_section', checked); }} disabled={!canEdit} />
                          </FormControl>
                        </div>
                      </FormItem>
                    )} />
                    <FormField control={form.control} name="about_section_image_url" render={({ field }) => (
                      <FormItem>
                        <FormLabel>About Section Image (separate from Store Logo)</FormLabel>
                        <ImageUploader
                          onImageUploaded={(url) => handleFieldUpdate('about_section_image_url', url)}
                          defaultImageUrl={field.value || undefined}
                          bucketName="imageassets"
                          folderPath="homepage"
                          uploadId="about-section-image-upload"
                          disabled={!canEdit}
                          aspectRatio={16 / 9}
                          recommendedSize="1600 × 900 px"
                        />
                        <FormMessage />
                      </FormItem>
                    )} />
                  </div>
                  <FormField control={form.control} name="about_section_title" render={({ field }) => (
                    <FormItem>
                      <FormLabel>About Section Title</FormLabel>
                      <div className="flex space-x-2">
                        <FormControl><Input {...field} placeholder="e.g. Our Story" disabled={!canEdit} /></FormControl>
                        <Button type="button" onClick={() => handleFieldUpdate('about_section_title', field.value)} disabled={!canEdit || (updateFieldMutation.isPending && updateFieldMutation.variables?.field === 'about_section_title')} size="icon"><Save className="h-4 w-4" /></Button>
                      </div>
                      <FormMessage />
                    </FormItem>
                  )} />
                  <FormField control={form.control} name="about_section_html" render={({ field }) => (
                    <FormItem>
                      <FormLabel>About Section Content (HTML)</FormLabel>
                      <div className="flex space-x-2">
                        <FormControl><Textarea {...field} placeholder="Enter HTML for About section" className="min-h-32" disabled={!canEdit} /></FormControl>
                        <Button type="button" onClick={() => handleFieldUpdate('about_section_html', field.value)} disabled={!canEdit || (updateFieldMutation.isPending && updateFieldMutation.variables?.field === 'about_section_html')} size="icon"><Save className="h-4 w-4" /></Button>
                      </div>
                      <FormMessage />
                    </FormItem>
                  )} />

                  {/* Testimonials & Social */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField control={form.control} name="show_testimonials_section" render={({ field }) => (
                      <FormItem>
                        <div className="flex items-center justify-between rounded-md border p-4 bg-muted">
                          <div><FormLabel>Show Testimonials</FormLabel></div>
                          <FormControl>
                            <Switch checked={!!field.value} onCheckedChange={(checked) => { field.onChange(checked); handleFieldUpdate('show_testimonials_section', checked); }} disabled={!canEdit} />
                          </FormControl>
                        </div>
                      </FormItem>
                    )} />
                    <FormField control={form.control} name="show_social_section" render={({ field }) => (
                      <FormItem>
                        <div className="flex items-center justify-between rounded-md border p-4 bg-muted">
                          <div><FormLabel>Email Subscription</FormLabel></div>
                          <FormControl>
                            <Switch checked={!!field.value} onCheckedChange={(checked) => { field.onChange(checked); handleFieldUpdate('show_social_section', checked); }} disabled={!canEdit} />
                          </FormControl>
                        </div>
                      </FormItem>
                    )} />
                  </div>

                  {/* Promotions */}
                  <FormField control={form.control} name="show_promotions_section" render={({ field }) => (
                    <FormItem>
                      <div className="flex items-center justify-between rounded-md border p-4 bg-muted">
                        <div><FormLabel>Show Promotions/Announcements</FormLabel></div>
                        <FormControl>
                          <Switch checked={!!field.value} onCheckedChange={(checked) => { field.onChange(checked); handleFieldUpdate('show_promotions_section', checked); }} disabled={!canEdit} />
                        </FormControl>
                      </div>
                    </FormItem>
                  )} />
                  <FormField control={form.control} name="promotions_html" render={({ field }) => (
                    <FormItem>
                      <FormLabel>Promotions Content (HTML)</FormLabel>
                      <div className="flex space-x-2">
                        <FormControl><Textarea {...field} placeholder="Enter HTML for promotions/announcement bar" className="min-h-24" disabled={!canEdit} /></FormControl>
                        <Button type="button" onClick={() => handleFieldUpdate('promotions_html', field.value)} disabled={!canEdit || (updateFieldMutation.isPending && updateFieldMutation.variables?.field === 'promotions_html')} size="icon"><Save className="h-4 w-4" /></Button>
                      </div>
                      <FormMessage />
                    </FormItem>
                  )} />
                </div>
              </AccordionContent>
            </AccordionItem>

            {/* ── Review Moderation ── */}
            <AccordionItem value="review-moderation" className="border rounded-lg px-4">
              <AccordionTrigger className="justify-center gap-2 text-base font-semibold hover:no-underline">
                Review Moderation
              </AccordionTrigger>
              <AccordionContent>
                <div className="space-y-4 pt-2">
                  <FormField control={form.control} name="moderation_enabled" render={({ field }) => (
                    <FormItem>
                      <div className="flex items-center justify-between rounded-md border p-3">
                        <div className="text-sm">Enable Moderation</div>
                        <FormControl>
                          <Switch checked={!!field.value} onCheckedChange={(checked) => { field.onChange(checked); handleFieldUpdate('moderation_enabled', checked); }} disabled={!canEdit} />
                        </FormControl>
                      </div>
                    </FormItem>
                  )} />
                  <FormField control={form.control} name="ai_moderation_enabled" render={({ field }) => (
                    <FormItem>
                      <div className="flex items-center justify-between rounded-md border p-3">
                        <div className="text-sm">AI Moderation</div>
                        <FormControl>
                          <Switch checked={!!field.value} onCheckedChange={(checked) => { field.onChange(checked); handleFieldUpdate('ai_moderation_enabled', checked); }} disabled={!canEdit} />
                        </FormControl>
                      </div>
                    </FormItem>
                  )} />
                  <FormItem>
                    <FormLabel>Auto Publish Minimum Stars</FormLabel>
                    <Select value={String((settings as any)?.auto_publish_min_stars ?? 4)} onValueChange={(val) => handleFieldUpdate('auto_publish_min_stars', Number(val))} disabled={!canEdit}>
                      <SelectTrigger><SelectValue placeholder="Select stars" /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="3">3</SelectItem>
                        <SelectItem value="4">4</SelectItem>
                        <SelectItem value="5">5</SelectItem>
                      </SelectContent>
                    </Select>
                  </FormItem>
                  <FormItem>
                    <FormLabel>Send Below Stars To Moderation</FormLabel>
                    <Select value={String((settings as any)?.send_below_stars_to_moderation ?? 3)} onValueChange={(val) => handleFieldUpdate('send_below_stars_to_moderation', Number(val))} disabled={!canEdit}>
                      <SelectTrigger><SelectValue placeholder="Select stars" /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">1</SelectItem>
                        <SelectItem value="2">2</SelectItem>
                        <SelectItem value="3">3</SelectItem>
                      </SelectContent>
                    </Select>
                  </FormItem>
                  <FormField control={form.control} name="block_spam_reviews" render={({ field }) => (
                    <FormItem>
                      <div className="flex items-center justify-between rounded-md border p-3">
                        <div className="text-sm">Block Spam Reviews</div>
                        <FormControl>
                          <Switch checked={!!field.value} onCheckedChange={(checked) => { field.onChange(checked); handleFieldUpdate('block_spam_reviews', checked); }} disabled={!canEdit} />
                        </FormControl>
                      </div>
                    </FormItem>
                  )} />
                </div>
              </AccordionContent>
            </AccordionItem>

            {/* ── Shipping & Payments ── */}
            <AccordionItem value="shipping-payments" className="border rounded-lg px-4">
              <AccordionTrigger className="justify-center gap-2 text-base font-semibold hover:no-underline">
                Shipping & Payments
              </AccordionTrigger>
              <AccordionContent>
                <div className="space-y-6 pt-2">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField control={form.control} name="free_shipping_enabled" render={({ field }) => (
                      <FormItem>
                        <div className="flex items-center justify-between rounded-md border p-4 bg-muted">
                          <div><FormLabel>Free Shipping Message</FormLabel></div>
                          <FormControl>
                            <Switch checked={!!field.value} onCheckedChange={(checked) => { field.onChange(checked); handleFieldUpdate('free_shipping_enabled', checked); }} disabled={!canEdit} />
                          </FormControl>
                        </div>
                      </FormItem>
                    )} />
                    <FormField control={form.control} name="free_shipping_text" render={({ field }) => (
                      <FormItem>
                        <FormLabel>Free Shipping Text</FormLabel>
                        <div className="flex space-x-2">
                          <FormControl><Input {...field} placeholder="Free Shipping over $50" disabled={!canEdit} /></FormControl>
                          <Button type="button" onClick={() => handleFieldUpdate('free_shipping_text', field.value)} disabled={!canEdit || (updateFieldMutation.isPending && updateFieldMutation.variables?.field === 'free_shipping_text')} size="icon"><Save className="h-4 w-4" /></Button>
                        </div>
                        <FormMessage />
                      </FormItem>
                    )} />
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField control={form.control} name="secure_payments_enabled" render={({ field }) => (
                      <FormItem>
                        <div className="flex items-center justify-between rounded-md border p-4 bg-muted">
                          <div><FormLabel>Secure Payments Badge</FormLabel></div>
                          <FormControl>
                            <Switch checked={!!field.value} onCheckedChange={(checked) => { field.onChange(checked); handleFieldUpdate('secure_payments_enabled', checked); }} disabled={!canEdit} />
                          </FormControl>
                        </div>
                      </FormItem>
                    )} />
                    <FormField control={form.control} name="secure_payments_text" render={({ field }) => (
                      <FormItem>
                        <FormLabel>Secure Payments Text</FormLabel>
                        <div className="flex space-x-2">
                          <FormControl><Input {...field} placeholder="Secure Payments" disabled={!canEdit} /></FormControl>
                          <Button type="button" onClick={() => handleFieldUpdate('secure_payments_text', field.value)} disabled={!canEdit || (updateFieldMutation.isPending && updateFieldMutation.variables?.field === 'secure_payments_text')} size="icon"><Save className="h-4 w-4" /></Button>
                        </div>
                        <FormMessage />
                      </FormItem>
                    )} />
                  </div>

                  <FormField control={form.control} name="returns_text" render={({ field }) => (
                    <FormItem>
                      <FormLabel>Returns / Trust Badge Text</FormLabel>
                      <div className="flex space-x-2">
                        <FormControl><Input {...field} value={field.value ?? ''} placeholder="Easy Returns" disabled={!canEdit} /></FormControl>
                        <Button type="button" onClick={() => handleFieldUpdate('returns_text', field.value)} disabled={!canEdit || (updateFieldMutation.isPending && updateFieldMutation.variables?.field === 'returns_text')} size="icon"><Save className="h-4 w-4" /></Button>
                      </div>
                      <FormMessage />
                    </FormItem>
                  )} />

                  <div>
                    <FormLabel className="mb-2 block">Payment Methods</FormLabel>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      {[
                        { field: 'payment_visa_enabled', label: 'Visa' },
                        { field: 'payment_mastercard_enabled', label: 'Mastercard' },
                        { field: 'payment_apple_pay_enabled', label: 'Apple Pay' },
                        { field: 'payment_google_pay_enabled', label: 'Google Pay' },
                        { field: 'payment_paypal_enabled', label: 'PayPal' },
                        { field: 'payment_cod_enabled', label: 'Cash on Delivery' },
                        { field: 'payment_whish_money_enabled', label: 'Whish Money' },
                      ].map((opt) => (
                        <FormField
                          key={opt.field}
                          control={form.control}
                          // @ts-ignore
                          name={opt.field}
                          render={({ field }) => (
                            <FormItem>
                              <div className="flex items-center justify-between rounded-md border p-3">
                                <div className="text-sm">{opt.label}</div>
                                <FormControl>
                                  <Switch checked={!!field.value} onCheckedChange={(checked) => { field.onChange(checked); handleFieldUpdate(opt.field, checked); }} disabled={!canEdit} />
                                </FormControl>
                              </div>
                            </FormItem>
                          )}
                        />
                      ))}
                    </div>
                  </div>

                  <div className="space-y-4">
                    <FormLabel className="mb-2 block">Payment Page Details (Whish / OMT)</FormLabel>
                    {([
                      { name: 'whish_number', label: 'Whish Money Number', placeholder: '+961 ...' },
                      { name: 'whish_owner_name', label: 'Whish Account Name', placeholder: 'First Last' },
                      { name: 'omt_owner_name', label: 'OMT Full Name (First & Last)', placeholder: 'First Last' },
                      { name: 'omt_number', label: 'OMT Number', placeholder: '+961 ...' },
                      { name: 'payment_instructions', label: 'Extra Payment Instructions', placeholder: 'Optional note shown on the payment page' },
                    ] as const).map((opt) => (
                      <FormField key={opt.name} control={form.control} name={opt.name} render={({ field }) => (
                        <FormItem>
                          <FormLabel>{opt.label}</FormLabel>
                          <div className="flex space-x-2">
                            <FormControl><Input {...field} value={field.value ?? ''} placeholder={opt.placeholder} disabled={!canEdit} /></FormControl>
                            <Button type="button" onClick={() => handleFieldUpdate(opt.name, field.value)} disabled={!canEdit || (updateFieldMutation.isPending && updateFieldMutation.variables?.field === opt.name)} size="icon"><Save className="h-4 w-4" /></Button>
                          </div>
                          <FormMessage />
                        </FormItem>
                      )} />
                    ))}
                  </div>
                </div>
              </AccordionContent>
            </AccordionItem>

            {/* ── Social Media Links ── */}
            <AccordionItem value="social-media" className="border rounded-lg px-4">
              <AccordionTrigger className="justify-center gap-2 text-base font-semibold hover:no-underline">
                Social Media Links
              </AccordionTrigger>
              <AccordionContent>
                <div className="pt-2">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {[
                      { e: 'social_instagram_enabled', u: 'social_instagram_url', label: 'Instagram' },
                      { e: 'social_facebook_enabled', u: 'social_facebook_url', label: 'Facebook' },
                      { e: 'social_tiktok_enabled', u: 'social_tiktok_url', label: 'TikTok' },
                      { e: 'social_youtube_enabled', u: 'social_youtube_url', label: 'YouTube' },
                      { e: 'social_whatsapp_enabled', u: 'social_whatsapp_url', label: 'WhatsApp' },
                      { e: 'social_twitter_enabled', u: 'social_twitter_url', label: 'Twitter/X' },
                    ].map((opt) => (
                      <div key={opt.e} className="grid grid-cols-1 gap-2">
                        <FormField
                          // @ts-ignore
                          name={opt.e}
                          control={form.control}
                          render={({ field }) => (
                            <FormItem>
                              <div className="flex items-center justify-between rounded-md border p-3">
                                <div className="text-sm">{opt.label} Enabled</div>
                                <FormControl>
                                  <Switch checked={!!field.value} onCheckedChange={(checked) => { field.onChange(checked); handleFieldUpdate(opt.e, checked); }} disabled={!canEdit} />
                                </FormControl>
                              </div>
                            </FormItem>
                          )}
                        />
                        <FormField
                          // @ts-ignore
                          name={opt.u}
                          control={form.control}
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>{opt.label} URL</FormLabel>
                              <div className="flex space-x-2">
                                <FormControl>
                                  <Input {...field} value={typeof field.value === 'boolean' ? '' : field.value ?? ''} placeholder={`https://${opt.label.toLowerCase()}.com/yourhandle`} disabled={!canEdit} />
                                </FormControl>
                                <Button type="button" onClick={() => handleFieldUpdate(opt.u, field.value)} disabled={!canEdit || (updateFieldMutation.isPending && updateFieldMutation.variables?.field === opt.u)} size="icon"><Save className="h-4 w-4" /></Button>
                              </div>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                    ))}
                  </div>
                </div>
              </AccordionContent>
            </AccordionItem>

            {/* ── Footer ── */}
            <AccordionItem value="footer" className="border rounded-lg px-4">
              <AccordionTrigger className="justify-center gap-2 text-base font-semibold hover:no-underline">
                Footer
              </AccordionTrigger>
              <AccordionContent>
                <div className="pt-2">
                  <FormField control={form.control} name="footer_copyright" render={({ field }) => (
                    <FormItem>
                      <FormLabel>Footer Copyright</FormLabel>
                      <div className="flex space-x-2">
                        <FormControl><Input {...field} placeholder="© 2026 Your Store. All rights reserved." disabled={!canEdit} /></FormControl>
                        <Button type="button" onClick={() => handleFieldUpdate('footer_copyright', field.value)} disabled={!canEdit || (updateFieldMutation.isPending && updateFieldMutation.variables?.field === 'footer_copyright')} size="icon"><Save className="h-4 w-4" /></Button>
                      </div>
                      <FormMessage />
                    </FormItem>
                  )} />
                </div>
              </AccordionContent>
            </AccordionItem>

          </Accordion>
        </Form>
      </CardContent>
    </Card>
  );
};

export default SiteSettingsAdmin;
