import React, { useEffect, useMemo, useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/lib/supabase';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/components/ui/use-toast';
import { Download, ArrowUpRight, ArrowDownRight, Plus, Trash, Edit3, DollarSign, Users, ShoppingCart, TrendingUp } from 'lucide-react';
import { ChartContainer, ChartLegend, ChartLegendContent, ChartTooltip, ChartTooltipContent } from '@/components/ui/chart';
import * as Recharts from 'recharts';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';

type TimeRange = 'today'|'7d'|'30d'|'3m'|'12m'|'custom';

function startOfRange(range: TimeRange): Date {
  const now = new Date();
  const d = new Date(now);
  if (range === 'today') {
    d.setHours(0,0,0,0);
  } else if (range === '7d') {
    d.setDate(d.getDate() - 7);
  } else if (range === '30d') {
    d.setDate(d.getDate() - 30);
  } else if (range === '3m') {
    d.setMonth(d.getMonth() - 3);
  } else if (range === '12m') {
    d.setFullYear(d.getFullYear() - 1);
  } else {
    d.setMonth(d.getMonth() - 1);
  }
  return d;
}

function toDateStr(d: Date) {
  return d.toISOString();
}

function pctChange(curr: number, prev: number) {
  if (!isFinite(prev) || prev === 0) return curr > 0 ? 100 : 0;
  return Math.round(((curr - prev) / Math.abs(prev)) * 1000)/10;
}

const categories = ['Advertising','Product Cost','Shipping','Platform Fees','Payment Processing Fees','Other'] as const;

const DashboardAdmin: React.FC = () => {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [range, setRange] = useState<TimeRange>(() => (localStorage.getItem('dash_range') as TimeRange) || '30d');
  const [customFrom, setCustomFrom] = useState<string>('');
  const [customTo, setCustomTo] = useState<string>('');
  const [showWidget, setShowWidget] = useState<Record<string, boolean>>(() => {
    try { return JSON.parse(localStorage.getItem('dash_widgets') || '{}') } catch { return {} }
  });
  const savePrefs = () => {
    localStorage.setItem('dash_range', range);
    localStorage.setItem('dash_widgets', JSON.stringify(showWidget));
  };
  useEffect(savePrefs, [range, showWidget]);

  const dateFrom = useMemo(() => range === 'custom' && customFrom ? new Date(customFrom) : startOfRange(range), [range, customFrom]);
  const dateTo = useMemo(() => range === 'custom' && customTo ? new Date(customTo) : new Date(), [range, customTo]);

  const { data: orders = [] } = useQuery({
    queryKey: ['dash-orders', range, customFrom, customTo],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('orders')
        .select('*')
        .gte('created_at', toDateStr(dateFrom))
        .lte('created_at', toDateStr(dateTo))
        .order('created_at', { ascending: true });
      if (error) return [];
      return data || [];
    }
  });

  const { data: prevOrders = [] } = useQuery({
    queryKey: ['dash-orders-prev', range, customFrom, customTo],
    queryFn: async () => {
      const from = new Date(dateFrom);
      const to = new Date(dateTo);
      const spanMs = to.getTime() - from.getTime();
      const prevFrom = new Date(from.getTime() - spanMs);
      const prevTo = new Date(from);
      const { data, error } = await supabase
        .from('orders')
        .select('*')
        .gte('created_at', toDateStr(prevFrom))
        .lt('created_at', toDateStr(prevTo))
        .order('created_at', { ascending: true });
      if (error) return [];
      return data || [];
    }
  });

  const { data: expenses = [] , refetch: refetchExpenses } = useQuery({
    queryKey: ['dash-expenses', range, customFrom, customTo],
    queryFn: async () => {
      try {
        const { data, error } = await supabase
          .from('expenses')
          .select('*')
          .gte('date', toDateStr(dateFrom))
          .lte('date', toDateStr(dateTo))
          .order('date', { ascending: true });
        if (error) return [];
        return data || [];
      } catch {
        return [];
      }
    }
  });

  const revenue = useMemo(() => (orders as any[]).filter(o => !['cancelled','refunded'].includes((o.status||'').toLowerCase())).reduce((s,o)=>s+(o.total_price||0),0), [orders]);
  const prevRevenue = useMemo(() => (prevOrders as any[]).filter(o => !['cancelled','refunded'].includes((o.status||'').toLowerCase())).reduce((s,o)=>s+(o.total_price||0),0), [prevOrders]);
  const expenseTotal = useMemo(() => (expenses as any[]).reduce((s,e)=>s+(e.amount||0),0), [expenses]);
  const profit = Math.max(0, revenue - expenseTotal);
  const prevProfit = Math.max(0, prevRevenue - 0);

  const totalOrders = (orders as any[]).length;
  const prevOrdersCount = (prevOrders as any[]).length;
  const avgOrderValue = totalOrders ? Math.round((revenue / totalOrders)*100)/100 : 0;

  const customersByEmail = useMemo(() => {
    const set = new Map<string, number>();
    (orders as any[]).forEach(o => {
      const k = o.customer_email || o.user_id || '';
      if (!k) return;
      set.set(k, (set.get(k)||0) + (o.total_price||0));
    });
    return set;
  }, [orders]);
  const totalCustomers = customersByEmail.size;
  const returningCustomers = Array.from(customersByEmail.values()).filter(()=>true).length - Array.from(customersByEmail.entries()).filter(([_,v])=>v>0).length < 0 ? 0 : Array.from(customersByEmail.values()).filter(()=>true).length - Array.from(customersByEmail.entries()).filter(()=>true).length;
  const newCustomers = totalCustomers - Math.max(0, returningCustomers);
  const { data: visitsCount = 0 } = useQuery({
    queryKey: ['dash-visits', range, customFrom, customTo],
    queryFn: async () => {
      try {
        const { count, error } = await supabase
          .from('site_visits')
          .select('*', { count: 'exact', head: true })
          .gte('created_at', toDateStr(dateFrom))
          .lte('created_at', toDateStr(dateTo));
        if (error) return 0;
        return count || 0;
      } catch { return 0; }
    }
  });
  const { data: abandonedCount = 0 } = useQuery({
    queryKey: ['dash-abandoned', range, customFrom, customTo],
    queryFn: async () => {
      try {
        const { count, error } = await supabase
          .from('abandoned_carts')
          .select('*', { count: 'exact', head: true })
          .gte('updated_at', toDateStr(dateFrom))
          .lte('updated_at', toDateStr(dateTo));
        if (error) return 0;
        return count || 0;
      } catch { return 0; }
    }
  });
  const conversionRate = visitsCount ? Math.round((totalOrders / visitsCount) * 1000)/10 : 0;

  const series = useMemo(() => {
    const byDate = new Map<string, {date: string, revenue: number, orders: number}>();
    (orders as any[]).forEach(o => {
      const d = new Date(o.created_at);
      const key = d.toISOString().slice(0,10);
      const rec = byDate.get(key) || { date: key, revenue: 0, orders: 0 };
      rec.revenue += o.total_price || 0;
      rec.orders += 1;
      byDate.set(key, rec);
    });
    (expenses as any[]).forEach(e => {
      const key = (e.date || '').slice(0,10);
      const rec = byDate.get(key) || { date: key, revenue: 0, orders: 0 };
      byDate.set(key, rec);
    });
    const data = Array.from(byDate.values()).sort((a,b)=>a.date.localeCompare(b.date));
    const withProfit = data.map(d => {
      const dayExpenses = (expenses as any[]).filter(e => (e.date||'').startsWith(d.date)).reduce((s,e)=>s+(e.amount||0),0);
      return { ...d, profit: Math.max(0, d.revenue - dayExpenses) };
    });
    return withProfit;
  }, [orders, expenses]);

  const { data: topProducts = [] } = useQuery({
    queryKey: ['dash-top-products', range, customFrom, customTo],
    queryFn: async () => {
      const { data: items, error } = await supabase
        .from('order_items')
        .select('product_id, quantity, price, created_at, variant_data')
        .gte('created_at', toDateStr(dateFrom))
        .lte('created_at', toDateStr(dateTo));
      if (error || !items) return [];
      const grouped: Record<string, {qty: number, revenue: number, product_id: string, variant_name: string}> = {};
      items.forEach(it => {
        const pid = it.product_id || 'unknown';
        const vd = it.variant_data as any;
        const variantName = vd?.variant_name || vd?.name || '';
        const key = `${pid}::${variantName}`;
        if (!grouped[key]) grouped[key] = { qty: 0, revenue: 0, product_id: pid, variant_name: variantName };
        grouped[key].qty += it.quantity || 0;
        grouped[key].revenue += (it.price || 0) * (it.quantity || 0);
      });
      const entries = Object.values(grouped);
      entries.sort((a,b)=>b.revenue-a.revenue);
      const top = entries.slice(0,8);

      // Fetch product names
      const productIds = [...new Set(top.map(e => e.product_id))];
      const { data: products } = await supabase
        .from('products')
        .select('id, name')
        .in('id', productIds);
      const nameMap = new Map((products || []).map(p => [p.id, p.name]));

      return top.map(e => ({
        ...e,
        label: nameMap.get(e.product_id)
          ? (e.variant_name ? `${nameMap.get(e.product_id)} – ${e.variant_name}` : nameMap.get(e.product_id)!)
          : (e.variant_name ? `Unknown Product – ${e.variant_name}` : 'Unknown Product')
      }));
    }
  });

  const [expenseEditing, setExpenseEditing] = useState<any|null>(null);
  const expenseSave = useMutation({
    mutationFn: async (payload: any) => {
      try {
        const { data, error } = await supabase
          .from('expenses')
          .upsert(payload)
          .select()
          .single();
        if (error) throw error;
        return data;
      } catch (e: any) {
        throw new Error(e.message || 'Failed to save expense');
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['dash-expenses'] });
      refetchExpenses();
      setExpenseEditing(null);
      toast({ title: 'Saved', description: 'Expense saved' });
    },
    onError: (e: any) => toast({ variant: 'destructive', title: 'Error', description: e.message })
  });
  const expenseDelete = useMutation({
    mutationFn: async (id: number) => {
      try {
        const { error } = await supabase.from('expenses').delete().eq('id', id);
        if (error) throw error;
      } catch (e: any) {
        throw new Error(e.message || 'Failed to delete expense');
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['dash-expenses'] });
      refetchExpenses();
      toast({ title: 'Deleted', description: 'Expense removed' });
    },
    onError: (e: any) => toast({ variant: 'destructive', title: 'Error', description: e.message })
  });

  function exportCSV(filename: string, rows: any[]) {
    const cols = Array.from(new Set(rows.flatMap(r => Object.keys(r))));
    const csv = [cols.join(',')].concat(rows.map(r => cols.map(c => JSON.stringify(r[c] ?? '')).join(','))).join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename.endsWith('.csv') ? filename : `${filename}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }

  // Coupon KPI queries
  const { data: couponUsages = [] } = useQuery({
    queryKey: ['dash-coupon-usages', range, customFrom, customTo],
    queryFn: async () => {
      try {
        const { data, error } = await supabase
          .from('coupon_usages')
          .select('*, orders:order_id(total_price, status)')
          .gte('created_at', toDateStr(dateFrom))
          .lte('created_at', toDateStr(dateTo));
        if (error) return [];
        return data || [];
      } catch { return []; }
    }
  });

  const couponStats = useMemo(() => {
    const usages = couponUsages as any[];
    const completedUsages = usages.filter(u => {
      const status = u.orders?.status || '';
      return !['cancelled', 'refunded'].includes(status.toLowerCase());
    });
    const totalConversions = completedUsages.length;
    const totalRevenueImpact = completedUsages.reduce((s: number, u: any) => s + (u.orders?.total_price || 0), 0);
    const totalDiscountValue = completedUsages.reduce((s: number, u: any) => s + (u.discount_applied || 0), 0);
    const couponAOV = totalConversions > 0 ? Math.round((totalRevenueImpact / totalConversions) * 100) / 100 : 0;

    // Non-coupon AOV: orders in range that don't have a coupon usage
    const couponOrderIds = new Set(completedUsages.map((u: any) => u.order_id).filter(Boolean));
    const nonCouponOrders = (orders as any[]).filter(o =>
      !['cancelled', 'refunded'].includes((o.status || '').toLowerCase()) && !couponOrderIds.has(o.id)
    );
    const nonCouponAOV = nonCouponOrders.length > 0
      ? Math.round((nonCouponOrders.reduce((s: number, o: any) => s + (o.total_price || 0), 0) / nonCouponOrders.length) * 100) / 100
      : 0;

    return { totalConversions, totalRevenueImpact, totalDiscountValue, couponAOV, nonCouponAOV };
  }, [couponUsages, orders]);

  const metricCards = [
    { label: 'Total Revenue', value: revenue, delta: pctChange(revenue, prevRevenue), icon: DollarSign },
    { label: 'Total Profit', value: profit, delta: pctChange(profit, prevProfit), icon: TrendingUp },
    { label: 'Total Expenses', value: expenseTotal, delta: pctChange(expenseTotal, 0), icon: DollarSign },
    { label: 'Net Profit', value: profit, delta: pctChange(profit, prevProfit), icon: TrendingUp },
    { label: 'Total Orders', value: totalOrders, delta: pctChange(totalOrders, prevOrdersCount), icon: ShoppingCart },
    { label: 'Average Order Value', value: avgOrderValue, delta: pctChange(avgOrderValue, 0), icon: DollarSign },
    { label: 'Conversion Rate', value: conversionRate, delta: pctChange(conversionRate, 0), icon: TrendingUp },
    { label: 'Total Customers', value: totalCustomers, delta: pctChange(totalCustomers, 0), icon: Users },
    { label: 'Returning Customers', value: returningCustomers, delta: pctChange(returningCustomers, 0), icon: Users },
    { label: 'New Customers', value: newCustomers, delta: pctChange(newCustomers, 0), icon: Users },
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center gap-3">
        <Select value={range} onValueChange={(v)=>setRange(v as TimeRange)}>
          <SelectTrigger className="w-[180px]"><SelectValue placeholder="Range" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="today">Today</SelectItem>
            <SelectItem value="7d">Last 7 days</SelectItem>
            <SelectItem value="30d">Last 30 days</SelectItem>
            <SelectItem value="3m">Last 3 months</SelectItem>
            <SelectItem value="12m">Last 12 months</SelectItem>
            <SelectItem value="custom">Custom</SelectItem>
          </SelectContent>
        </Select>
        {range === 'custom' && (
          <>
            <Input type="date" value={customFrom} onChange={(e)=>setCustomFrom(e.target.value)} />
            <Input type="date" value={customTo} onChange={(e)=>setCustomTo(e.target.value)} />
          </>
        )}
        <div className="ml-auto flex items-center gap-2">
          <Button variant="outline" onClick={()=>exportCSV('sales-report', orders as any[])}>Export Sales (CSV)</Button>
          <Button variant="outline" onClick={()=>exportCSV('expense-report', expenses as any[])}>Export Expenses (CSV)</Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        {metricCards.map((m) => (
          <Card key={m.label}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">{m.label}</CardTitle>
              <m.icon className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{typeof m.value === 'number' ? m.value.toLocaleString() : m.value}</div>
              <div className={`text-xs mt-1 flex items-center gap-1 ${m.delta >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                {m.delta >= 0 ? <ArrowUpRight className="h-3 w-3" /> : <ArrowDownRight className="h-3 w-3" />}
                {isFinite(m.delta) ? `${m.delta}%` : '—'}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Coupon KPI Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Coupon Conversions</CardTitle>
            <ShoppingCart className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{couponStats.totalConversions}</div>
            <p className="text-xs text-muted-foreground mt-1">Orders completed with a coupon</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Coupon Revenue Impact</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${couponStats.totalRevenueImpact.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground mt-1">Gross sales via coupon codes</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Discount Given</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${couponStats.totalDiscountValue.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground mt-1">Sum of all discounts granted</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">AOV Comparison</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${couponStats.couponAOV}</div>
            <p className="text-xs text-muted-foreground mt-1">
              Coupon AOV vs ${couponStats.nonCouponAOV} non-coupon
            </p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Revenue & Profit</CardTitle>
          <div className="flex items-center gap-2">
            <span className="text-xs text-muted-foreground">Show Chart</span>
            <Switch checked={showWidget.revenueChart !== false} onCheckedChange={(v) => setShowWidget(prev => ({ ...prev, revenueChart: v }))} />
          </div>
        </CardHeader>
        {showWidget.revenueChart !== false && (
        <CardContent>
          <ChartContainer
            config={{
              revenue: { label: 'Revenue' },
              profit: { label: 'Profit' },
              orders: { label: 'Orders' },
            }}
            className="w-full h-[360px]"
          >
            <Recharts.ComposedChart data={series}>
              <Recharts.CartesianGrid strokeDasharray="3 3" />
              <Recharts.XAxis dataKey="date" />
              <Recharts.YAxis />
              <ChartTooltip content={<ChartTooltipContent />} />
              <ChartLegend content={<ChartLegendContent />} />
              <Recharts.Line type="monotone" dataKey="revenue" stroke="var(--color-revenue, hsl(var(--primary)))" dot={false} />
              <Recharts.Line type="monotone" dataKey="profit" stroke="var(--color-profit, hsl(var(--muted-foreground)))" dot={false} />
              <Recharts.Bar dataKey="orders" fill="var(--color-orders, hsl(var(--accent)))" opacity={0.3} />
            </Recharts.ComposedChart>
          </ChartContainer>
        </CardContent>
        )}
      </Card>

      <Tabs defaultValue="sales" className="w-full">
        <TabsList className="mb-4">
          <TabsTrigger value="sales">Sales Analytics</TabsTrigger>
          <TabsTrigger value="customers">Customer Analytics</TabsTrigger>
          <TabsTrigger value="traffic">Traffic & Conversion</TabsTrigger>
          <TabsTrigger value="orders">Order Analytics</TabsTrigger>
          <TabsTrigger value="inventory">Inventory Insights</TabsTrigger>
          <TabsTrigger value="marketing">Marketing Performance</TabsTrigger>
          <TabsTrigger value="expenses">Expenses</TabsTrigger>
        </TabsList>
        <TabsContent value="sales" className="space-y-4">
          <Card>
            <CardHeader><CardTitle>Top Selling Products</CardTitle></CardHeader>
            <CardContent className="space-y-2">
              {(topProducts as any[]).length === 0 ? <div>No sales yet.</div> : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {(topProducts as any[]).map(p => (
                    <div key={p.product_id} className="flex items-center justify-between rounded-md border p-3">
                      <div className="text-sm font-medium">{p.label}</div>
                      <div className="text-xs text-muted-foreground">Qty {p.qty} • ${p.revenue.toFixed(2)}</div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="customers" className="space-y-4">
          <Card>
            <CardHeader><CardTitle>Customers Overview</CardTitle></CardHeader>
            <CardContent className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="rounded-md border p-4"><div className="text-sm text-muted-foreground">Total Customers</div><div className="text-2xl font-semibold">{totalCustomers}</div></div>
              <div className="rounded-md border p-4"><div className="text-sm text-muted-foreground">New Customers</div><div className="text-2xl font-semibold">{newCustomers}</div></div>
              <div className="rounded-md border p-4"><div className="text-sm text-muted-foreground">Returning Customers</div><div className="text-2xl font-semibold">{returningCustomers}</div></div>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="traffic" className="space-y-4">
          <Card>
            <CardHeader><CardTitle>Traffic & Conversion</CardTitle></CardHeader>
            <CardContent className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="rounded-md border p-4"><div className="text-sm text-muted-foreground">Visitors</div><div className="text-2xl font-semibold">{visitsCount}</div></div>
              <div className="rounded-md border p-4"><div className="text-sm text-muted-foreground">Conversion Rate</div><div className="text-2xl font-semibold">{conversionRate}%</div></div>
              <div className="rounded-md border p-4"><div className="text-sm text-muted-foreground">Abandoned Carts</div><div className="text-2xl font-semibold">{abandonedCount}</div></div>
              <div className="rounded-md border p-4"><div className="text-sm text-muted-foreground">Checkout Completion</div><div className="text-2xl font-semibold">{visitsCount ? Math.round(((totalOrders)/(abandonedCount+totalOrders))*1000)/10 : 0}%</div></div>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="orders" className="space-y-4">
          <Card>
            <CardHeader><CardTitle>Orders Summary</CardTitle></CardHeader>
            <CardContent className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="rounded-md border p-4"><div className="text-sm text-muted-foreground">Orders (range)</div><div className="text-2xl font-semibold">{totalOrders}</div></div>
              <div className="rounded-md border p-4"><div className="text-sm text-muted-foreground">Orders Today</div><div className="text-2xl font-semibold">{(orders as any[]).filter(o => (o.created_at||'').slice(0,10) === new Date().toISOString().slice(0,10)).length}</div></div>
              <div className="rounded-md border p-4"><div className="text-sm text-muted-foreground">Pending</div><div className="text-2xl font-semibold">{(orders as any[]).filter(o => (o.status||'').toLowerCase() === 'pending').length}</div></div>
              <div className="rounded-md border p-4"><div className="text-sm text-muted-foreground">Refunded</div><div className="text-2xl font-semibold">{(orders as any[]).filter(o => (o.status||'').toLowerCase() === 'refunded').length}</div></div>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="inventory" className="space-y-4">
          <Card>
            <CardHeader><CardTitle>Inventory Alerts</CardTitle></CardHeader>
            <CardContent>No inventory data available in this build.</CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="marketing" className="space-y-4">
          <Card>
            <CardHeader><CardTitle>Marketing Performance</CardTitle></CardHeader>
            <CardContent>Connect channels to see detailed attribution.</CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="expenses" className="space-y-4">
          <Card>
            <CardHeader className="flex items-center justify-between">
              <CardTitle>Expenses</CardTitle>
              <Button onClick={() => setExpenseEditing({ amount: 0, category: 'Advertising', note: '', date: new Date().toISOString().slice(0,10) })}><Plus className="h-4 w-4 mr-2" /> Add Expense</Button>
            </CardHeader>
            <CardContent className="space-y-4">
              {expenseEditing && (
                <div className="grid grid-cols-1 md:grid-cols-5 gap-3 p-3 border rounded-md">
                  <Input type="number" placeholder="Amount" value={expenseEditing.amount} onChange={(e)=>setExpenseEditing({ ...expenseEditing, amount: Number(e.target.value) })} />
                  <Select value={expenseEditing.category} onValueChange={(v)=>setExpenseEditing({ ...expenseEditing, category: v })}>
                    <SelectTrigger><SelectValue placeholder="Category" /></SelectTrigger>
                    <SelectContent>
                      {categories.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                    </SelectContent>
                  </Select>
                  <Input type="date" value={(expenseEditing.date||'').slice(0,10)} onChange={(e)=>setExpenseEditing({ ...expenseEditing, date: e.target.value })} />
                  <Input placeholder="Note" value={expenseEditing.note} onChange={(e)=>setExpenseEditing({ ...expenseEditing, note: e.target.value })} />
                  <div className="flex items-center gap-2">
                    <Button onClick={() => expenseSave.mutate(expenseEditing)}>Save</Button>
                    <Button variant="outline" onClick={() => setExpenseEditing(null)}>Cancel</Button>
                  </div>
                </div>
              )}
              <div className="space-y-2">
                {(expenses as any[]).length === 0 ? <div className="text-sm text-muted-foreground">No expenses in range.</div> : (
                  (expenses as any[]).map((e: any) => (
                    <div key={e.id} className="grid grid-cols-1 md:grid-cols-6 gap-3 items-center border rounded-md p-3">
                      <div>${(e.amount||0).toFixed(2)}</div>
                      <div>{e.category}</div>
                      <div>{(e.date||'').slice(0,10)}</div>
                      <div className="col-span-2 text-sm text-muted-foreground truncate">{e.note || ''}</div>
                      <div className="flex gap-2 justify-end">
                        <Button size="sm" variant="outline" onClick={()=>setExpenseEditing(e)}><Edit3 className="h-4 w-4" /></Button>
                        <Button size="sm" variant="destructive" onClick={()=>e.id && expenseDelete.mutate(e.id)}><Trash className="h-4 w-4" /></Button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <Card>
        <CardHeader><CardTitle>Quick Actions</CardTitle></CardHeader>
        <CardContent className="flex flex-wrap gap-2">
          <Button asChild><a href="#/admin?tab=products">Add Product</a></Button>
          <Button variant="outline" asChild><a href="#/admin?tab=orders">View Orders</a></Button>
          <Button variant="outline" asChild onClick={() => setExpenseEditing({ amount: 0, category: 'Advertising', note: '', date: new Date().toISOString().slice(0,10) })}>Add Expense</Button>
          <Button variant="outline" asChild><a href="#/customers">View Customers</a></Button>
        </CardContent>
      </Card>
    </div>
  );
};

export default DashboardAdmin;
