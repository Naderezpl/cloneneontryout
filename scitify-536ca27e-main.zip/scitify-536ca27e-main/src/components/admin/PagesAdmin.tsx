import React, { useMemo, useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { listPages, upsertPage, CmsPage } from '@/api/pages';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import ImageUploader from '@/components/ImageUploader';
import { Save, Plus } from 'lucide-react';

const predefinedSlugs = [
  { slug: 'home', title: 'Home' },
  { slug: 'shop', title: 'Shop All' },
  { slug: 'about', title: 'About Us' },
  { slug: 'shipping-policy', title: 'Shipping Policy' },
  { slug: 'care-instructions', title: 'Care Instructions' },
  { slug: 'privacy-policy', title: 'Privacy Policy' },
  { slug: 'terms-of-service', title: 'Terms of Service' },
];

const PagesAdmin = () => {
  const qc = useQueryClient();
  const [activeSlug, setActiveSlug] = useState(predefinedSlugs[0].slug);

  const { data: pages = [] } = useQuery({
    queryKey: ['pages'],
    queryFn: listPages,
  });

  const currentPage: CmsPage = useMemo(() => {
    const found = pages.find(p => p.slug === activeSlug);
    return found || {
      slug: activeSlug,
      title: predefinedSlugs.find(p => p.slug === activeSlug)?.title || activeSlug,
      content_html: '',
      meta_title: '',
      meta_description: '',
      enabled: true,
      hero_image_url: null,
    };
  }, [pages, activeSlug]);

  const mutation = useMutation({
    mutationFn: upsertPage,
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['pages'] });
    }
  });

  const [form, setForm] = useState<CmsPage>(currentPage);

  React.useEffect(() => {
    setForm(currentPage);
  }, [currentPage]);

  const handleSave = () => {
    mutation.mutate(form);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Pages</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex flex-wrap gap-2 mb-6">
          {predefinedSlugs.map(p => (
            <Button
              key={p.slug}
              variant={activeSlug === p.slug ? 'default' : 'outline'}
              onClick={() => setActiveSlug(p.slug)}
              size="sm"
            >
              {p.title}
            </Button>
          ))}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <div>
              <label className="text-sm block mb-1">Title</label>
              <Input
                value={form.title}
                onChange={(e) => setForm({ ...form, title: e.target.value })}
                placeholder="Page title"
              />
            </div>
            <div>
              <label className="text-sm block mb-1">Meta Title</label>
              <Input
                value={form.meta_title || ''}
                onChange={(e) => setForm({ ...form, meta_title: e.target.value })}
                placeholder="Meta title"
              />
            </div>
            <div>
              <label className="text-sm block mb-1">Meta Description</label>
              <Textarea
                value={form.meta_description || ''}
                onChange={(e) => setForm({ ...form, meta_description: e.target.value })}
                placeholder="Meta description"
              />
            </div>
            <div className="flex items-center justify-between rounded-md border p-3">
              <div className="text-sm">Enabled</div>
              <Switch
                checked={!!form.enabled}
                onCheckedChange={(checked) => setForm({ ...form, enabled: checked })}
              />
            </div>
            <div>
              <label className="text-sm block mb-1">Hero Image</label>
              <ImageUploader
                onImageUploaded={(url) => setForm({ ...form, hero_image_url: url })}
                defaultImageUrl={form.hero_image_url || undefined}
                bucketName="imageassets"
                folderPath="pages"
                aspectRatio={16 / 9}
                uploadId="page-hero-image-upload"
                recommendedSize="1600 × 900 px"
              />
            </div>
          </div>
          <div>
            <label className="text-sm block mb-1">Content (HTML)</label>
            <Textarea
              className="min-h-80"
              value={form.content_html}
              onChange={(e) => setForm({ ...form, content_html: e.target.value })}
              placeholder="HTML content"
            />
          </div>
        </div>
        <div className="mt-6 flex gap-2">
          <Button onClick={handleSave} disabled={mutation.isPending}>
            <Save className="h-4 w-4 mr-2" />
            Save Page
          </Button>
          <Button variant="outline" onClick={() => setForm(currentPage)}>
            Reset
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default PagesAdmin;
