import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/lib/supabase';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Trash2, UserPlus, Shield, ShieldOff } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';

interface AdminUser {
  id: string;
  user_id: string;
  role: string;
  created_at: string;
  email?: string;
}

const AdminUsersAdmin = () => {
  const [newAdminEmail, setNewAdminEmail] = useState('');
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: adminUsers = [], isLoading } = useQuery({
    queryKey: ['admin-users'],
    queryFn: async () => {
      const { data: roles, error } = await supabase
        .from('user_roles')
        .select('*')
        .eq('role', 'admin');

      if (error) throw error;

      // Get emails from user_profiles
      const userIds = (roles || []).map(r => r.user_id);
      if (userIds.length === 0) return [];

      const { data: profiles } = await supabase
        .from('user_profiles')
        .select('user_id, email')
        .in('user_id', userIds);

      const profileMap = new Map((profiles || []).map(p => [p.user_id, p.email]));

      return (roles || []).map(r => ({
        ...r,
        email: profileMap.get(r.user_id) || 'Unknown',
      })) as AdminUser[];
    },
  });

  const addAdmin = useMutation({
    mutationFn: async (email: string) => {
      // Find user by email in user_profiles
      const { data: profile, error: profileError } = await supabase
        .from('user_profiles')
        .select('user_id')
        .eq('email', email.trim().toLowerCase())
        .single();

      if (profileError || !profile) {
        throw new Error('No user found with that email. The user must sign up first.');
      }

      // Check if already admin
      const { data: existing } = await supabase
        .from('user_roles')
        .select('id')
        .eq('user_id', profile.user_id)
        .eq('role', 'admin')
        .single();

      if (existing) {
        throw new Error('This user is already an admin.');
      }

      const { error } = await supabase
        .from('user_roles')
        .insert({ user_id: profile.user_id, role: 'admin' });

      if (error) throw error;
    },
    onSuccess: () => {
      toast({ title: 'Admin added successfully' });
      setNewAdminEmail('');
      queryClient.invalidateQueries({ queryKey: ['admin-users'] });
    },
    onError: (error: Error) => {
      toast({ variant: 'destructive', title: 'Error', description: error.message });
    },
  });

  const removeAdmin = useMutation({
    mutationFn: async (roleId: string) => {
      const { error } = await supabase
        .from('user_roles')
        .delete()
        .eq('id', roleId);

      if (error) throw error;
    },
    onSuccess: () => {
      toast({ title: 'Admin removed successfully' });
      queryClient.invalidateQueries({ queryKey: ['admin-users'] });
    },
    onError: (error: Error) => {
      toast({ variant: 'destructive', title: 'Error', description: error.message });
    },
  });

  const handleAddAdmin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAdminEmail.trim()) return;
    addAdmin.mutate(newAdminEmail);
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold mb-2">Admin Management</h2>
        <p className="text-sm text-muted-foreground">
          Add or remove admin access by email. Users must have an account before being granted admin access.
        </p>
      </div>

      <Card className="p-4">
        <form onSubmit={handleAddAdmin} className="flex gap-2">
          <Input
            type="email"
            placeholder="Enter user email to grant admin access..."
            value={newAdminEmail}
            onChange={(e) => setNewAdminEmail(e.target.value)}
            className="flex-1"
          />
          <Button type="submit" disabled={addAdmin.isPending || !newAdminEmail.trim()}>
            <UserPlus className="mr-2 h-4 w-4" />
            {addAdmin.isPending ? 'Adding...' : 'Add Admin'}
          </Button>
        </form>
      </Card>

      <div className="space-y-2">
        <h3 className="text-sm font-medium text-muted-foreground uppercase tracking-wide">
          Current Admins ({adminUsers.length})
        </h3>

        {isLoading ? (
          <p className="text-sm text-muted-foreground">Loading...</p>
        ) : adminUsers.length === 0 ? (
          <Card className="p-6 text-center text-muted-foreground">
            <ShieldOff className="mx-auto mb-2 h-8 w-8" />
            <p>No admins found in the database.</p>
          </Card>
        ) : (
          <div className="space-y-2">
            {adminUsers.map((admin) => (
              <Card key={admin.id} className="p-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Shield className="h-5 w-5 text-primary" />
                  <div>
                    <p className="font-medium">{admin.email}</p>
                    <p className="text-xs text-muted-foreground">
                      Added {new Date(admin.created_at).toLocaleDateString()}
                    </p>
                  </div>
                  <Badge variant="secondary">Admin</Badge>
                </div>

                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button variant="ghost" size="sm" className="text-destructive hover:text-destructive">
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Remove admin access?</AlertDialogTitle>
                      <AlertDialogDescription>
                        This will remove admin privileges from {admin.email}. They will no longer be able to access the admin panel.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                      <AlertDialogAction
                        onClick={() => removeAdmin.mutate(admin.id)}
                        className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                      >
                        Remove
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminUsersAdmin;
