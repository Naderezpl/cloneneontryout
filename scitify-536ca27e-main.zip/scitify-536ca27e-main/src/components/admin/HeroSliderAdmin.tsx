import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/lib/supabase';
import { fetchSiteSettings, updateSiteSettings } from '@/api/settings';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { Checkbox } from '@/components/ui/checkbox';
import { useToast } from '@/components/ui/use-toast';
import ImageUploader from '@/components/ImageUploader';
import MobileCropSelector, { type MobileCropData } from '@/components/admin/MobileCropSelector';
import { Save, Loader2, Trash2, Image, Video, Upload } from 'lucide-react';

const HeroSliderAdmin = () => {
  const { toast } = useToast();
  const [selectedSlides, setSelectedSlides] = useState<Set<number>>(new Set());
  const queryClient = useQueryClient();

  const { data: settings, isLoading } = useQuery({
    queryKey: ['site-settings'],
    queryFn: fetchSiteSettings,
    staleTime: 0,
  });

  const { data: slides = [], isLoading: slidesLoading } = useQuery({
    queryKey: ['homepage-slides'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('homepage_slides')
        .select('*')
        .order('display_order');
      if (error) throw error;
      return data || [];
    },
  });

  const [mediaMode, setMediaMode] = useState<'image' | 'video'>('video');
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [durationSec, setDurationSec] = useState(5);
  const [isVideoUploading, setIsVideoUploading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [videoMobileCrop, setVideoMobileCrop] = useState<MobileCropData | null>(null);

  useEffect(() => {
    if (settings) {
      setMediaMode((settings as any).hero_media_mode === 'image' ? 'image' : 'video');
      setVideoUrl((settings as any).hero_video_url || null);
      setDurationSec(
        (settings as any).hero_slide_duration_ms
          ? Math.round((settings as any).hero_slide_duration_ms / 1000)
          : 5
      );
      setVideoMobileCrop((settings as any).hero_video_mobile_crop || null);
    }
  }, [settings]);

  const handleSave = async () => {
    try {
      setIsSaving(true);
      await updateSiteSettings({
        hero_media_mode: mediaMode,
        hero_video_url: videoUrl,
        hero_slide_duration_ms: durationSec * 1000,
        hero_video_mobile_crop: videoMobileCrop,
      } as any);
      queryClient.invalidateQueries({ queryKey: ['site-settings'] });
      toast({ title: 'Saved', description: 'Hero settings updated.' });
    } catch (e: any) {
      toast({ variant: 'destructive', title: 'Error', description: e.message });
    } finally {
      setIsSaving(false);
    }
  };

  // Slide mutations
  const addSlide = useMutation({
    mutationFn: async (imageUrl: string) => {
      const nextOrder = slides.length;
      const { error } = await supabase.from('homepage_slides').insert({
        image_url: imageUrl,
        title: '',
        display_order: nextOrder,
        is_active: true,
      });
      if (error) throw error;
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['homepage-slides'] }),
  });

  const deleteSlide = useMutation({
    mutationFn: async (id: number) => {
      const { error } = await supabase.from('homepage_slides').delete().eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['homepage-slides'] });
      setSelectedSlides((prev) => { const next = new Set(prev); next.forEach((id) => next.delete(id)); return next; });
    },
  });

  const deleteSelectedSlides = useMutation({
    mutationFn: async (ids: number[]) => {
      const { error } = await supabase.from('homepage_slides').delete().in('id', ids);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['homepage-slides'] });
      setSelectedSlides(new Set());
      toast({ title: 'Deleted', description: 'Selected slides removed.' });
    },
  });

  const deleteAllSlides = useMutation({
    mutationFn: async () => {
      const ids = slides.map((s: any) => s.id);
      if (ids.length === 0) return;
      const { error } = await supabase.from('homepage_slides').delete().in('id', ids);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['homepage-slides'] });
      setSelectedSlides(new Set());
      toast({ title: 'Deleted', description: 'All slides removed.' });
    },
  });

  const updateSlideMobileCrop = useMutation({
    mutationFn: async ({ id, cropData }: { id: number; cropData: MobileCropData }) => {
      const { error } = await supabase
        .from('homepage_slides')
        .update({ mobile_crop_data: cropData } as any)
        .eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['homepage-slides'] });
      queryClient.invalidateQueries({ queryKey: ['homepage-slides-public'] });
      toast({ title: 'Saved', description: 'Mobile crop updated.' });
    },
  });

  const handleVideoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const validTypes = ['video/mp4', 'video/quicktime'];
    if (!validTypes.includes(file.type)) {
      toast({ variant: 'destructive', title: 'Invalid format', description: 'Please upload an MP4 or MOV file.' });
      return;
    }
    if (file.size > 20 * 1024 * 1024) {
      toast({ variant: 'destructive', title: 'File too large', description: 'Video must be under 20MB.' });
      return;
    }

    try {
      setIsVideoUploading(true);
      const ext = file.name.split('.').pop() || 'mp4';
      const fileName = `hero_video_${Date.now()}.${ext}`;
      const { error } = await supabase.storage
        .from('imageassets')
        .upload(`hero/${fileName}`, file, { upsert: true, contentType: file.type });
      if (error) throw error;

      const { data: { publicUrl } } = supabase.storage
        .from('imageassets')
        .getPublicUrl(`hero/${fileName}`);

      setVideoUrl(publicUrl);
      toast({ title: 'Video uploaded', description: 'Hero video uploaded successfully.' });
    } catch (err: any) {
      toast({ variant: 'destructive', title: 'Upload failed', description: err.message });
    } finally {
      setIsVideoUploading(false);
      e.target.value = '';
    }
  };

  if (isLoading) return <div className="flex justify-center p-8"><Loader2 className="animate-spin" /></div>;

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Hero Media Mode</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <RadioGroup
            value={mediaMode}
            onValueChange={(v) => setMediaMode(v as 'image' | 'video')}
            className="flex gap-6"
          >
            <div className="flex items-center gap-2">
              <RadioGroupItem value="image" id="hero-mode-image" />
              <Label htmlFor="hero-mode-image" className="flex items-center gap-1.5 cursor-pointer">
                <Image size={16} /> Image Slider
              </Label>
            </div>
            <div className="flex items-center gap-2">
              <RadioGroupItem value="video" id="hero-mode-video" />
              <Label htmlFor="hero-mode-video" className="flex items-center gap-1.5 cursor-pointer">
                <Video size={16} /> Single Video
              </Label>
            </div>
          </RadioGroup>
        </CardContent>
      </Card>

      {mediaMode === 'image' && (
        <Card>
          <CardHeader>
            <CardTitle>Image Slider Settings</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label>Slide Duration: {durationSec}s</Label>
              <Slider
                min={1}
                max={10}
                step={1}
                value={[durationSec]}
                onValueChange={([v]) => setDurationSec(v)}
              />
              <p className="text-xs text-muted-foreground">Each slide displays for {durationSec} second{durationSec !== 1 ? 's' : ''}</p>
            </div>

            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Label>Slides ({slides.length}/6)</Label>
                {slides.length > 0 && (
                  <div className="flex items-center gap-2">
                    <label className="flex items-center gap-1.5 text-sm cursor-pointer">
                      <Checkbox
                        checked={selectedSlides.size === slides.length && slides.length > 0}
                        onCheckedChange={(checked) => {
                          if (checked) {
                            setSelectedSlides(new Set(slides.map((s: any) => s.id)));
                          } else {
                            setSelectedSlides(new Set());
                          }
                        }}
                      />
                      Select All
                    </label>
                  </div>
                )}
              </div>

              {slides.length > 0 && (selectedSlides.size > 0 || slides.length > 0) && (
                <div className="flex gap-2">
                  {selectedSlides.size > 0 && (
                    <Button
                      variant="destructive"
                      size="sm"
                      disabled={deleteSelectedSlides.isPending}
                      onClick={() => deleteSelectedSlides.mutate(Array.from(selectedSlides))}
                      className="flex items-center gap-1.5"
                    >
                      <Trash2 size={14} />
                      Delete Selected ({selectedSlides.size})
                    </Button>
                  )}
                  <Button
                    variant="outline"
                    size="sm"
                    disabled={deleteAllSlides.isPending || slides.length === 0}
                    onClick={() => deleteAllSlides.mutate()}
                    className="flex items-center gap-1.5 text-destructive border-destructive/30 hover:bg-destructive/10"
                  >
                    <Trash2 size={14} />
                    Delete All
                  </Button>
                </div>
              )}

              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {slides.map((slide: any) => (
                  <div key={slide.id} className={`relative group rounded-lg overflow-hidden border ${selectedSlides.has(slide.id) ? 'border-primary ring-2 ring-primary/30' : 'border-border'}`}>
                    <div className="absolute top-2 left-2 z-10">
                      <Checkbox
                        checked={selectedSlides.has(slide.id)}
                        onCheckedChange={(checked) => {
                          setSelectedSlides((prev) => {
                            const next = new Set(prev);
                            if (checked) next.add(slide.id);
                            else next.delete(slide.id);
                            return next;
                          });
                        }}
                        className="bg-background/80 backdrop-blur-sm"
                      />
                    </div>
                    <div className="aspect-video">
                      <img src={slide.image_url} alt={slide.title || 'Slide'} className="w-full h-full object-cover" />
                    </div>
                    <div className="absolute top-2 right-2 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button
                        onClick={() => deleteSlide.mutate(slide.id)}
                        className="p-1.5 rounded-full bg-destructive text-destructive-foreground"
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>
                    <div className="p-2 border-t border-border bg-background">
                      <MobileCropSelector
                        src={slide.image_url}
                        cropData={slide.mobile_crop_data || null}
                        onChange={(data) => updateSlideMobileCrop.mutate({ id: slide.id, cropData: data })}
                      />
                      {slide.mobile_crop_data && (
                        <span className="text-xs text-muted-foreground ml-2">
                          ✓ Mobile crop set
                        </span>
                      )}
                    </div>
                  </div>
                ))}

                {slides.length < 6 && (
                  <div className="border border-dashed border-border rounded-lg aspect-video flex items-center justify-center">
                    <ImageUploader
                      onImageUploaded={(url) => addSlide.mutate(url)}
                      uploadId="hero-slide-add"
                      aspectRatio={16 / 9}
                      bucketName="imageassets"
                      folderPath="hero"
                      recommendedSize="1920 × 1080 px"
                    />
                  </div>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {mediaMode === 'video' && (
        <Card>
          <CardHeader>
            <CardTitle>Video Background</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground">Upload a single MP4 or MOV video. It will autoplay, loop, and fill the hero section.</p>

            {videoUrl && (
              <div className="space-y-3">
                <div className="relative rounded-lg overflow-hidden border border-border aspect-video max-w-lg">
                  <video src={videoUrl} className="w-full h-full object-cover" muted autoPlay loop playsInline />
                  <button
                    onClick={() => setVideoUrl(null)}
                    className="absolute top-2 right-2 p-1.5 rounded-full bg-destructive text-destructive-foreground"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
                <div className="flex items-center gap-2">
                  <MobileCropSelector
                    src={videoUrl}
                    isVideo
                    cropData={videoMobileCrop}
                    onChange={setVideoMobileCrop}
                  />
                  {videoMobileCrop && (
                    <span className="text-xs text-muted-foreground">✓ Mobile crop set</span>
                  )}
                </div>
              </div>
            )}

            <div>
              <Button
                type="button"
                variant="outline"
                disabled={isVideoUploading}
                onClick={() => document.getElementById('hero-video-upload')?.click()}
                className="flex items-center gap-2"
              >
                <Upload size={16} />
                {isVideoUploading ? 'Uploading…' : 'Upload Video'}
              </Button>
              <input
                id="hero-video-upload"
                type="file"
                accept="video/mp4,video/quicktime"
                onChange={handleVideoUpload}
                className="hidden"
              />
            </div>
          </CardContent>
        </Card>
      )}

      <Button onClick={handleSave} disabled={isSaving} className="flex items-center gap-2">
        {isSaving ? <Loader2 size={16} className="animate-spin" /> : <Save size={16} />}
        Save Hero Settings
      </Button>
    </div>
  );
};

export default HeroSliderAdmin;
