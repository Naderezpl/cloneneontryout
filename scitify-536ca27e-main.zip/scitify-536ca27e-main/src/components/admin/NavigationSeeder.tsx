import React, { useState } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/lib/supabase';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { Loader2 } from 'lucide-react';

const defaultNavItems = [
  { title: 'Home', url: '/', order: 0, is_enabled: true },
  { title: 'Shop', url: '/shop', order: 1, is_enabled: true },
  { title: 'Custom Neon', url: '/custom', order: 2, is_enabled: true },
  { title: 'Inspiration', url: '/inspiration', order: 3, is_enabled: true },
  { title: 'About Us', url: '/about', order: 4, is_enabled: true }
];

const NavigationSeeder = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isSeeding, setIsSeeding] = useState(false);

  const seedNavItems = async () => {
    setIsSeeding(true);
    try {
      // Check if we already have items
      const { data: existingItems } = await supabase
        .from('nav_items')
        .select('*');

      if (existingItems && existingItems.length > 0) {
        toast({
          title: "Navigation items already exist",
          description: "Default navigation items are already in the database.",
        });
        setIsSeeding(false);
        return;
      }

      const now = new Date().toISOString();
      
      // Insert default items
      const { error } = await supabase
        .from('nav_items')
        .insert(defaultNavItems.map(item => ({
          ...item,
          created_at: now,
          updated_at: now
        })));

      if (error) throw error;

      queryClient.invalidateQueries({ queryKey: ['nav-items'] });
      queryClient.invalidateQueries({ queryKey: ['navigation-items'] });

      toast({
        title: "Success!",
        description: "Default navigation items have been added to the database.",
      });
    } catch (error) {
      console.error('Error seeding navigation items:', error);
      toast({
        variant: "destructive",
        title: "Error",
        description: `Failed to seed navigation items: ${(error as Error).message}`,
      });
    } finally {
      setIsSeeding(false);
    }
  };

  return (
    <div className="flex justify-end mb-4">
      <Button 
        variant="outline" 
        onClick={seedNavItems} 
        disabled={isSeeding}
      >
        {isSeeding ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            Seeding navigation items...
          </>
        ) : (
          'Seed Default Navigation Items'
        )}
      </Button>
    </div>
  );
};

export default NavigationSeeder;
