import React, { useMemo, useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { listReviews, upsertReview, deleteReview, Review, analyzeReviewContent, addReviewReply } from '@/api/reviews';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Save, Trash, Plus } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger } from '@/components/ui/dialog';

const ReviewsAdmin: React.FC = () => {
  const { isAdmin, hasDbAdminRole } = useAuth();
  const canEdit = isAdmin || hasDbAdminRole;
  const queryClient = useQueryClient();
  const { data: reviews = [], isLoading } = useQuery({
    queryKey: ['reviews'],
    queryFn: () => listReviews(),
  });

  const [editing, setEditing] = useState<Partial<Review> | null>(null);
  const [filter, setFilter] = useState<'all'|'approved'|'flagged'|'spam'>('all');
  const [replyFor, setReplyFor] = useState<Review | null>(null);
  const [replyText, setReplyText] = useState('');

  const saveMutation = useMutation({
    mutationFn: upsertReview,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['reviews'] });
      setEditing(null);
    }
  });

  const deleteMutation = useMutation({
    mutationFn: deleteReview,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['reviews'] });
    }
  });

  const replyMutation = useMutation({
    mutationFn: async ({ reviewId, text }: { reviewId: number, text: string }) => addReviewReply(reviewId, text),
    onSuccess: () => {
      setReplyFor(null);
      setReplyText('');
    }
  });

  const analytics = useMemo(() => {
    const total = reviews.length;
    const analyses = reviews.map(r => ({ r, a: analyzeReviewContent(r.rating || 5, r.review_text || '') }));
    const spam = analyses.filter(x => x.a.status === 'rejected').length;
    const flagged = analyses.filter(x => x.a.status === 'pending').length;
    const approved = reviews.filter(r => r.enabled).length;
    const avg = (() => {
      const enabled = reviews.filter(r => r.enabled && typeof r.rating === 'number');
      if (enabled.length === 0) return 0;
      return Math.round((enabled.reduce((s, r) => s + (r.rating || 0), 0) / enabled.length) * 10) / 10;
    })();
    return { total, spam, flagged, approved, avg };
  }, [reviews]);

  const filteredReviews = useMemo(() => {
    if (filter === 'all') return reviews;
    return reviews.filter(r => {
      const a = analyzeReviewContent(r.rating || 5, r.review_text || '');
      if (filter === 'spam') return a.status === 'rejected';
      if (filter === 'flagged') return a.status === 'pending';
      if (filter === 'approved') return r.enabled;
      return true;
    });
  }, [filter, reviews]);

  return (
    <Card>
      <CardHeader className="flex items-center justify-between">
        <CardTitle>Reviews</CardTitle>
        <Button onClick={() => setEditing({ reviewer_name: '', rating: 5, review_text: '', enabled: true })} disabled={!canEdit}>
          <Plus className="h-4 w-4 mr-1" /> New Review
        </Button>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="flex flex-wrap items-center gap-3">
          <div className="text-sm px-3 py-2 border rounded-md">Total: {analytics.total}</div>
          <div className="text-sm px-3 py-2 border rounded-md">Approved: {analytics.approved}</div>
          <div className="text-sm px-3 py-2 border rounded-md">Flagged: {analytics.flagged}</div>
          <div className="text-sm px-3 py-2 border rounded-md">Spam: {analytics.spam}</div>
          <div className="text-sm px-3 py-2 border rounded-md">Average: {analytics.avg}</div>
          <div className="ml-auto flex items-center gap-2">
            <Button size="sm" variant={filter==='all'?'default':'outline'} onClick={() => setFilter('all')}>
              All
            </Button>
            <Button size="sm" variant={filter==='approved'?'default':'outline'} onClick={() => setFilter('approved')}>
              Approved
            </Button>
            <Button size="sm" variant={filter==='flagged'?'default':'outline'} onClick={() => setFilter('flagged')}>
              Flagged
            </Button>
            <Button size="sm" variant={filter==='spam'?'default':'outline'} onClick={() => setFilter('spam')}>
              Spam
            </Button>
          </div>
        </div>
        {editing && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 border rounded-md">
            <Input
              placeholder="Reviewer name"
              value={editing.reviewer_name || ''}
              onChange={(e) => setEditing({ ...editing, reviewer_name: e.target.value })}
              disabled={!canEdit}
            />
            <Input
              placeholder="Product ID (optional)"
              value={editing.product_id || ''}
              onChange={(e) => setEditing({ ...editing, product_id: e.target.value })}
              disabled={!canEdit}
            />
            <Textarea
              placeholder="Review text"
              value={editing.review_text || ''}
              onChange={(e) => setEditing({ ...editing, review_text: e.target.value })}
              disabled={!canEdit}
              className="md:col-span-2"
            />
            <div className="flex items-center gap-3">
              <span className="text-sm">Rating</span>
              <Input
                type="number"
                min={1}
                max={5}
                value={editing.rating || 5}
                onChange={(e) => setEditing({ ...editing, rating: Number(e.target.value) })}
                disabled={!canEdit}
                className="w-24"
              />
              <div className="ml-6 flex items-center gap-2">
                <span className="text-sm">Enabled</span>
                <Switch
                  checked={!!editing.enabled}
                  onCheckedChange={(v) => setEditing({ ...editing, enabled: v })}
                  disabled={!canEdit}
                />
              </div>
              <div className="ml-6 flex items-center gap-2">
                <span className="text-sm">Featured</span>
                <Switch
                  checked={!!editing.featured}
                  onCheckedChange={(v) => setEditing({ ...editing, featured: v })}
                  disabled={!canEdit}
                />
              </div>
            </div>
            <div className="md:col-span-2 flex gap-2">
              <Button onClick={() => editing && saveMutation.mutate(editing)} disabled={!canEdit}>
                <Save className="h-4 w-4 mr-1" /> Save
              </Button>
              <Button variant="outline" onClick={() => setEditing(null)}>
                Cancel
              </Button>
            </div>
          </div>
        )}

        <div className="space-y-3">
          {isLoading ? (
            <div>Loading reviews...</div>
          ) : reviews.length === 0 ? (
            <div>No reviews yet.</div>
          ) : (
            filteredReviews.map((r) => {
              const a = analyzeReviewContent(r.rating || 5, r.review_text || '');
              return (
              <div key={r.id} className="p-4 border rounded-md flex items-start gap-4">
                <div className="flex-1 space-y-1">
                  <div className="font-medium">{r.reviewer_name} • {r.rating}/5</div>
                  <div className="text-sm text-muted-foreground">{r.review_text}</div>
                  <div className="text-xs text-muted-foreground">
                    Status: {a.status} • AI score: {Math.round(a.aiScore*100)}
                    • {a.reasons.join(', ')}
                  </div>
                </div>
                <div className="flex flex-col gap-2 items-end">
                  <Switch checked={!!r.enabled} onCheckedChange={(v) => saveMutation.mutate({ ...r, enabled: v })} disabled={!canEdit} />
                  <div className="flex gap-2">
                    <Button size="sm" onClick={() => saveMutation.mutate({ ...r, enabled: true })} disabled={!canEdit}>
                      Approve
                    </Button>
                    <Button size="sm" variant="secondary" onClick={() => saveMutation.mutate({ ...r, enabled: false })} disabled={!canEdit}>
                      Reject
                    </Button>
                    <Dialog open={replyFor?.id === r.id} onOpenChange={(open) => { if (!open) { setReplyFor(null); setReplyText(''); } }}>
                      <DialogTrigger asChild>
                        <Button size="sm" variant="outline" onClick={() => setReplyFor(r)} disabled={!canEdit}>
                          Reply
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Reply to {r.reviewer_name}</DialogTitle>
                        </DialogHeader>
                        <Textarea value={replyText} onChange={(e) => setReplyText(e.target.value)} placeholder="Write your reply" />
                        <DialogFooter>
                          <Button variant="outline" onClick={() => { setReplyFor(null); setReplyText(''); }}>
                            Cancel
                          </Button>
                          <Button onClick={() => r.id && replyText.trim() && replyMutation.mutate({ reviewId: r.id, text: replyText.trim() })}>
                            Send Reply
                          </Button>
                        </DialogFooter>
                      </DialogContent>
                    </Dialog>
                    <Button size="sm" variant="destructive" onClick={() => r.id && deleteMutation.mutate(r.id)} disabled={!canEdit}>
                      <Trash className="h-4 w-4" />
                    </Button>
                  </div>
                  <Button size="sm" variant="outline" onClick={() => setEditing(r)} disabled={!canEdit}>
                    Edit
                  </Button>
                </div>
              </div>
            )})
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default ReviewsAdmin;
