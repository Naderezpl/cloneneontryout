
import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/lib/supabase';
import { Badge } from '@/components/ui/badge';

interface NotificationBadgeProps {
  className?: string;
}

const NotificationBadge = ({ className }: NotificationBadgeProps) => {
  // Fetch unread notifications count - pending orders
  const { data: count = 0, isLoading } = useQuery({
    queryKey: ['unread-notifications'],
    queryFn: async () => {
      console.log('Fetching pending orders count...');
      const { count, error } = await supabase
        .from('orders')
        .select('*', { count: 'exact', head: true })
        .eq('status', 'pending');
      
      if (error) {
        console.error('Error fetching notification count:', error);
        throw new Error(error.message);
      }
      
      console.log('Pending orders count:', count);
      return count || 0;
    },
    // Refetch every minute and when window gains focus
    refetchInterval: 60000,
    refetchOnWindowFocus: true
  });

  if (isLoading || count === 0) {
    return null;
  }

  return (
    <Badge variant="default" className={`absolute -top-2 -right-2 px-1.5 bg-primary text-primary-foreground border-transparent ${className || ''}`}>
      {count > 99 ? '99+' : count}
    </Badge>
  );
};

export default NotificationBadge;
