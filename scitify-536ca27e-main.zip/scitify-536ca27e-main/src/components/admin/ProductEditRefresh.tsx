
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/components/ui/use-toast';

// This is a custom hook to handle variant deletion with automatic refresh
export const useVariantDeletion = (productId: string, onSuccess?: () => void) => {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const deleteVariantMutation = useMutation({
    mutationFn: async (variantId: string) => {
      // First delete any images associated with this variant
      const { error: imageError } = await supabase
        .from('product_images')
        .delete()
        .eq('variant_id', variantId);
      
      if (imageError) {
        console.error('Error deleting variant images:', imageError);
        throw new Error(`Failed to delete variant images: ${imageError.message}`);
      }

      // Then delete the variant itself
      const { error } = await supabase
        .from('product_variants')
        .delete()
        .eq('id', variantId);
      
      if (error) {
        throw new Error(`Failed to delete variant: ${error.message}`);
      }

      return variantId;
    },
    onSuccess: (_data, _variables) => {
      // Invalidate both the product variants and images queries to trigger a refresh
      queryClient.invalidateQueries({ queryKey: ['product', productId] });
      queryClient.invalidateQueries({ queryKey: ['product-variants', productId] });
      queryClient.invalidateQueries({ queryKey: ['product-images', productId] });

      toast({
        title: "Variant Deleted",
        description: "The variant has been successfully removed.",
      });

      if (onSuccess) {
        onSuccess();
      }
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Error",
        description: `Failed to delete variant: ${(error as Error).message}`,
      });
    }
  });

  return deleteVariantMutation;
};

// Export a component that can be used to replace just the delete button in the product edit modal
export const DeleteVariantButton = ({ 
  variant, 
  productId,
  onSuccess
}: { 
  variant: any;
  productId: string;
  onSuccess?: () => void;
}) => {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const deleteVariant = async () => {
    try {
      // First delete any images associated with this variant
      const { error: imageError } = await supabase
        .from('product_images')
        .delete()
        .eq('variant_id', variant.id);
      
      if (imageError) {
        console.error('Error deleting variant images:', imageError);
        toast({
          variant: "destructive",
          title: "Error",
          description: `Failed to delete variant images: ${imageError.message}`,
        });
        return;
      }

      // Then delete the variant itself
      const { error } = await supabase
        .from('product_variants')
        .delete()
        .eq('id', variant.id);
      
      if (error) {
        toast({
          variant: "destructive",
          title: "Error",
          description: `Failed to delete variant: ${error.message}`,
        });
        return;
      }

      // Invalidate queries to refresh the UI
      queryClient.invalidateQueries({ queryKey: ['product', productId] });
      queryClient.invalidateQueries({ queryKey: ['product-variants', productId] });
      queryClient.invalidateQueries({ queryKey: ['product-images', productId] });

      toast({
        title: "Variant Deleted",
        description: "The variant has been successfully removed.",
      });

      if (onSuccess) {
        onSuccess();
      }
    } catch (error) {
      console.error('Error during variant deletion:', error);
      toast({
        variant: "destructive",
        title: "Error",
        description: `An unexpected error occurred: ${(error as Error).message}`,
      });
    }
  };

  return (
    <button
      type="button"
      onClick={deleteVariant}
      className="text-red-500 hover:text-red-700"
      aria-label="Delete variant"
    >
      Delete
    </button>
  );
};
