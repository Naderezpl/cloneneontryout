
import React, { useState } from 'react';
import { 
  useQuery, 
  useMutation, 
  useQueryClient 
} from '@tanstack/react-query';
import { supabase } from '@/lib/supabase';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { 
  Dialog, 
  DialogContent, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle 
} from '@/components/ui/dialog';
import { 
  Form, 
  FormControl, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from '@/components/ui/form';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/components/ui/use-toast';
import { Edit, Trash2, Plus, X, Wand2, RefreshCw } from 'lucide-react';
import ProductImageGallery from '@/components/admin/ProductImageGallery';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { ProductVariant, Product, ProductImage } from '@/types/product';
import ImageUploader from '@/components/ImageUploader';
import { Card, CardContent } from '@/components/ui/card';
import { v4 as uuidv4 } from 'uuid';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { ProductFilters } from '@/pages/Admin';
import { useAuth } from '@/contexts/AuthContext';

const variantSchema = z.object({
  id: z.string().optional(),
  variant_name: z.string().min(1, { message: "Variant name is required" }),
  price: z.coerce.number().positive({ message: "Price must be positive" }),
  stock_quantity: z.coerce.number().nonnegative({ message: "Stock must be 0 or greater" }),
  original_price: z.coerce.number().positive().optional(),
  is_on_sale: z.boolean().optional(),
  images: z.array(z.object({
    id: z.string().optional(),
    image_url: z.string().optional(),
    title: z.string().nullable().optional(),
    position: z.number().nullable().optional(),
  })).optional(),
});

const optionGroupSchema = z.object({
  name: z.string().min(1, { message: "Option name is required" }),
  values: z.array(z.string().min(1)).min(1, { message: "At least one value is required" }),
});

const faqSchema = z.object({
  id: z.string().optional(),
  question: z.string().min(1),
  answer: z.string().min(1),
  position: z.number().optional()
});

const productSchema = z.object({
  id: z.string().optional(),
  name: z.string().min(2, { message: "Name must be at least 2 characters" }),
  description: z.string().min(10, { message: "Description must be at least 10 characters" }),
  category_id: z.string().optional(),
  product_cost: z.coerce.number().nonnegative().default(0),
  variants: z.array(variantSchema).min(1, { message: "At least one variant is required" }),
  images: z.array(z.object({
    id: z.string().optional(),
    image_url: z.string(),
    title: z.string().nullable().optional(),
    position: z.number().nullable().optional(),
  })).optional(),
  is_hidden: z.boolean().optional(),
  track_stock: z.boolean().optional(),
  is_featured: z.boolean().optional(),
  is_on_sale: z.boolean().optional(),
  show_description: z.boolean().optional(),
  show_faq: z.boolean().optional(),
  show_recommendations: z.boolean().optional(),
  faqs: z.array(faqSchema).optional(),
  recommended_product_ids: z.array(z.string()).optional(),
  variant_options: z.array(optionGroupSchema).optional(),
});

type ProductFormValues = z.infer<typeof productSchema>;

interface ProductsAdminProps {
  filters: ProductFilters;
}

const ProductsAdmin: React.FC<ProductsAdminProps> = ({ filters }) => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { hasDbAdminRole } = useAuth();
  const [isOpen, setIsOpen] = useState(false);
  const [isDeleteOpen, setIsDeleteOpen] = useState(false);
  const [currentProduct, setCurrentProduct] = useState<Product | null>(null);
  const [variantToDelete, setVariantToDelete] = useState<{productId: string, variantId: string} | null>(null);
  const [isDeleteVariantOpen, setIsDeleteVariantOpen] = useState(false);
  const [selectedProducts, setSelectedProducts] = useState<string[]>([]);
  const [optionGroups, setOptionGroups] = useState<Array<{name: string, values: string[], newValue: string}>>([]);
  const [useCrossVariants, setUseCrossVariants] = useState(false);
  const [basePrice, setBasePrice] = useState<number | ''>('');
  const [overriddenVariants, setOverriddenVariants] = useState<Set<number>>(new Set());
  const [baseOriginalPrice, setBaseOriginalPrice] = useState<number | ''>('');
  const [thumbnailIndex, setThumbnailIndex] = useState(0);

  // Use the filters prop for filtering products
  const { 
    search,
    sort,
    showInStock,
    priceRange 
  } = filters;

  const form = useForm<ProductFormValues>({
    resolver: zodResolver(productSchema),
    defaultValues: {
      name: '',
      description: '',
      category_id: '',
      product_cost: 0,
      variants: [{ variant_name: 'Default', price: 0, stock_quantity: 0, images: [] }],
      images: [],
      is_hidden: false,
      track_stock: false,
      is_featured: false,
      is_on_sale: false,
      show_description: true,
      show_faq: false,
      show_recommendations: false,
      faqs: [],
      recommended_product_ids: [],
      variant_options: [],
    }
  });

  const watchVariants = form.watch('variants');

  const { data: products = [], isLoading } = useQuery({
    queryKey: ['admin-products', filters],
    queryFn: async () => {
      const { data: productsData, error } = await supabase
        .from('products')
        .select('*, categories(name)')
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      
      const productsWithData = await Promise.all(productsData.map(async (product) => {
        const { data: variants, error: variantsError } = await supabase
          .from('product_variants')
          .select('*')
          .eq('product_id', product.id)
          .order('variant_name');
        
        if (variantsError) console.error('Error fetching variants:', variantsError);
        
        const { data: images, error: imagesError } = await supabase
          .from('product_images')
          .select('*')
          .eq('product_id', product.id);
        
        if (imagesError) console.error('Error fetching images:', imagesError);
        
        return {
          ...product,
          variants: variants || [],
          images: images || []
        };
      }));
      
      // Apply filters to the products
      let filteredProducts = productsWithData;
      
      // Filter by search term
      if (search) {
        const searchLower = search.toLowerCase();
        filteredProducts = filteredProducts.filter(product => 
          product.name.toLowerCase().includes(searchLower) || 
          product.description.toLowerCase().includes(searchLower)
        );
      }
      
      // Filter by stock status
      if (showInStock !== null) {
        filteredProducts = filteredProducts.filter(product => {
          const hasStock = product.variants?.some(v => v.stock_quantity > 0) || false;
          return showInStock ? hasStock : !hasStock;
        });
      }
      
      // Filter by price range
      if (priceRange && (priceRange[0] > 0 || priceRange[1] < 5000)) {
        filteredProducts = filteredProducts.filter(product => {
          // Check if any variant's price is within the range
          return product.variants?.some(v => 
            v.price >= priceRange[0] && v.price <= priceRange[1]
          ) || false;
        });
      }
      
      // Sort products
      if (sort) {
        filteredProducts = [...filteredProducts].sort((a, b) => {
          switch (sort) {
            case 'name-asc':
              return a.name.localeCompare(b.name);
            case 'name-desc':
              return b.name.localeCompare(a.name);
            case 'price-asc':
              const minPriceA = Math.min(...(a.variants?.map(v => v.price) || [0]));
              const minPriceB = Math.min(...(b.variants?.map(v => v.price) || [0]));
              return minPriceA - minPriceB;
            case 'price-desc':
              const maxPriceA = Math.max(...(a.variants?.map(v => v.price) || [0]));
              const maxPriceB = Math.max(...(b.variants?.map(v => v.price) || [0]));
              return maxPriceB - maxPriceA;
            case 'created-desc':
              return new Date(b.created_at || 0).getTime() - new Date(a.created_at || 0).getTime();
            case 'created-asc':
              return new Date(a.created_at || 0).getTime() - new Date(b.created_at || 0).getTime();
            default:
              return 0;
          }
        });
      }
      
      return filteredProducts;
    }
  });

  const { data: categories = [] } = useQuery({
    queryKey: ['admin-categories'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('categories')
        .select('*')
        .order('name');
        
      if (error) throw error;
      return data;
    }
  });

  const saveMutation = useMutation({
    mutationFn: async (values: ProductFormValues) => {
      const now = new Date().toISOString();
      const productId = values.id || uuidv4();
      
      const productData = {
        id: productId,
        name: values.name,
        description: values.description,
        category_id: values.category_id || null,
        product_cost: values.product_cost ?? 0,
        created_at: values.id ? undefined : now,
        is_hidden: values.is_hidden ?? false,
        track_stock: values.track_stock ?? false,
        is_featured: values.is_featured ?? false,
        is_on_sale: values.is_on_sale ?? false,
        show_description: values.show_description ?? true,
        show_faq: values.show_faq ?? false,
        show_recommendations: values.show_recommendations ?? false,
        variant_options: values.variant_options ?? [],
      };
      
      const { error: productError } = values.id
        ? await supabase.from('products').update(productData).eq('id', productId)
        : await supabase.from('products').insert(productData);
      
      if (productError) throw productError;
      
      const variantPromises = values.variants.map(async (variant) => {
        const variantId = variant.id || uuidv4();
        const isOnSale = values.is_on_sale;
        
        const originalPrice = isOnSale && variant.original_price === undefined ? variant.price : variant.original_price;
        
        const variantData = {
          id: variantId,
          product_id: productId,
          variant_name: variant.variant_name,
          price: variant.price,
          stock_quantity: variant.stock_quantity,
          created_at: variant.id ? undefined : now,
          updated_at: now,
          original_price: originalPrice,
          is_on_sale: isOnSale
        };
        
        const { error: variantError } = variant.id
          ? await supabase.from('product_variants').update(variantData).eq('id', variantId)
          : await supabase.from('product_variants').insert(variantData);
        
        if (variantError) throw variantError;
        
        if (variant.images && variant.images.length > 0) {
          for (let i = 0; i < variant.images.length; i++) {
            const img = variant.images[i];
            if (!img.image_url) continue;
            
            const imageData = {
              id: img.id || uuidv4(),
              product_id: productId,
              variant_id: variantId,
              image_url: img.image_url,
              title: img.title || null,
              position: i,
            };
            
            const { error: imgError } = img.id
              ? await supabase.from('product_images').update(imageData).eq('id', img.id)
              : await supabase.from('product_images').insert(imageData);
            
            if (imgError) {
              console.error('Error saving variant image:', imgError);
              throw imgError;
            }
          }
        }
        
        return variantId;
      });
      
      await Promise.all(variantPromises);
      
      if (values.images && values.images.length > 0) {
        // Reorder so thumbnail (thumbnailIndex) gets position 0
        const reordered = [...values.images];
        if (thumbnailIndex > 0 && thumbnailIndex < reordered.length) {
          const [thumb] = reordered.splice(thumbnailIndex, 1);
          reordered.unshift(thumb);
        }

        for (let i = 0; i < reordered.length; i++) {
          const img = reordered[i];
          if (!img.image_url) continue;
          
          const imageData = {
            id: img.id || uuidv4(),
            product_id: productId,
            variant_id: null,
            image_url: img.image_url,
            title: img.title || null,
            position: i,
          };
          
          const { error: imgError } = img.id
            ? await supabase.from('product_images').update(imageData).eq('id', img.id)
            : await supabase.from('product_images').insert(imageData);
          
          if (imgError) {
            console.error('Error saving product image:', imgError);
            throw imgError;
          }
        }
      }
      
      // Save FAQs: replace existing with provided
      if (values.faqs) {
        const { error: delFaqErr } = await supabase
          .from('product_faqs')
          .delete()
          .eq('product_id', productId);
        if (delFaqErr) throw delFaqErr;
        if (values.faqs.length > 0) {
          const faqsToInsert = values.faqs.map((f, idx) => ({
            id: f.id || uuidv4(),
            product_id: productId,
            question: f.question,
            answer: f.answer,
            position: idx
          }));
          const { error: insFaqErr } = await supabase
            .from('product_faqs')
            .insert(faqsToInsert);
          if (insFaqErr) throw insFaqErr;
        }
      }

      // Save Recommendations: replace existing with provided
      if (values.recommended_product_ids) {
        const { error: delRecErr } = await supabase
          .from('product_recommendations')
          .delete()
          .eq('product_id', productId);
        if (delRecErr) throw delRecErr;
        if (values.recommended_product_ids.length > 0) {
          const recRows = values.recommended_product_ids
            .filter(rid => rid !== productId)
            .map((rid, idx) => ({
              product_id: productId,
              recommended_product_id: rid,
              position: idx
            }));
          if (recRows.length > 0) {
            const { error: insRecErr } = await supabase
              .from('product_recommendations')
              .insert(recRows);
            if (insRecErr) throw insRecErr;
          }
        }
      }

      const { data, error } = await supabase
        .from('products')
        .select('*, categories(name)')
        .eq('id', productId)
        .single();
      
      if (error) throw error;
      return data;
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['admin-products'] });
      toast({
        title: "Product Saved",
        description: `${data.name} has been saved successfully with all variants and images.`,
      });
      setIsOpen(false);
    },
    onError: (error) => {
      console.error('Error saving product:', error);
      toast({
        variant: "destructive",
        title: "Save Failed",
        description: `Error: ${error.message}`,
      });
    }
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error: imagesError } = await supabase
        .from('product_images')
        .delete()
        .eq('product_id', id);
      
      if (imagesError) {
        console.error('Error deleting product images:', imagesError);
        throw imagesError;
      }
      
      const { error: variantsError } = await supabase
        .from('product_variants')
        .delete()
        .eq('product_id', id);
      
      if (variantsError) {
        console.error('Error deleting product variants:', variantsError);
        throw variantsError;
      }
      
      const { data, error } = await supabase
        .from('products')
        .delete()
        .eq('id', id)
        .select('id')
        .maybeSingle();
      
      if (error) throw error;
      if (!data) {
        throw new Error('Delete was blocked by permissions (no rows deleted).');
      }
      return id;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-products'] });
      queryClient.refetchQueries({ queryKey: ['admin-products'], type: 'active' });
      toast({
        title: "Product Deleted",
        description: "Product and all associated variants and images have been deleted."
      });
      setIsDeleteOpen(false);
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Delete Failed",
        description: `Error: ${error.message}`,
      });
    }
  });

  const deleteVariantMutation = useMutation({
    mutationFn: async ({productId, variantId}: {productId: string, variantId: string}) => {
      const { error: imagesError } = await supabase
        .from('product_images')
        .delete()
        .eq('variant_id', variantId);
      
      if (imagesError) {
        console.error('Error deleting variant images:', imagesError);
        throw imagesError;
      }
      
      const { data, error } = await supabase
        .from('product_variants')
        .delete()
        .eq('id', variantId)
        .select('id')
        .maybeSingle();
      
      if (error) {
        console.error('Error deleting variant:', error);
        throw error;
      }
      if (!data) {
        throw new Error('Delete was blocked by permissions (no rows deleted).');
      }
      
      return { productId, variantId };
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['admin-products'] });
      queryClient.refetchQueries({ queryKey: ['admin-products'], type: 'active' });
      toast({
        title: "Variant Deleted",
        description: "Variant and all associated images have been deleted."
      });
      setIsDeleteVariantOpen(false);
      setVariantToDelete(null);
      
      if (currentProduct && currentProduct.id === data.productId) {
        const updatedProduct = products.find(p => p.id === data.productId);
        if (updatedProduct) {
          handleEdit(updatedProduct);
        }
      }
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Delete Failed",
        description: `Error: ${error.message}`,
      });
    }
  });

  const handleBasePriceChange = (value: string) => {
    const numVal = parseFloat(value);
    if (value === '' || isNaN(numVal)) {
      setBasePrice('');
      return;
    }
    setBasePrice(numVal);
    // Update all non-overridden variants
    const variants = form.getValues('variants') || [];
    variants.forEach((_, index) => {
      if (!overriddenVariants.has(index)) {
        form.setValue(`variants.${index}.price`, numVal);
      }
    });
  };

  const handleBaseOriginalPriceChange = (value: string) => {
    const numVal = parseFloat(value);
    if (value === '' || isNaN(numVal)) {
      setBaseOriginalPrice('');
      // Clear original_price on all variants
      const variants = form.getValues('variants') || [];
      variants.forEach((_, index) => {
        form.setValue(`variants.${index}.original_price`, undefined);
      });
      return;
    }
    setBaseOriginalPrice(numVal);
    const variants = form.getValues('variants') || [];
    variants.forEach((_, index) => {
      form.setValue(`variants.${index}.original_price`, numVal);
    });
  };

  const handleVariantPriceManualChange = (index: number, value: number) => {
    form.setValue(`variants.${index}.price`, value);
    // Mark as overridden if different from base price
    if (basePrice !== '' && value !== basePrice) {
      setOverriddenVariants(prev => new Set(prev).add(index));
    }
  };

  const resetVariantToBasePrice = (index: number) => {
    if (basePrice !== '' && typeof basePrice === 'number') {
      form.setValue(`variants.${index}.price`, basePrice);
      setOverriddenVariants(prev => {
        const next = new Set(prev);
        next.delete(index);
        return next;
      });
    }
  };

  const addVariant = () => {
    const variants = form.getValues('variants') || [];
    const price = typeof basePrice === 'number' ? basePrice : 0;
    form.setValue('variants', [
      ...variants,
      { variant_name: '', price, stock_quantity: 0, images: [] }
    ]);
  };

  const removeVariant = (index: number) => {
    const variants = form.getValues('variants') || [];
    if (variants.length > 1) {
      const variantToRemove = variants[index];
      
      if (variantToRemove.id && currentProduct) {
        setVariantToDelete({
          productId: currentProduct.id,
          variantId: variantToRemove.id
        });
        setIsDeleteVariantOpen(true);
      } else {
        form.setValue('variants', variants.filter((_, i) => i !== index));
      }
    } else {
      toast({
        title: "Cannot Remove",
        description: "At least one variant is required.",
      });
    }
  };

  const handleVariantImageUploaded = (index: number, url: string) => {
    const variants = form.getValues('variants');
    const currentVariant = variants[index];
    const currentImages = currentVariant.images || [];
    
    form.setValue(`variants.${index}.images`, [
      ...currentImages,
      { 
        image_url: url, 
        position: currentImages.length,
        variant_id: currentVariant.id,
      } as ProductImage
    ]);
  };

  const handleProductImageUploaded = (url: string) => {
    const currentImages = form.getValues('images') || [];
    form.setValue('images', [
      ...currentImages,
      { 
        image_url: url, 
        position: currentImages.length,
        variant_id: null
      } as ProductImage
    ]);
  };

  const removeVariantImage = (variantIndex: number, imageIndex: number) => {
    const variants = form.getValues('variants');
    const currentImages = [...(variants[variantIndex].images || [])];
    currentImages.splice(imageIndex, 1);
    form.setValue(`variants.${variantIndex}.images`, currentImages);
  };

  const removeProductImage = (imageIndex: number) => {
    const currentImages = [...(form.getValues('images') || [])];
    currentImages.splice(imageIndex, 1);
    form.setValue('images', currentImages);
  };

  // Cross-variant helpers
  const addOptionGroup = () => {
    setOptionGroups(prev => [...prev, { name: '', values: [], newValue: '' }]);
  };

  const removeOptionGroup = (index: number) => {
    setOptionGroups(prev => prev.filter((_, i) => i !== index));
  };

  const updateOptionGroupName = (index: number, name: string) => {
    setOptionGroups(prev => prev.map((g, i) => i === index ? { ...g, name } : g));
  };

  const addOptionValue = (groupIndex: number) => {
    setOptionGroups(prev => prev.map((g, i) => {
      if (i !== groupIndex || !g.newValue.trim()) return g;
      return { ...g, values: [...g.values, g.newValue.trim()], newValue: '' };
    }));
  };

  const removeOptionValue = (groupIndex: number, valueIndex: number) => {
    setOptionGroups(prev => prev.map((g, i) => 
      i === groupIndex ? { ...g, values: g.values.filter((_, vi) => vi !== valueIndex) } : g
    ));
  };

  const generateCrossVariants = () => {
    const validGroups = optionGroups.filter(g => g.name.trim() && g.values.length > 0);
    if (validGroups.length === 0) {
      toast({ title: "No Options", description: "Add at least one option group with values." });
      return;
    }

    // Generate cartesian product
    const combinations = validGroups.reduce<string[][]>(
      (acc, group) => {
        if (acc.length === 0) return group.values.map(v => [v]);
        return acc.flatMap(combo => group.values.map(v => [...combo, v]));
      },
      []
    );

    const existingVariants = form.getValues('variants') || [];
    const newVariants = combinations.map(combo => {
      const variantName = combo.join(' / ');
      // Try to find existing variant with same name to preserve id/price/stock
      const existing = existingVariants.find(v => v.variant_name === variantName);
      const defaultPrice = typeof basePrice === 'number' ? basePrice : 0;
      return existing || { variant_name: variantName, price: defaultPrice, stock_quantity: 0, images: [] };
    });

    form.setValue('variants', newVariants);
    setOverriddenVariants(new Set());
    // Also save the option groups to form
    form.setValue('variant_options', validGroups.map(g => ({ name: g.name, values: g.values })));
    
    toast({ title: "Variants Generated", description: `${newVariants.length} variant combinations created.` });
  };

  const handleEdit = async (product: Product) => {
    setCurrentProduct(product);
    
    // Fetch meta for this product
    const { data: faqs } = await supabase
      .from('product_faqs')
      .select('*')
      .eq('product_id', product.id)
      .order('position', { ascending: true });
    const { data: recs } = await supabase
      .from('product_recommendations')
      .select('recommended_product_id, position')
      .eq('product_id', product.id)
      .order('position', { ascending: true });

    const formValues = {
      id: product.id,
      name: product.name,
      description: product.description,
      category_id: product.category_id || '',
      product_cost: (product as any).product_cost ?? 0,
      variants: product.variants?.map(v => ({
        id: v.id,
        variant_name: v.variant_name,
        price: v.price,
        stock_quantity: v.stock_quantity,
        original_price: v.original_price,
        images: v.images || []
      })) || [{ variant_name: 'Default', price: 0, stock_quantity: 0, images: [] }],
      images: product.images?.filter(img => !img.variant_id) || [],
      is_hidden: product.is_hidden ?? false,
      track_stock: product.track_stock ?? false,
      is_featured: product.is_featured ?? false,
      is_on_sale: product.is_on_sale ?? false,
      show_description: (product as any).show_description ?? true,
      show_faq: (product as any).show_faq ?? false,
      show_recommendations: (product as any).show_recommendations ?? false,
      faqs: faqs || [],
      recommended_product_ids: (recs || []).map(r => r.recommended_product_id),
      variant_options: (product as any).variant_options || [],
    };
    
    // Restore option groups state
    const vo = (product as any).variant_options || [];
    if (vo.length > 0) {
      setUseCrossVariants(true);
      setOptionGroups(vo.map((g: any) => ({ name: g.name, values: g.values || [], newValue: '' })));
    } else {
      setUseCrossVariants(false);
      setOptionGroups([]);
    }
    
    form.reset(formValues);
    // Set thumbnail to the image at position 0
    const productImages = formValues.images || [];
    const thumbIdx = productImages.findIndex(img => img.position === 0);
    setThumbnailIndex(thumbIdx >= 0 ? thumbIdx : 0);
    setBasePrice('');
    setBaseOriginalPrice('');
    setOverriddenVariants(new Set());
    setIsOpen(true);
  };

  const handleNew = () => {
    setCurrentProduct(null);
    setUseCrossVariants(false);
    setOptionGroups([]);
    setThumbnailIndex(0);
    setBasePrice('');
    setBaseOriginalPrice('');
    setOverriddenVariants(new Set());
    form.reset({
      name: '',
      description: '',
      category_id: categories.length > 0 ? categories[0].id : '',
      variants: [{ variant_name: 'Default', price: 0, stock_quantity: 0, images: [] }],
      images: [],
      is_hidden: false,
      track_stock: false,
      is_featured: false,
      is_on_sale: false,
      variant_options: [],
    });
    setIsOpen(true);
  };

  const handleDelete = (product: Product) => {
    setCurrentProduct(product);
    setIsDeleteOpen(true);
  };

  const confirmDelete = () => {
    if (currentProduct) {
      deleteMutation.mutate(currentProduct.id);
    }
  };

  const confirmDeleteVariant = () => {
    if (variantToDelete) {
      deleteVariantMutation.mutate(variantToDelete);
    }
  };

  const onSubmit = (values: ProductFormValues) => {
    if (!hasDbAdminRole) {
      toast({
        variant: "destructive",
        title: "Insufficient Permissions",
        description: "Saving products requires a DB admin role. Please add your user to public.user_roles with role 'admin'.",
      });
      return;
    }
    saveMutation.mutate(values);
  };

  const handleMassDelete = async () => {
    try {
      const results = await Promise.all(
        selectedProducts.map(async (productId) => {
          const { error } = await supabase.from('products').delete().eq('id', productId);
          return { productId, error };
        })
      );
      
      const errors = results.filter(r => r.error);
      if (errors.length > 0) {
        toast({
          variant: "destructive",
          title: "Delete Failed",
          description: `Failed to delete ${errors.length} of ${selectedProducts.length} products due to permissions.`,
        });
      } else {
        toast({
          title: "Products Deleted",
          description: `${selectedProducts.length} products were deleted.`,
        });
      }
      
      setSelectedProducts([]);
      queryClient.invalidateQueries({ queryKey: ['admin-products'] });
    } catch (err: any) {
      toast({
        variant: "destructive",
        title: "Delete Failed",
        description: `Error: ${err?.message || 'Unknown error'}`,
      });
    }
  };

  const handleMassHide = async () => {
    try {
      const results = await Promise.all(
        selectedProducts.map(async (productId) => {
          const { error } = await supabase
            .from('products')
            .update({ is_hidden: true })
            .eq('id', productId);
          return { productId, error };
        })
      );
      
      const errors = results.filter(r => r.error);
      if (errors.length > 0) {
        toast({
          variant: "destructive",
          title: "Hide Failed",
          description: `Failed to hide ${errors.length} of ${selectedProducts.length} products due to permissions.`,
        });
      } else {
        toast({
          title: "Products Hidden",
          description: `${selectedProducts.length} products have been hidden from the shop.`,
        });
      }
      
      setSelectedProducts([]);
      queryClient.invalidateQueries({ queryKey: ['admin-products'] });
    } catch (err: any) {
      toast({
        variant: "destructive",
        title: "Hide Failed",
        description: `Error: ${err?.message || 'Unknown error'}`,
      });
    }
  };

  const handleMassShow = async () => {
    try {
      const results = await Promise.all(
        selectedProducts.map(async (productId) => {
          const { error } = await supabase
            .from('products')
            .update({ is_hidden: false })
            .eq('id', productId);
          return { productId, error };
        })
      );
      
      const errors = results.filter(r => r.error);
      if (errors.length > 0) {
        toast({
          variant: "destructive",
          title: "Show Failed",
          description: `Failed to show ${errors.length} of ${selectedProducts.length} products due to permissions.`,
        });
      } else {
        toast({
          title: "Products Shown",
          description: `${selectedProducts.length} products are now visible in the shop.`,
        });
      }
      
      setSelectedProducts([]);
      queryClient.invalidateQueries({ queryKey: ['admin-products'] });
    } catch (err: any) {
      toast({
        variant: "destructive",
        title: "Show Failed",
        description: `Error: ${err?.message || 'Unknown error'}`,
      });
    }
  };

  if (isLoading) {
    return <div className="text-center py-8">Loading products...</div>;
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">Manage Products</h2>
        <Button onClick={handleNew}>
          <Plus className="mr-2 h-4 w-4" /> Add Product
        </Button>
      </div>

      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>
              <Checkbox 
                checked={selectedProducts.length === products.length}
                onCheckedChange={(checked) => {
                  setSelectedProducts(checked ? products.map(p => p.id) : []);
                }}
              />
            </TableHead>
            <TableHead>Image</TableHead>
            <TableHead>Name</TableHead>
            <TableHead>Category</TableHead>
            <TableHead>Variants</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {products.map((product) => (
            <TableRow key={product.id}>
              <TableCell>
                <Checkbox 
                  checked={selectedProducts.includes(product.id)}
                  onCheckedChange={(checked) => {
                    setSelectedProducts(prev => 
                      checked 
                        ? [...prev, product.id] 
                        : prev.filter(id => id !== product.id)
                    );
                  }}
                />
              </TableCell>
              <TableCell>
                {product.images && product.images.length > 0 ? (
                  <img 
                    src={product.images[0].image_url} 
                    alt={product.name} 
                    className="w-16 h-16 object-cover rounded"
                  />
                ) : (
                  <div className="w-16 h-16 bg-gray-100 flex items-center justify-center rounded">
                    <span className="text-xs text-gray-400">No image</span>
                  </div>
                )}
              </TableCell>
              <TableCell>{product.name}</TableCell>
              <TableCell>
                {product.categories ? product.categories.name : 'Uncategorized'}
              </TableCell>
              <TableCell>
                {product.variants && product.variants.length > 0 ? (
                  <div>
                    <span className="font-medium">{product.variants.length} variants</span>
                    <ul className="text-xs text-muted-foreground mt-1">
                      {product.variants.slice(0, 2).map((variant) => (
                        <li key={variant.id}>
                          {variant.variant_name}: ${variant.price} 
                          {variant.is_on_sale && variant.original_price && (
                            <span className="text-neon-red"> (Sale from ${variant.original_price})</span>
                          )}
                          ({variant.stock_quantity} in stock)
                        </li>
                      ))}
                      {product.variants.length > 2 && (
                        <li>+{product.variants.length - 2} more variants...</li>
                      )}
                    </ul>
                  </div>
                ) : (
                  <span className="text-muted-foreground">No variants</span>
                )}
              </TableCell>
              <TableCell>
                <div className="flex flex-col gap-1">
                  <Badge variant={product.is_hidden ? "destructive" : "default"}>
                    {product.is_hidden ? 'Hidden' : 'Visible'}
                  </Badge>
                  {product.is_featured && (
                    <Badge variant="outline" className="bg-neon-blue/10 text-neon-blue border-neon-blue">
                      Featured
                    </Badge>
                  )}
                  {product.is_on_sale && (
                    <Badge variant="outline" className="bg-neon-red/10 text-neon-red border-neon-red">
                      On Sale
                    </Badge>
                  )}
                </div>
              </TableCell>
              <TableCell>
                <div className="flex space-x-2">
                  <Button variant="outline" size="sm" onClick={() => handleEdit(product)}>
                    <Edit className="h-4 w-4" />
                  </Button>
                  <Button variant="destructive" size="sm" onClick={() => {
                    if (!hasDbAdminRole) {
                      toast({
                        variant: "destructive",
                        title: "Insufficient Permissions",
                        description: "Your account is marked admin in the app but missing the admin role in the database. Please contact support to grant DB admin.",
                      });
                      return;
                    }
                    handleDelete(product);
                  }} disabled={!hasDbAdminRole}>
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>

      <div className="flex items-center space-x-2 mb-4">
        <Button 
          variant="destructive" 
          disabled={selectedProducts.length === 0 || !hasDbAdminRole}
          onClick={handleMassDelete}
        >
          Delete Selected
        </Button>
        <Button 
          variant="outline" 
          disabled={selectedProducts.length === 0 || !hasDbAdminRole}
          onClick={handleMassHide}
        >
          Hide Selected
        </Button>
        <Button 
          variant="outline" 
          disabled={selectedProducts.length === 0 || !hasDbAdminRole}
          onClick={handleMassShow}
        >
          Show Selected
        </Button>
      </div>

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="sm:max-w-[800px] max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {currentProduct ? `Edit Product: ${currentProduct.name}` : 'Add New Product'}
            </DialogTitle>
          </DialogHeader>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Product Name</FormLabel>
                        <FormControl>
                          <Input {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Description</FormLabel>
                        <FormControl>
                          <Textarea rows={5} {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="product_cost"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Product Cost (internal)</FormLabel>
                        <FormControl>
                          <Input type="number" step="0.01" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="category_id"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Category</FormLabel>
                        <Select onValueChange={field.onChange} value={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select a category" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {categories.map((category) => (
                              <SelectItem key={category.id} value={category.id}>
                                {category.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div>
                    <ProductImageGallery
                      images={(form.watch('images') || []).filter(img => img.image_url).map(img => ({ ...img, image_url: img.image_url! }))}
                      onImagesChange={(imgs) => form.setValue('images', imgs)}
                      onImageUploaded={handleProductImageUploaded}
                      thumbnailIndex={thumbnailIndex}
                      onThumbnailChange={setThumbnailIndex}
                    />
                  </div>
                </div>
                
                <div>
                  {/* Global Base Price */}
                  <div className="mb-4 p-3 border rounded-lg bg-muted/30">
                    <Label className="text-sm font-medium">Base Price (applies to all variants)</Label>
                    <Input
                      type="number"
                      step="0.01"
                      placeholder="Enter base price..."
                      value={basePrice}
                      onChange={(e) => handleBasePriceChange(e.target.value)}
                      className="mt-1"
                    />
                    {basePrice !== '' && overriddenVariants.size > 0 && (
                      <p className="text-xs text-muted-foreground mt-1">
                        {overriddenVariants.size} variant(s) have custom prices.
                      </p>
                    )}
                    </div>

                  {/* Global Original Price */}
                  <div className="mb-4 p-3 border rounded-lg bg-muted/30">
                    <Label className="text-sm font-medium">Original Price (applies to all variants)</Label>
                    <p className="text-xs text-muted-foreground mb-1">
                      Set a strikethrough price shown when product is on sale.
                    </p>
                    <Input
                      type="number"
                      step="0.01"
                      placeholder="Enter original price..."
                      value={baseOriginalPrice}
                      onChange={(e) => handleBaseOriginalPriceChange(e.target.value)}
                      className="mt-1"
                    />
                  </div>

                  <div className="flex justify-between items-center mb-4">
                    <h3 className="font-medium">Product Variants</h3>
                    <div className="flex items-center gap-2">
                      <Label htmlFor="cross-variant-toggle" className="text-sm">Cross Variants</Label>
                      <Checkbox
                        id="cross-variant-toggle"
                        checked={useCrossVariants}
                        onCheckedChange={(checked) => {
                          setUseCrossVariants(!!checked);
                          if (checked && optionGroups.length === 0) {
                            setOptionGroups([{ name: '', values: [], newValue: '' }]);
                          }
                        }}
                      />
                    </div>
                  </div>

                  {/* Cross-Variant Option Groups */}
                  {useCrossVariants && (
                    <div className="mb-6 space-y-4 p-4 border rounded-lg bg-muted/30">
                      <div className="flex justify-between items-center">
                        <h4 className="text-sm font-medium">Option Groups</h4>
                        <Button type="button" variant="outline" size="sm" onClick={addOptionGroup}>
                          <Plus className="h-4 w-4 mr-1" /> Add Option Group
                        </Button>
                      </div>
                      
                      {optionGroups.map((group, gIdx) => (
                        <Card key={gIdx} className="relative">
                          <button
                            type="button"
                            className="absolute top-2 right-2 text-destructive"
                            onClick={() => removeOptionGroup(gIdx)}
                          >
                            <X className="h-4 w-4" />
                          </button>
                          <CardContent className="pt-4 space-y-3">
                            <div>
                              <Label className="text-sm">Option Name (e.g., Color, Size)</Label>
                              <Input
                                value={group.name}
                                onChange={(e) => updateOptionGroupName(gIdx, e.target.value)}
                                placeholder="e.g., Color"
                                className="mt-1"
                              />
                            </div>
                            <div>
                              <Label className="text-sm">Values</Label>
                              <div className="flex flex-wrap gap-1.5 mt-1 mb-2">
                                {group.values.map((val, vIdx) => (
                                  <Badge key={vIdx} variant="secondary" className="gap-1">
                                    {val}
                                    <button type="button" onClick={() => removeOptionValue(gIdx, vIdx)}>
                                      <X className="h-3 w-3" />
                                    </button>
                                  </Badge>
                                ))}
                              </div>
                              <div className="flex gap-2">
                                <Input
                                  value={group.newValue}
                                  onChange={(e) => setOptionGroups(prev => prev.map((g, i) => i === gIdx ? { ...g, newValue: e.target.value } : g))}
                                  placeholder="e.g., Red"
                                  className="flex-1"
                                  onKeyDown={(e) => {
                                    if (e.key === 'Enter') { e.preventDefault(); addOptionValue(gIdx); }
                                  }}
                                />
                                <Button type="button" variant="outline" size="sm" onClick={() => addOptionValue(gIdx)}>
                                  Add
                                </Button>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                      
                      <Button type="button" onClick={generateCrossVariants} className="w-full">
                        <Wand2 className="h-4 w-4 mr-2" /> Generate Variant Combinations
                      </Button>
                    </div>
                  )}
                  
                  {/* Manual add variant button (only when not using cross variants) */}
                  {!useCrossVariants && (
                    <div className="flex justify-end mb-4">
                      <Button type="button" variant="outline" size="sm" onClick={addVariant}>
                        <Plus className="h-4 w-4 mr-1" /> Add Variant
                      </Button>
                    </div>
                  )}
                  
                  <div className="space-y-6">
                    {watchVariants.map((_, index) => (
                      <Card key={index} className="relative">
                        {watchVariants.length > 1 && !useCrossVariants && (
                          <button
                            type="button"
                            className="absolute top-2 right-2 text-destructive"
                            onClick={() => removeVariant(index)}
                          >
                            <X className="h-4 w-4" />
                          </button>
                        )}
                        <CardContent className="pt-6 space-y-4">
                          <FormField
                            control={form.control}
                            name={`variants.${index}.variant_name`}
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Variant Name</FormLabel>
                                <FormControl>
                                  <Input {...field} placeholder="e.g., Small, Red, Oak Wood" readOnly={useCrossVariants} className={useCrossVariants ? 'bg-muted' : ''} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <div className="grid grid-cols-2 gap-4">
                            <FormField
                              control={form.control}
                              name={`variants.${index}.price`}
                              render={({ field }) => (
                                <FormItem>
                                  <div className="flex items-center justify-between">
                                    <FormLabel>Price</FormLabel>
                                    {overriddenVariants.has(index) && basePrice !== '' && (
                                      <button
                                        type="button"
                                        onClick={() => resetVariantToBasePrice(index)}
                                        className="flex items-center gap-1 text-xs text-primary hover:underline"
                                        title="Sync back to base price"
                                      >
                                        <RefreshCw className="h-3 w-3" /> Sync
                                      </button>
                                    )}
                                  </div>
                                  <FormControl>
                                    <Input
                                      type="number"
                                      step="0.01"
                                      {...field}
                                      onChange={(e) => {
                                        field.onChange(e);
                                        handleVariantPriceManualChange(index, parseFloat(e.target.value) || 0);
                                      }}
                                      className={overriddenVariants.has(index) ? 'border-accent' : ''}
                                    />
                                  </FormControl>
                                  {overriddenVariants.has(index) && (
                                    <p className="text-xs text-muted-foreground">Custom price (overridden)</p>
                                  )}
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            
                            {form.watch('is_on_sale') && (
                              <FormField
                                control={form.control}
                                name={`variants.${index}.original_price` as const}
                                render={({ field }) => (
                                  <FormItem>
                                    <FormLabel>Original Price</FormLabel>
                                    <FormControl>
                                      <Input type="number" step="0.01" {...field} value={field.value || ''} />
                                    </FormControl>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                            )}
                          </div>
                          
                          <FormField
                            control={form.control}
                            name={`variants.${index}.stock_quantity`}
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Stock</FormLabel>
                                <FormControl>
                                  <Input type="number" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <div>
                            <FormLabel className="block mb-2">Variant Images</FormLabel>
                            <div className="flex flex-wrap gap-2 mb-2">
                              {form.getValues(`variants.${index}.images`)?.map((img, imgIdx) => (
                                <div key={imgIdx} className="relative group">
                                  <img 
                                    src={img.image_url} 
                                    alt={`Variant ${index} image ${imgIdx}`}
                                    className="w-16 h-16 object-cover rounded"
                                  />
                                  <button
                                    type="button"
                                    className="absolute top-0 right-0 bg-destructive text-destructive-foreground rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity"
                                    onClick={() => removeVariantImage(index, imgIdx)}
                                  >
                                    <X className="h-3 w-3" />
                                  </button>
                                </div>
                              ))}
                            </div>
                            <ImageUploader 
                              onImageUploaded={(url) => handleVariantImageUploaded(index, url)} 
                              bucketName="imageassets"
                              folderPath={`products/variants/${index}`}
                              aspectRatio={1}
                              uploadId={`variant-image-upload-${index}`}
                              recommendedSize="1000 × 1000 px"
                            />
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="is_hidden"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                      <FormControl>
                        <Checkbox
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                      <div className="space-y-1 leading-none">
                        <FormLabel>
                          Hide Product
                        </FormLabel>
                        <p className="text-sm text-muted-foreground">
                          Hidden products won't appear in the shop.
                        </p>
                      </div>
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="is_featured"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                      <FormControl>
                        <Checkbox
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                      <div className="space-y-1 leading-none">
                        <FormLabel>
                          Featured Product
                        </FormLabel>
                        <p className="text-sm text-muted-foreground">
                          Featured products appear in the homepage showcase.
                        </p>
                      </div>
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="is_on_sale"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                      <FormControl>
                        <Checkbox
                          checked={field.value}
                          onCheckedChange={(checked) => {
                            field.onChange(checked);
                            if (checked) {
                              // When setting a product on sale, update all variants to have original price
                              const variants = form.getValues('variants');
                              variants.forEach((variant, idx) => {
                                if (!variant.original_price) {
                                  form.setValue(`variants.${idx}.original_price`, variant.price);
                                }
                              });
                            }
                          }}
                        />
                      </FormControl>
                      <div className="space-y-1 leading-none">
                        <FormLabel>
                          On Sale
                        </FormLabel>
                        <p className="text-sm text-muted-foreground">
                          Sale products are displayed with discount information.
                        </p>
                      </div>
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="track_stock"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                      <FormControl>
                        <Checkbox
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                      <div className="space-y-1 leading-none">
                        <FormLabel>
                          Track Stock
                        </FormLabel>
                        <p className="text-sm text-muted-foreground">
                          Stock levels will update as products are sold.
                        </p>
                      </div>
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="show_description"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                      <FormControl>
                        <Checkbox
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                      <div className="space-y-1 leading-none">
                        <FormLabel>
                          Show Description
                        </FormLabel>
                        <p className="text-sm text-muted-foreground">
                          Toggle visibility of the product description.
                        </p>
                      </div>
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="show_faq"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                      <FormControl>
                        <Checkbox
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                      <div className="space-y-1 leading-none">
                        <FormLabel>
                          Show FAQ
                        </FormLabel>
                        <p className="text-sm text-muted-foreground">
                          Display frequently asked questions below the description.
                        </p>
                      </div>
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="show_recommendations"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                      <FormControl>
                        <Checkbox
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                      <div className="space-y-1 leading-none">
                        <FormLabel>
                          Show You May Also Like
                        </FormLabel>
                        <p className="text-sm text-muted-foreground">
                          Display recommended products at the bottom of the page.
                        </p>
                      </div>
                    </FormItem>
                  )}
                />
              </div>

              {/* FAQ Manager */}
              <div className="space-y-4">
                <h3 className="font-medium">FAQ Manager</h3>
                {(form.watch('faqs') || []).map((faq, index) => (
                  <div key={faq.id || index} className="border rounded-md p-4 space-y-3">
                    <div className="flex gap-2">
                      <div className="flex-1">
                        <FormField
                          control={form.control}
                          name={`faqs.${index}.question` as const}
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Question</FormLabel>
                              <FormControl>
                                <Input {...field} placeholder="Enter question" />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                      <Button
                        type="button"
                        variant="ghost"
                        onClick={() => {
                          const faqs = form.getValues('faqs') || [];
                          faqs.splice(index, 1);
                          form.setValue('faqs', [...faqs]);
                        }}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                    <FormField
                      control={form.control}
                      name={`faqs.${index}.answer` as const}
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Answer</FormLabel>
                          <FormControl>
                            <Textarea rows={3} {...field} placeholder="Enter answer" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                ))}
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => {
                    const faqs = form.getValues('faqs') || [];
                    form.setValue('faqs', [...faqs, { question: '', answer: '' } as any]);
                  }}
                >
                  <Plus className="h-4 w-4 mr-1" /> Add FAQ
                </Button>
              </div>

              {/* Recommendations Selector */}
              <div className="space-y-3">
                <h3 className="font-medium">You May Also Like</h3>
                <p className="text-sm text-muted-foreground">Select products to recommend. If none selected, section is hidden.</p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2 max-h-60 overflow-auto p-2 border rounded">
                  {products
                    .filter(p => p.id !== (currentProduct?.id || form.getValues('id')))
                    .map(p => {
                      const selected = (form.watch('recommended_product_ids') || []).includes(p.id);
                      return (
                        <label key={p.id} className="flex items-center gap-2 text-sm">
                          <Checkbox
                            checked={selected}
                            onCheckedChange={(checked) => {
                              const current = new Set(form.getValues('recommended_product_ids') || []);
                              if (checked) current.add(p.id); else current.delete(p.id);
                              form.setValue('recommended_product_ids', Array.from(current));
                            }}
                          />
                          <span>{p.name}</span>
                        </label>
                      );
                    })}
                </div>
              </div>
              
              <DialogFooter>
                <Button type="submit" disabled={saveMutation.isPending || !hasDbAdminRole}>
                  {saveMutation.isPending ? "Saving..." : "Save Product"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
      
      <Dialog open={isDeleteOpen} onOpenChange={setIsDeleteOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirm Delete</DialogTitle>
          </DialogHeader>
          <p>Are you sure you want to delete {currentProduct?.name}? This will also remove all variants and images.</p>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDeleteOpen(false)}>Cancel</Button>
            <Button variant="destructive" onClick={confirmDelete} disabled={deleteMutation.isPending}>
              {deleteMutation.isPending ? "Deleting..." : "Delete"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      <Dialog open={isDeleteVariantOpen} onOpenChange={setIsDeleteVariantOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirm Variant Delete</DialogTitle>
          </DialogHeader>
          <p>Are you sure you want to delete this variant? This will also remove all associated images.</p>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDeleteVariantOpen(false)}>Cancel</Button>
            <Button variant="destructive" onClick={confirmDeleteVariant} disabled={deleteVariantMutation.isPending}>
              {deleteVariantMutation.isPending ? "Deleting..." : "Delete"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default ProductsAdmin;
