
import React, { useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { listReviews, createReview, analyzeReviewContent } from '@/api/reviews';
import { useToast } from '@/components/ui/use-toast';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Star } from 'lucide-react';

const HomeReviewSection: React.FC = () => {
  return (
    <section className="py-16 md:py-24 bg-background">
      <div className="container mx-auto px-4 max-w-2xl">
        <h2 className="text-2xl md:text-3xl font-semibold tracking-tight text-center mb-10">Leave a Review</h2>
        <HomeReviewForm />
      </div>
    </section>
  );
};

const HomeReviewForm: React.FC = () => {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [name, setName] = useState('');
  const [rating, setRating] = useState<number>(5);
  const [text, setText] = useState('');
  const [hp, setHp] = useState('');

  const addMutation = useMutation({
    mutationFn: async () => {
      if (hp) throw new Error('spam-detected');
      if (!name.trim() || !text.trim()) throw new Error('Please fill all fields');
      return createReview({
        product_id: null,
        reviewer_name: name.trim(),
        rating,
        review_text: text.trim(),
      });
    },
    onSuccess: () => {
      const outcome = analyzeReviewContent(rating, text);
      const desc = outcome.status === 'approved'
        ? 'Thanks! Your review is live.'
        : 'Your review is being reviewed by our moderation team.';
      toast({ title: 'Review submitted', description: desc });
      setName('');
      setRating(5);
      setText('');
      queryClient.invalidateQueries({ queryKey: ['home-reviews'] });
    }
  });

  return (
    <form
      className="space-y-4"
      onSubmit={(e) => {
        e.preventDefault();
        addMutation.mutate();
      }}
    >
      <Input
        placeholder="Your name"
        value={name}
        onChange={(e) => setName(e.target.value)}
        required
        className="h-11 rounded-lg"
      />
      <div className="flex items-center gap-3">
        <span className="text-sm text-muted-foreground">Rating</span>
        <div className="flex items-center gap-0.5">
          {[1,2,3,4,5].map(n => (
            <button
              key={n}
              type="button"
              onClick={() => setRating(n)}
              aria-label={`${n} star${n>1?'s':''}`}
              className="p-0.5"
            >
              <Star className={`h-5 w-5 transition-colors ${n <= rating ? 'text-amber-500 fill-amber-500' : 'text-border'}`} />
            </button>
          ))}
        </div>
      </div>
      <Textarea
        placeholder="Share your experience"
        value={text}
        onChange={(e) => setText(e.target.value)}
        rows={4}
        required
        className="rounded-lg"
      />
      <Input
        className="hidden"
        tabIndex={-1}
        autoComplete="off"
        value={hp}
        onChange={(e) => setHp(e.target.value)}
        aria-hidden="true"
      />
      <div className="flex items-center gap-4">
        <Button 
          type="submit" 
          disabled={addMutation.isPending}
          className="rounded-full px-8"
        >
          {addMutation.isPending ? 'Submitting...' : 'Submit Review'}
        </Button>
        <span className="text-xs text-muted-foreground">
          Status will update after submission.
        </span>
      </div>
    </form>
  );
};

export default HomeReviewSection;
