
import React, { useCallback, useEffect, useState } from 'react';
import { Star, ChevronLeft, ChevronRight, BadgeCheck } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/lib/supabase';
import useEmblaCarousel from 'embla-carousel-react';
import { cn } from '@/lib/utils';

interface ReviewCardProps {
  rating: number;
  text: string;
  name: string;
}

const ReviewCard: React.FC<ReviewCardProps> = ({ rating, text, name }) => (
  <div
    className={cn(
      "bg-[hsl(0_0%_98%)] rounded-2xl px-7 py-8 flex flex-col gap-5 h-full",
      "shadow-[0_4px_6px_-1px_rgb(0_0_0/0.04),0_20px_25px_-5px_rgb(0_0_0/0.05)]",
      "transition-shadow duration-300 hover:shadow-[0_8px_12px_-2px_rgb(0_0_0/0.06),0_25px_35px_-5px_rgb(0_0_0/0.08)]"
    )}
  >
    {/* Stars */}
    <div className="flex items-center gap-0.5">
      {[1, 2, 3, 4, 5].map((i) => (
        <Star
          key={i}
          size={16}
          className={cn(
            "transition-colors",
            i <= rating ? "fill-amber-400 text-amber-400" : "text-muted-foreground/25"
          )}
        />
      ))}
    </div>

    {/* Review text — clamped to 3 lines */}
    <p className="text-sm leading-relaxed text-foreground/80 line-clamp-3 flex-1">
      {text}
    </p>

    {/* Reviewer */}
    <div className="flex items-center gap-2 pt-1 border-t border-border/40">
      <span className="text-sm font-semibold text-foreground tracking-tight">{name}</span>
      <span className="inline-flex items-center gap-1 text-[11px] font-medium text-muted-foreground bg-muted rounded-full px-2 py-0.5">
        <BadgeCheck size={12} className="text-primary" />
        Verified
      </span>
    </div>
  </div>
);

const Testimonials = () => {
  const { data: reviews = [] } = useQuery({
    queryKey: ['reviews-home'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('reviews')
        .select('*')
        .eq('enabled', true)
        .order('position', { ascending: true });
      if (error) return [];
      return data || [];
    }
  });

  const [emblaRef, emblaApi] = useEmblaCarousel({
    align: 'start',
    loop: true,
    slidesToScroll: 1,
  });

  const [canPrev, setCanPrev] = useState(false);
  const [canNext, setCanNext] = useState(false);

  const onSelect = useCallback(() => {
    if (!emblaApi) return;
    setCanPrev(emblaApi.canScrollPrev());
    setCanNext(emblaApi.canScrollNext());
  }, [emblaApi]);

  useEffect(() => {
    if (!emblaApi) return;
    onSelect();
    emblaApi.on('select', onSelect);
    emblaApi.on('reInit', onSelect);
    return () => { emblaApi.off('select', onSelect); };
  }, [emblaApi, onSelect]);

  if (!reviews || reviews.length === 0) return null;

  return (
    <section className="py-20 md:py-28 bg-background">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-14">
          <h2 className="text-2xl md:text-3xl font-semibold tracking-tight text-foreground">
            What Our Customers Say
          </h2>
          <p className="text-sm text-muted-foreground mt-3 max-w-md mx-auto">
            Real feedback from people who love our products
          </p>
        </div>

        {/* Carousel wrapper */}
        <div className="relative max-w-5xl mx-auto group">
          {/* Nav arrows */}
          <button
            onClick={() => emblaApi?.scrollPrev()}
            disabled={!canPrev}
            aria-label="Previous review"
            className={cn(
              "absolute -left-5 md:-left-12 top-1/2 -translate-y-1/2 z-10",
              "w-9 h-9 rounded-full bg-card flex items-center justify-center",
              "shadow-md hover:shadow-lg transition-all duration-200",
              "disabled:opacity-0 disabled:pointer-events-none",
              "active:scale-95"
            )}
          >
            <ChevronLeft size={18} className="text-foreground" />
          </button>

          <button
            onClick={() => emblaApi?.scrollNext()}
            disabled={!canNext}
            aria-label="Next review"
            className={cn(
              "absolute -right-5 md:-right-12 top-1/2 -translate-y-1/2 z-10",
              "w-9 h-9 rounded-full bg-card flex items-center justify-center",
              "shadow-md hover:shadow-lg transition-all duration-200",
              "disabled:opacity-0 disabled:pointer-events-none",
              "active:scale-95"
            )}
          >
            <ChevronRight size={18} className="text-foreground" />
          </button>

          {/* Slides */}
          <div ref={emblaRef} className="overflow-hidden">
            <div className="flex -ml-4">
              {reviews.map((r: any) => (
                <div
                  key={r.id}
                  className="min-w-0 shrink-0 grow-0 basis-full sm:basis-1/2 lg:basis-1/3 pl-4"
                >
                  <div className="py-2 px-1">
                    <ReviewCard
                      rating={r.rating || 0}
                      text={r.review_text}
                      name={r.reviewer_name}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
