
import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/lib/supabase';
import { Product, adaptProductForUI } from '@/types/product';
import { fetchSiteSettings } from '@/api/settings';
import ProductGrid from './ProductGrid';

async function fetchOnSaleProducts(): Promise<Product[]> {
  const { data, error } = await supabase
    .from('products')
    .select('*, product_variants(*), product_images(*)')
    .eq('is_on_sale', true)
    .eq('is_hidden', false)
    .limit(4);
  
  if (error) {
    console.error('Error fetching on-sale products:', error);
    throw new Error(error.message);
  }

  const mappedProducts = (data || []).map(product => ({
    ...product,
    variants: product.product_variants,
    images: product.product_images
  }));

  return mappedProducts.map(product => adaptProductForUI(product)) as Product[];
}

const OnSaleProducts = () => {
  const { data: products = [], isLoading: isLoadingProducts, error: productsError } = useQuery({
    queryKey: ['on-sale-products'],
    queryFn: fetchOnSaleProducts,
    staleTime: 0, // Ensure we refetch when component mounts
    refetchOnMount: true
  });

  const { data: settings } = useQuery({
    queryKey: ['site-settings'],
    queryFn: fetchSiteSettings,
    staleTime: 0, // Ensure we refetch when component mounts
    refetchOnMount: true
  });

  if (isLoadingProducts) {
    return (
      <section className="py-16 bg-background">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">On Sale</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Loading our sale items...
            </p>
          </div>
        </div>
      </section>
    );
  }

  if (productsError || products.length === 0) {
    return null;
  }

  return (
    <ProductGrid
      products={products}
      title={settings?.on_sale_products_title?.trim() || ''}
      description={settings?.on_sale_products_description?.trim() || ''}
      viewAllLink="/shop?sale=true"
      viewAllText="View All Sale Items"
      columns={3}
      rows={1}
      variant="sale"
    />
  );
};

export default OnSaleProducts;
