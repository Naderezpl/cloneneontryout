
import React from 'react';
import { Product } from '@/types/product';
import ProductCard from '@/components/ProductCard';
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from '@/components/ui/carousel';
import { useIsMobile } from '@/hooks/use-mobile';

interface ProductGridProps {
  products: Product[];
  title: string;
  description: string;
  viewAllLink?: string;
  viewAllText?: string;
  columns?: 1 | 2 | 3;
  rows?: 1 | 2 | 3;
  featured?: boolean;
  className?: string;
  variant?: 'default' | 'featured' | 'sale';
}

const ProductGrid: React.FC<ProductGridProps> = ({
  products,
  title,
  description,
  viewAllLink,
  viewAllText = 'View All',
  featured = false,
  className = '',
  variant = 'default'
}) => {
  const isMobile = useIsMobile();

  if (products.length === 0) return null;

  let displayTitle = title;
  let displayDescription = description;
  if (variant === 'featured') {
    displayTitle = title?.trim() ? title : 'Featured Products';
    displayDescription = description?.trim() ? description : '';
  } else if (variant === 'default') {
    displayTitle = title?.trim() ? title : 'Our Products';
    displayDescription = description?.trim() ? description : '';
  }

  return (
    <section className={`py-16 md:py-24 bg-background ${className}`}>
      <div className="container mx-auto px-4">
        <div className="text-center mb-10 md:mb-14">
          <h2 className="text-3xl md:text-4xl font-bold tracking-tight text-foreground mb-3">{displayTitle}</h2>
          {displayDescription && (
            <p className="text-muted-foreground text-base md:text-lg max-w-2xl mx-auto leading-relaxed">
              {displayDescription}
            </p>
          )}
          {viewAllLink && (
            <a 
              href={viewAllLink}
              className="inline-flex items-center justify-center mt-6 px-6 py-2.5 rounded-full border border-foreground text-foreground text-xs font-medium tracking-wider uppercase hover:bg-foreground hover:text-background transition-all duration-300"
            >
              {viewAllText}
            </a>
          )}
        </div>

        <Carousel className="w-full">
          <CarouselContent className="-ml-3">
            {products.map((product) => (
              <CarouselItem
                key={product.id}
                className="pl-3 basis-[80%] sm:basis-[45%] md:basis-1/3 lg:basis-1/4"
              >
                <ProductCard product={product} featured={featured} />
              </CarouselItem>
            ))}
          </CarouselContent>
          <CarouselPrevious className="left-2 bg-background/80 backdrop-blur-sm border-border hover:bg-background" />
          <CarouselNext className="right-2 bg-background/80 backdrop-blur-sm border-border hover:bg-background" />
        </Carousel>
      </div>
    </section>
  );
};

export default ProductGrid;
