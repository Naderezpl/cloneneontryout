
import React from 'react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { PencilRuler, Palette, Clock, Zap } from 'lucide-react';

const CustomSection = () => {
  return (
    <section className="py-20 relative">
      <div className="absolute inset-0 bg-gradient-to-r from-primary/20 to-accent/20 z-0"></div>
      <div className="container mx-auto px-4 relative z-10">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-3xl font-bold mb-6">Create Your Own Custom Neon Sign</h2>
            <p className="text-lg mb-8">
              Bring your vision to life with our easy-to-use custom neon sign creator. 
              Design personalized neon signs for your home, business, or special event.
            </p>
            
            <div className="space-y-4 mb-8">
              <div className="flex items-start gap-4">
                <div className="p-2 rounded-full bg-primary/20 text-primary">
                  <PencilRuler size={24} />
                </div>
                <div>
                  <h3 className="font-bold text-lg">Easy Design Process</h3>
                  <p className="text-muted-foreground">Choose your text, font, color, and size with our intuitive design tool</p>
                </div>
              </div>
              
              <div className="flex items-start gap-4">
                <div className="p-2 rounded-full bg-accent/20 text-accent">
                  <Palette size={24} />
                </div>
                <div>
                  <h3 className="font-bold text-lg">Endless Customization</h3>
                  <p className="text-muted-foreground">Pick from multiple colors, fonts, and mounting options</p>
                </div>
              </div>
              
              <div className="flex items-start gap-4">
                <div className="p-2 rounded-full bg-secondary/20 text-secondary">
                  <Clock size={24} />
                </div>
                <div>
                  <h3 className="font-bold text-lg">Quick Production Time</h3>
                  <p className="text-muted-foreground">Your custom sign will be ready to ship in just 2-3 weeks</p>
                </div>
              </div>
              
              <div className="flex items-start gap-4">
                <div className="p-2 rounded-full bg-neon-yellow/20 text-neon-yellow">
                  <Zap size={24} />
                </div>
                <div>
                  <h3 className="font-bold text-lg">Energy Efficient LEDs</h3>
                  <p className="text-muted-foreground">Our signs use energy-efficient LED technology that lasts for years</p>
                </div>
              </div>
            </div>
            
            <Button size="lg" asChild>
              <Link to="/custom">Start Designing Now</Link>
            </Button>
          </div>
          
          <div className="bg-black/30 p-6 rounded-lg border border-muted">
            <div className="aspect-square max-w-md mx-auto rounded-md overflow-hidden relative">
              <img 
                src="https://images.unsplash.com/photo-1621494547431-5148f0351630?q=80&w=2070&auto=format&fit=crop" 
                alt="Custom neon sign preview" 
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 flex items-center justify-center">
                <h3 className="neon-text-pink text-4xl md:text-5xl font-bold tracking-wide">
                  Your Text Here
                </h3>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CustomSection;
