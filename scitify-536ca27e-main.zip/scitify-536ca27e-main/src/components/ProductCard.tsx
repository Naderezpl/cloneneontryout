
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Product } from '@/types/product';
import { Heart, ShoppingCart } from 'lucide-react';
import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useCart } from '@/contexts/cart';
import { useFavorites } from '@/contexts/FavoritesContext';
import { useToast } from '@/components/ui/use-toast';

interface ProductCardProps {
  product: Product;
  featured?: boolean;
}

const ProductCard = ({ product, featured = false }: ProductCardProps) => {
  const { addToCart } = useCart();
  const { isFavorite, toggleFavorite } = useFavorites();
  const { toast } = useToast();
  
  const [isAddingToCart, setIsAddingToCart] = useState(false);
  const [isTogglingFavorite, setIsTogglingFavorite] = useState(false);
  
  const favorited = isFavorite(product.id);
  
  const mainImage = product.images && product.images.length > 0 
    ? product.images[0].image_url 
    : '/placeholder.svg';
  
  const hasDiscount = (product.variants && product.variants.some(variant => 
    (variant.original_price && variant.original_price > variant.price) || variant.is_on_sale
  )) || product.is_on_sale;
  
  const lowestPrice = product.variants 
    ? Math.min(...product.variants.map(v => v.price))
    : product.price;
  
  const highestOriginalPrice = product.variants 
    ? Math.max(...product.variants.filter(v => v.original_price).map(v => v.original_price || 0))
    : 0;
  
  const handleAddToCart = async (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (isAddingToCart) return;
    
    if (!product.variants || product.variants.length === 0) {
      toast({
        variant: "destructive",
        title: "Cannot add to cart",
        description: "This product has no variants available.",
      });
      return;
    }
    
    try {
      setIsAddingToCart(true);
      
      toast({
        title: "Adding to cart...",
        description: `${product.name} is being added to your cart.`,
      });
      
      await addToCart(product, 1);
      
      toast({
        title: "Added to cart",
        description: `${product.name} has been added to your cart.`,
      });
    } catch (error) {
      console.error('Failed to add item to cart:', error);
      toast({
        variant: "destructive",
        title: "Failed to add to cart",
        description: "There was an error adding this item to your cart.",
      });
    } finally {
      setIsAddingToCart(false);
    }
  };

  const handleToggleFavorite = async (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (isTogglingFavorite) return;
    
    try {
      setIsTogglingFavorite(true);
      
      toggleFavorite(product);
      
      toast({
        title: favorited ? "Removed from favorites" : "Added to favorites",
        description: favorited
          ? `${product.name} has been removed from your favorites.`
          : `${product.name} has been added to your favorites.`,
      });
    } catch (error) {
      console.error('Failed to toggle favorite:', error);
      toast({
        variant: "destructive",
        title: "Failed to update favorites",
        description: "There was an error updating your favorites.",
      });
    } finally {
      setIsTogglingFavorite(false);
    }
  };
  
  return (
    <Card className={`overflow-hidden group transition-all duration-300 hover:shadow-lg h-full flex flex-col w-full max-w-[300px] mx-auto`}>
      <Link to={`/product/${product.id}`} className="flex-1 flex flex-col">
        <div className="relative aspect-square overflow-hidden">
          <img
            src={mainImage}
            alt={product.name}
            className="object-cover w-full h-full transition-transform duration-300 group-hover:scale-105"
          />
          {hasDiscount && (
            <Badge className="absolute top-2 left-2 bg-primary text-primary-foreground">
              Sale
            </Badge>
          )}
          {product.is_featured && (
            <Badge className="absolute top-2 right-2 bg-primary text-primary-foreground">
              Featured
            </Badge>
          )}
        </div>
        <CardContent className="p-4 flex-1">
          <h3 className="font-semibold text-lg mb-2 line-clamp-1">{product.name}</h3>
          <p className="text-muted-foreground text-sm line-clamp-2 mb-2">{product.description}</p>
          <div className="mt-2">
            {hasDiscount ? (
              <div className="flex items-center gap-1">
                <span className="font-semibold text-primary">${lowestPrice?.toFixed(2)}</span>
                {highestOriginalPrice > 0 && (
                  <span className="text-sm text-muted-foreground line-through">${highestOriginalPrice.toFixed(2)}</span>
                )}
              </div>
            ) : (
              <span className="font-semibold">${lowestPrice?.toFixed(2)}</span>
            )}
          </div>
        </CardContent>
      </Link>
      <CardFooter className="flex items-center justify-between p-4 border-t mt-auto">
        <div className="grid grid-cols-2 w-full gap-2">
          <Button
            variant="outline"
            size="sm"
            className={`w-full transition-all duration-200 ${favorited ? 'text-primary border-primary' : ''}`}
            onClick={handleToggleFavorite}
            disabled={isTogglingFavorite}
          >
            <Heart
              className={`h-4 w-4 mr-2 transition-all ${favorited ? 'fill-primary text-primary' : ''} ${isTogglingFavorite ? 'animate-pulse' : ''}`}
            />
            {favorited ? 'Saved' : 'Save'}
          </Button>
          <Button
            variant="outline"
            size="sm"
            className="w-full transition-all duration-200 flex items-center justify-center"
            onClick={handleAddToCart}
            disabled={isAddingToCart}
          >
            <ShoppingCart className={`h-4 w-4 mr-2 shrink-0 ${isAddingToCart ? 'animate-pulse' : ''}`} />
            <span className="truncate">
              {isAddingToCart ? 'Adding...' : 'Add to Cart'}
            </span>
          </Button>
        </div>
      </CardFooter>
    </Card>
  );
};

export default ProductCard;
