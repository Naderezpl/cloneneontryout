
import React, { useCallback, useState } from 'react';
import { Button } from '@/components/ui/button';
import { supabase } from '@/lib/supabase';
import { Upload } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import ImageCropModal from '@/components/ImageCropModal';

interface ImageUploaderProps {
  onImageUploaded: (url: string) => void;
  defaultImageUrl?: string;
  bucketName?: string;
  folderPath?: string;
  disabled?: boolean;
  /** Unique id to avoid input collisions when multiple uploaders exist on the same page */
  uploadId?: string;
  metadata?: {
    variant_id?: string;
  };
  /** Optional fixed aspect ratio for the cropper (e.g. 1 for square, 16/9 for widescreen). Leave undefined for free-form. */
  aspectRatio?: number;
  /** Max output width in px. Defaults to 4096. */
  maxWidth?: number;
  /** Max output height in px. Defaults to 4096. */
  maxHeight?: number;
  /** Recommended dimensions label shown below the upload button (e.g. "1000 × 1000 px") */
  recommendedSize?: string;
}

const ImageUploader = ({ 
  onImageUploaded, 
  defaultImageUrl, 
  bucketName = 'imageassets',
  folderPath = '',
  uploadId,
  metadata = {},
  aspectRatio,
  maxWidth = 4096,
  maxHeight = 4096,
  recommendedSize,
}: ImageUploaderProps) => {
  const inputId = React.useMemo(
    () => uploadId || `image-upload-${Math.random().toString(36).slice(2, 9)}`,
    [uploadId]
  );
  const [isUploading, setIsUploading] = useState(false);
  const [preview, setPreview] = useState<string | null>(defaultImageUrl || null);
  const [cropSrc, setCropSrc] = useState<string | null>(null);
  const [rawFile, setRawFile] = useState<File | null>(null);
  const { toast } = useToast();

  const uploadBlob = useCallback(async (blob: Blob) => {
    try {
      setIsUploading(true);

      const ext = blob.type === 'image/webp' ? 'webp' : 'png';
      const fileName = `${Math.random().toString(36).substring(2, 15)}_${Date.now()}.${ext}`;
      const filePath = folderPath ? `${folderPath}/${fileName}` : fileName;

      // Ensure bucket exists
      try {
        const { data: buckets } = await supabase.storage.listBuckets();
        const bucketExists = buckets?.some((bucket: any) => bucket.name === bucketName);
        if (!bucketExists) {
          await supabase.storage.createBucket(bucketName, { public: true });
        }
      } catch (bucketError) {
        console.log('Bucket check skipped:', bucketError);
      }

      const { error } = await supabase.storage
        .from(bucketName)
        .upload(filePath, blob, {
          upsert: true,
          contentType: blob.type,
        });

      if (error) {
        throw new Error(`Upload failed: ${error.message}`);
      }

      const { data: { publicUrl } } = supabase.storage
        .from(bucketName)
        .getPublicUrl(filePath);

      setPreview(publicUrl);
      onImageUploaded(publicUrl);

      toast({
        title: "Image uploaded",
        description: "Your cropped image has been uploaded successfully.",
      });
    } catch (error) {
      console.error('Error uploading image:', error);
      toast({
        variant: "destructive",
        title: "Upload failed",
        description: error instanceof Error ? error.message : "An unknown upload error occurred",
      });
    } finally {
      setIsUploading(false);
    }
  }, [onImageUploaded, toast, bucketName, folderPath]);

  const handleCropComplete = useCallback((croppedBlob: Blob) => {
    setCropSrc(null);
    setRawFile(null);
    uploadBlob(croppedBlob);
  }, [uploadBlob]);

  const handleFileChange = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    if (!event.target.files || event.target.files.length === 0) return;

    const file = event.target.files[0];

    if (!file.type.startsWith('image/')) {
      toast({ variant: "destructive", title: "Invalid file type", description: "Please upload an image file (JPEG, PNG, etc.)" });
      return;
    }

    // Allow up to 20MB for high-res source images (will be compressed after crop)
    if (file.size > 20 * 1024 * 1024) {
      toast({ variant: "destructive", title: "File too large", description: "Please upload an image smaller than 20MB" });
      return;
    }

    // Reset input so re-selecting the same file works
    event.target.value = '';

    const reader = new FileReader();
    reader.onload = () => {
      setCropSrc(reader.result as string);
      setRawFile(file);
    };
    reader.readAsDataURL(file);
  }, [toast]);

  return (
    <div className="space-y-4">
      {preview && (
        <div className="relative w-40 h-40 overflow-hidden rounded-md bg-muted flex items-center justify-center">
          <img 
            src={preview} 
            alt="Preview" 
            className="max-w-full max-h-full object-contain"
          />
        </div>
      )}
      
      <div className="space-y-1">
        <div className="flex items-center">
          <Button
            type="button"
            variant="outline"
            disabled={isUploading}
            onClick={() => document.getElementById(inputId)?.click()}
            className="flex items-center gap-2"
          >
            <Upload size={16} />
            {isUploading ? 'Uploading...' : 'Upload Image'}
          </Button>
          <input
            id={inputId}
            type="file"
            accept="image/*"
            onChange={handleFileChange}
            className="hidden"
          />
        </div>
        {recommendedSize && (
          <p className="text-xs text-muted-foreground">Recommended: {recommendedSize}</p>
        )}
      </div>

      {cropSrc && (
        <ImageCropModal
          open={!!cropSrc}
          imageSrc={cropSrc}
          onClose={() => { setCropSrc(null); setRawFile(null); }}
          onCropComplete={handleCropComplete}
          aspectRatio={aspectRatio}
          maxWidth={maxWidth}
          maxHeight={maxHeight}
        />
      )}
    </div>
  );
};

export default ImageUploader;
