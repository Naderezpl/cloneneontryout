import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Facebook, Instagram, Youtube, Twitter, MessageCircle, Truck, Shield, CreditCard, Wallet, ChevronRight, Phone, Mail } from 'lucide-react';
import { fetchSiteSettings } from '@/api/settings';
import { useQuery } from '@tanstack/react-query';
import { listPages, CmsPage } from '@/api/pages';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';

const Footer = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const { toast } = useToast();

  const { data: settings } = useQuery({
    queryKey: ['site-settings'],
    queryFn: fetchSiteSettings,
  });

  const { data: pages = [] } = useQuery({
    queryKey: ['pages'],
    queryFn: listPages,
  });

  const pageBySlug = (slug: string): CmsPage | undefined => pages.find(p => p.slug === slug);
  const quickLinks = [
    { slug: 'home', url: '/', fallback: 'Home' },
    { slug: 'shop', url: '/shop', fallback: 'Shop All' },
    { slug: 'about', url: '/about', fallback: 'About Us' },
    { slug: 'shipping-policy', url: '/shipping-policy', fallback: 'Development Time & Payment' },
    { slug: 'care-instructions', url: '/care-instructions', fallback: 'Care Instructions' },
    { slug: 'privacy-policy', url: '/privacy-policy', fallback: 'Privacy Policy' },
    { slug: 'terms-of-service', url: '/terms-of-service', fallback: 'Terms of Service' },
  ].map(link => {
    const p = pageBySlug(link.slug);
    return { ...link, title: p?.title || link.fallback, enabled: p?.enabled !== false };
  }).filter(link => link.enabled);


  return (
    <footer className="bg-background text-foreground border-t border-muted">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="text-center md:text-left">
            <h2 className="text-2xl font-bold text-primary mb-4">
              {settings?.company_name ?? 'Store'}
            </h2>
            <div className="flex flex-col items-center md:items-start gap-[15px]">
              {settings?.social_facebook_enabled && settings?.social_facebook_url && (
                <a href={settings.social_facebook_url} target="_blank" rel="noreferrer" className="flex items-center gap-2 hover:text-primary transition-colors" aria-label="Facebook">
                  <Facebook size={20} />
                  <span className="text-sm">Facebook</span>
                </a>
              )}
              {settings?.social_instagram_enabled && settings?.social_instagram_url && (
                <a href={settings.social_instagram_url} target="_blank" rel="noreferrer" className="flex items-center gap-2 hover:text-primary transition-colors" aria-label="Instagram">
                  <Instagram size={20} />
                  <span className="text-sm">Instagram</span>
                </a>
              )}
              {settings?.social_tiktok_enabled && settings?.social_tiktok_url && (
                <a href={settings.social_tiktok_url} target="_blank" rel="noreferrer" className="flex items-center gap-2 hover:text-primary transition-colors" aria-label="TikTok">
                  <svg viewBox="0 0 24 24" fill="currentColor" className="h-5 w-5"><path d="M19.59 6.69a4.83 4.83 0 01-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 01-2.88 2.5 2.89 2.89 0 01-2.89-2.89 2.89 2.89 0 012.89-2.89c.28 0 .54.04.79.1v-3.5a6.37 6.37 0 00-.79-.05A6.34 6.34 0 003.15 15.2a6.34 6.34 0 006.34 6.34 6.34 6.34 0 006.34-6.34V8.73a8.19 8.19 0 004.76 1.52V6.8a4.84 4.84 0 01-1-.11z"/></svg>
                  <span className="text-sm">TikTok</span>
                </a>
              )}
              {settings?.social_youtube_enabled && settings?.social_youtube_url && (
                <a href={settings.social_youtube_url} target="_blank" rel="noreferrer" className="flex items-center gap-2 hover:text-primary transition-colors" aria-label="YouTube">
                  <Youtube size={20} />
                  <span className="text-sm">YouTube</span>
                </a>
              )}
              {settings?.social_whatsapp_enabled && settings?.social_whatsapp_url && (
                <a href={settings.social_whatsapp_url} target="_blank" rel="noreferrer" className="flex items-center gap-2 hover:text-primary transition-colors" aria-label="WhatsApp">
                  <MessageCircle size={20} />
                  <span className="text-sm">WhatsApp</span>
                </a>
              )}
              {settings?.social_twitter_enabled && settings?.social_twitter_url && (
                <a href={settings.social_twitter_url} target="_blank" rel="noreferrer" className="flex items-center gap-2 hover:text-primary transition-colors" aria-label="Twitter">
                  <Twitter size={20} />
                  <span className="text-sm">Twitter</span>
                </a>
              )}
            </div>
          </div>
          
          <div>
            <h3 className="font-bold mb-4">Quick Links</h3>
            <ul className="grid gap-2">
              {quickLinks.map(link => (
                <li key={link.slug} className="group">
                  <Link to={link.url} className="flex items-center gap-2 text-sm hover:text-primary transition-colors">
                    <ChevronRight className="h-4 w-4 text-muted-foreground group-hover:text-primary transition-colors" />
                    <span className="underline-offset-4 group-hover:underline">{link.title}</span>
                  </Link>
                </li>
              ))}
            </ul>

            <div className="mt-6 space-y-3">
              <a href={`tel:${settings?.contact_phone || ''}`} className="flex items-center gap-3 text-sm hover:text-primary transition-colors group">
                <span className="flex items-center justify-center w-8 h-8 rounded-full bg-muted group-hover:bg-primary/10 transition-colors">
                  <Phone size={15} className="text-primary" />
                </span>
                <span>{settings?.contact_phone || 'Not set'}</span>
              </a>
              <a href={`mailto:${settings?.contact_email || ''}`} className="flex items-center gap-3 text-sm hover:text-primary transition-colors group">
                <span className="flex items-center justify-center w-8 h-8 rounded-full bg-muted group-hover:bg-primary/10 transition-colors">
                  <Mail size={15} className="text-primary" />
                </span>
                <span>{settings?.contact_email || 'Not set'}</span>
              </a>
            </div>
          </div>

          <div>
            <h3 className="font-bold mb-4">Payments</h3>
            <div className="flex flex-col items-center md:items-start gap-[15px]">
              {settings?.payment_cod_enabled && (
                <span className="inline-flex items-center gap-2 rounded-full border border-border bg-muted/40 px-3 py-1 text-xs">
                  <Wallet className="h-3.5 w-3.5" />
                  <span>Cash on Delivery</span>
                </span>
              )}
              {settings?.payment_whish_money_enabled && (
                <span className="inline-flex items-center gap-2 rounded-full border border-border bg-muted/40 px-3 py-1 text-xs">
                  <Wallet className="h-3.5 w-3.5" />
                  <span>Whish Money</span>
                </span>
              )}
              {settings?.payment_visa_enabled && (
                <span className="inline-flex items-center gap-2 rounded-full border border-border bg-muted/40 px-3 py-1 text-xs">
                  <CreditCard className="h-3.5 w-3.5" />
                  <span>Visa</span>
                </span>
              )}
              {settings?.payment_mastercard_enabled && (
                <span className="inline-flex items-center gap-2 rounded-full border border-border bg-muted/40 px-3 py-1 text-xs">
                  <CreditCard className="h-3.5 w-3.5" />
                  <span>Mastercard</span>
                </span>
              )}
              {settings?.payment_paypal_enabled && (
                <span className="inline-flex items-center gap-2 rounded-full border border-border bg-muted/40 px-3 py-1 text-xs">
                  <CreditCard className="h-3.5 w-3.5" />
                  <span>PayPal</span>
                </span>
              )}
              {settings?.payment_apple_pay_enabled && (
                <span className="inline-flex items-center gap-2 rounded-full border border-border bg-muted/40 px-3 py-1 text-xs">
                  <CreditCard className="h-3.5 w-3.5" />
                  <span>Apple Pay</span>
                </span>
              )}
              {settings?.payment_google_pay_enabled && (
                <span className="inline-flex items-center gap-2 rounded-full border border-border bg-muted/40 px-3 py-1 text-xs">
                  <CreditCard className="h-3.5 w-3.5" />
                  <span>Google Pay</span>
                </span>
              )}
            </div>
          </div>
        </div>

        <div className="mt-10">
          <h3 className="text-xl font-bold mb-4 text-primary">Send a Message</h3>
          <form
            className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-card p-4 md:p-6 rounded-lg border border-border"
            onSubmit={(e) => {
              e.preventDefault();
              if (!name.trim() || !email.trim() || !message.trim()) {
                toast({ variant: 'destructive', title: 'Missing information', description: 'Please fill in all fields.' });
                return;
              }
              setSubmitting(true);
              const store = settings?.company_name || 'Store';
              const composed = `New contact from ${store} website:\nName: ${name}\nEmail: ${email}\nMessage: ${message}`;
              const text = encodeURIComponent(composed);
              const base = (settings?.whatsapp_number1 || '').toString().trim();
              let url: string | null = null;
              if (base) {
                if (/^https?:\/\//i.test(base)) {
                  url = base.includes('?') ? `${base}&text=${text}` : `${base}?text=${text}`;
                } else {
                  const phone = base.replace(/[^\d]/g, '');
                  if (phone) url = `https://wa.me/${phone}?text=${text}`;
                }
              }
              if (!url) {
                toast({ variant: 'destructive', title: 'WhatsApp not configured', description: 'Please add a WhatsApp number or URL in Site Settings.' });
                setSubmitting(false);
                return;
              }
              setName('');
              setEmail('');
              setMessage('');
              window.location.href = url;
            }}
          >
            <Input placeholder="Your Name" value={name} onChange={(e) => setName(e.target.value)} disabled={submitting} />
            <Input placeholder="Your Email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} disabled={submitting} />
            <Textarea className="md:col-span-2" placeholder="Your Message" value={message} onChange={(e) => setMessage(e.target.value)} rows={4} disabled={submitting} />
            <div className="md:col-span-2">
              <Button type="submit" className="w-full" disabled={submitting}>
                {submitting ? 'Sending…' : 'Send Message'}
              </Button>
            </div>
          </form>
        </div>
        
        <div className="border-t border-border mt-10 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="flex items-center space-x-6">
              {settings?.free_shipping_enabled && (
                <div className="flex items-center gap-2">
                  <Truck size={18} />
                  <span className="text-sm">{settings?.free_shipping_text || 'Free Shipping'}</span>
                </div>
              )}
              {settings?.secure_payments_enabled && (
                <div className="flex items-center gap-2">
                  <Shield size={18} />
                  <span className="text-sm">{settings?.secure_payments_text || 'Secure Payments'}</span>
                </div>
              )}
            </div>
            <div className="text-sm text-muted-foreground">
              {`© ${new Date().getFullYear()} ${(settings?.company_name || 'Majestic Touch Events')}. All rights reserved.`}
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
