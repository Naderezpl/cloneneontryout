import { useEffect } from 'react';

/**
 * Prevents accidental page refreshes/navigations and maintains
 * session state when the browser tab loses focus.
 *
 * - Intercepts beforeunload to block unintentional reloads.
 * - Disables any visibility-change-driven cleanup.
 */
export function useSessionPersistence() {
  useEffect(() => {
    const handleBeforeUnload = (e: BeforeUnloadEvent) => {
      e.preventDefault();
      // Modern browsers require returnValue to be set
      e.returnValue = '';
    };

    // Keep Supabase auth token refresh alive even when tab is hidden
    const handleVisibilityChange = () => {
      // No-op: intentionally preventing any teardown on tab blur
    };

    window.addEventListener('beforeunload', handleBeforeUnload);
    document.addEventListener('visibilitychange', handleVisibilityChange);

    return () => {
      window.removeEventListener('beforeunload', handleBeforeUnload);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, []);
}
